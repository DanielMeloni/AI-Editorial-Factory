// biome-ignore-all lint: generated file
/* eslint-disable */

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// node_modules/workflow/dist/internal/builtins.js
import { registerStepFunction } from "workflow/internal/private";
async function __builtin_response_array_buffer() {
  return this.arrayBuffer();
}
__name(__builtin_response_array_buffer, "__builtin_response_array_buffer");
async function __builtin_response_json() {
  return this.json();
}
__name(__builtin_response_json, "__builtin_response_json");
async function __builtin_response_text() {
  return this.text();
}
__name(__builtin_response_text, "__builtin_response_text");
registerStepFunction("__builtin_response_array_buffer", __builtin_response_array_buffer);
registerStepFunction("__builtin_response_json", __builtin_response_json);
registerStepFunction("__builtin_response_text", __builtin_response_text);

// node_modules/workflow/dist/stdlib.js
import { registerStepFunction as registerStepFunction2 } from "workflow/internal/private";
async function fetch(...args) {
  return globalThis.fetch(...args);
}
__name(fetch, "fetch");
registerStepFunction2("step//workflow@4.8.1//fetch", fetch);

// src/workflows/chapter-audit-steps.ts
import { registerStepFunction as registerStepFunction3 } from "workflow/internal/private";
import { createAdminClient } from "../../../../../lib/supabase/admin.ts";
import { runAgent } from "../../../../../lib/agents/runner.ts";
import { chapterApparatusAgent, chapterPlanAgent, chapterSectionAgent, sourceAuditorAgent, technicalVerifierAgent, technicalWriterAgent, visualPlanAgent } from "../../../../../lib/agents/definitions.ts";
import { analyzeMarkdown } from "../../../../../lib/ingest/markdown.ts";
import { istruzioniEditoriali } from "../../../../../lib/editorial/direzione.ts";
import { budgetParole, istruzioniBrief } from "../../../../../lib/editorial/brief.ts";
import { rebuildVolumePreviewWith } from "../../../../../lib/publish/preview.ts";
import { buildProjectIndex } from "../../../../../lib/sources/library.ts";
import { mergeSuggestions, researchClaims } from "../../../../../lib/sources/research.ts";
import { verifyUrls } from "../../../../../lib/sources/verify-url.ts";
import { extractConfigBlock } from "../../../../../lib/agents/analysis/dataform.ts";
import { buildDependencyDag } from "../../../../../lib/visual/mermaid-dag.ts";
async function loadChapter(context) {
  const db = createAdminClient();
  const { data: chapter, error } = await db.from("chapters").select("id, number, title, current_version_id, organization_id, project_id").eq("id", context.chapterId).single();
  if (error || !chapter) throw new Error("Capitolo non trovato.");
  if (chapter.organization_id !== context.organizationId || chapter.project_id !== context.projectId) {
    throw new Error("Il capitolo non appartiene al progetto indicato.");
  }
  const { data: version } = await db.from("chapter_versions").select("id, content_md").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  if (!version) throw new Error("Il capitolo non ha alcuna versione da analizzare.");
  const analysis = analyzeMarkdown(version.content_md);
  const isIncremental = analysis.codeBlocks.some((block) => {
    const config = extractConfigBlock(block.content);
    return config !== null && /\btype\s*:\s*["']incremental["']/.test(config);
  });
  return {
    chapter: {
      chapterId: chapter.id,
      number: chapter.number,
      title: chapter.title,
      contentMd: version.content_md,
      headings: analysis.headings.map((h) => ({
        level: h.level,
        text: h.text,
        line: h.line
      })),
      codeBlocks: analysis.codeBlocks.map((b) => ({
        language: b.language,
        content: b.content,
        line: b.line
      })),
      links: analysis.links,
      figures: analysis.figures.map((f) => ({
        alt: f.alt,
        src: f.src,
        line: f.line
      })),
      placeholders: analysis.placeholders.map((p) => ({
        description: p.description,
        line: p.line
      }))
    },
    versionId: version.id,
    isIncremental
  };
}
__name(loadChapter, "loadChapter");
function componiCapitolo(numero, titolo, obiettivi, corpo, apparato) {
  const parti = [
    `# ${numero !== null ? `Capitolo ${numero} - ` : ""}${titolo}`,
    "",
    "> **OBIETTIVI DEL CAPITOLO**",
    ">",
    ...obiettivi.map((obiettivo) => `> - ${obiettivo}`),
    "",
    corpo,
    ""
  ];
  if (apparato.bestPractices.length > 0) {
    parti.push("## Best practice", "", ...apparato.bestPractices.map((voce) => `- ${voce}`), "");
  }
  if (apparato.commonErrors.length > 0) {
    parti.push("## Errori comuni", "", ...apparato.commonErrors.map((voce) => `- ${voce}`), "");
  }
  parti.push("## Riassunto", "", apparato.summary, "");
  parti.push("## Punti chiave", "", ...apparato.keyPoints.map((voce) => `- ${voce}`), "");
  if (apparato.quiz.length > 0) {
    parti.push("## Quiz", "", "Per ogni domanda una sola risposta \xE8 corretta.", "");
    apparato.quiz.forEach((domanda, indice) => {
      parti.push(`${indice + 1}. **${domanda.question}**`, "");
      domanda.options.forEach((opzione, i) => {
        parti.push(`   ${String.fromCharCode(97 + i)}) ${opzione}`);
      });
      parti.push("");
    });
    parti.push("**Soluzioni:** " + apparato.quiz.map((domanda, indice) => `${indice + 1}-${String.fromCharCode(97 + domanda.correct)}`).join(", "), "");
  }
  if (apparato.lab.trim()) parti.push("## Laboratorio", "", apparato.lab.trim(), "");
  return parti.join("\n");
}
__name(componiCapitolo, "componiCapitolo");
async function draftChapter(context, chapter, baseVersionId) {
  const db = createAdminClient();
  const [{ data: chapterRow }, { data: project }] = await Promise.all([
    db.from("chapters").select("part_id").eq("id", context.chapterId).maybeSingle(),
    db.from("projects").select("language, level, tone, register, style_notes, work_shape, target_pages, scope, out_of_scope, audience").eq("id", context.projectId).maybeSingle()
  ]);
  const { data: part } = chapterRow?.part_id ? await db.from("publication_parts").select("title").eq("id", chapterRow.part_id).maybeSingle() : {
    data: null
  };
  const [{ data: references }, { data: referenceChunks }, { data: sourceChunks }] = await Promise.all([
    db.from("reference_sources").select("title, publisher, url").or(`project_id.eq.${context.projectId},project_id.is.null`).neq("status", "proposed").limit(60),
    db.from("reference_chunks").select("heading, content").or(`project_id.eq.${context.projectId},project_id.is.null`).order("chunk_index", {
      ascending: true
    }).limit(120),
    db.from("source_chunks").select("heading_path, content").eq("project_id", context.projectId).order("chunk_index", {
      ascending: true
    }).limit(120)
  ]);
  const evidence = [
    ...(referenceChunks ?? []).map((blocco) => `${blocco.heading ? `## ${blocco.heading}
` : ""}${blocco.content}`),
    ...(sourceChunks ?? []).map((blocco) => `${blocco.heading_path?.length ? `## ${blocco.heading_path.join(" > ")}
` : ""}${blocco.content}`)
  ].join("\n\n").slice(0, 6e4);
  const obiettivo = chapter.contentMd.match(/##\s*Obiettivo\s*\n+([\s\S]*?)(?:\n#{1,2}\s|$)/i);
  const { count: capitoliTotali } = await db.from("chapters").select("id", {
    count: "exact",
    head: true
  }).eq("project_id", context.projectId).neq("kind", "back_matter");
  const budgetOpera = budgetParole(project?.target_pages ?? null);
  const budgetCapitolo = budgetOpera !== null && (capitoliTotali ?? 0) > 0 ? Math.round(budgetOpera / (capitoliTotali ?? 1)) : null;
  const ingresso = {
    chapterId: chapter.chapterId,
    number: chapter.number,
    title: chapter.title,
    objective: (obiettivo?.[1] ?? "").trim().slice(0, 2e3),
    partTitle: part?.title ?? null,
    language: project?.language ?? "it",
    // Senza questo, tre volumi sullo stesso argomento produrrebbero lo stesso
    // capitolo con tre titoli diversi.
    direzione: [
      istruzioniEditoriali({
        level: project?.level ?? "base",
        tone: project?.tone ?? "didattico",
        register: project?.register ?? "tecnico_operativo",
        styleNotes: project?.style_notes ?? null
      }),
      istruzioniBrief({
        workShape: project?.work_shape,
        targetPages: project?.target_pages,
        scope: project?.scope,
        outOfScope: project?.out_of_scope,
        audience: project?.audience
      }),
      // Il budget del volume diviso per i capitoli che lo compongono. Senza,
      // «cento pagine» resta un'intenzione dell'editore che non raggiunge mai
      // chi scrive il singolo capitolo.
      budgetCapitolo !== null ? `- Questo capitolo deve aggirarsi sulle ${budgetCapitolo.toLocaleString("it-IT")} parole, apparato di chiusura compreso: \xE8 la quota che gli spetta nel totale dell\u2019opera.` : ""
    ].filter(Boolean).join("\n"),
    references: (references ?? []).map((riferimento) => ({
      title: riferimento.title,
      publisher: riferimento.publisher ?? null,
      url: riferimento.url ?? null
    })),
    evidence,
    existingContent: chapter.contentMd
  };
  const contesto = {
    db,
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "stesura-capitolo"
  };
  const gaps = [];
  const piano = (await runAgent(chapterPlanAgent, ingresso, contesto)).output;
  const scaletta = piano.sections.map((sezione) => sezione.title);
  const sezioni = [];
  for (const [indice, sezione] of piano.sections.entries()) {
    const scritta = (await runAgent(chapterSectionAgent, {
      ...ingresso,
      sectionTitle: sezione.title,
      sectionIntent: sezione.intent,
      needsCode: sezione.needsCode,
      needsFigure: sezione.needsFigure,
      sectionNumber: indice + 1,
      outline: scaletta,
      objectives: piano.objectives
    }, contesto)).output;
    sezioni.push(scritta.contentMd.trim());
    gaps.push(...scritta.gaps);
  }
  const corpo = sezioni.join("\n\n");
  const apparato = (await runAgent(chapterApparatusAgent, {
    ...ingresso,
    objectives: piano.objectives,
    outline: scaletta,
    body: corpo
  }, contesto)).output;
  gaps.push(...apparato.gaps);
  const contentMd = componiCapitolo(chapter.number, chapter.title, piano.objectives, corpo, apparato);
  const { data: last } = await db.from("chapter_versions").select("version_no").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(contentMd));
  const contentHash = Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  const analysis = analyzeMarkdown(contentMd);
  const wordCount = contentMd.split(/\s+/).filter(Boolean).length;
  const { data: created, error } = await db.from("chapter_versions").insert({
    chapter_id: context.chapterId,
    project_id: context.projectId,
    organization_id: context.organizationId,
    version_no: (last?.version_no ?? 0) + 1,
    origin: "ai_proposal",
    content_md: contentMd,
    content_hash: contentHash,
    summary: `Capitolo scritto in ${piano.sections.length} sezioni${gaps.length > 0 ? `, con ${gaps.length} punti non coperti dalle fonti` : ""}.`,
    word_count: wordCount,
    parent_version_id: baseVersionId,
    workflow_run_id: context.workflowRunId
  }).select("id").single();
  if (error || !created) throw new Error(error?.message ?? "Stesura non registrata.");
  await db.from("chapters").update({
    current_version_id: created.id,
    status: "in_review",
    word_count: wordCount,
    code_block_count: analysis.codeBlocks.length,
    heading_count: analysis.headings.length,
    figure_count: analysis.figures.length,
    placeholder_count: analysis.placeholders.length,
    link_count: analysis.links.length
  }).eq("id", context.chapterId);
  return {
    chapter: {
      ...chapter,
      contentMd,
      headings: analysis.headings.map((h) => ({
        level: h.level,
        text: h.text,
        line: h.line
      })),
      codeBlocks: analysis.codeBlocks.map((b) => ({
        language: b.language,
        content: b.content,
        line: b.line
      })),
      links: analysis.links,
      figures: analysis.figures.map((f) => ({
        alt: f.alt,
        src: f.src,
        line: f.line
      })),
      placeholders: analysis.placeholders.map((p) => ({
        description: p.description,
        line: p.line
      }))
    },
    versionId: created.id,
    gaps,
    grounded: gaps.length === 0
  };
}
__name(draftChapter, "draftChapter");
async function verifyTechnical(context, chapter) {
  const result = await runAgent(technicalVerifierAgent, chapter, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "verifica-tecnica"
  });
  return result.output;
}
__name(verifyTechnical, "verifyTechnical");
async function auditSources(context, chapter, claims) {
  if (chapter.links.length === 0 && claims.length === 0) {
    return {
      citations: [],
      suggestions: [],
      unmatchedClaims: 0,
      issues: [
        {
          kind: "source",
          severity: "low",
          title: "Capitolo senza contenuto verificabile",
          detail: "Il capitolo non contiene collegamenti n\xE9 affermazioni tecniche da sostenere con una fonte. La verifica dei riferimenti non \xE8 stata eseguita: non c\u2019\xE8 nulla da verificare, e nulla \xE8 stato dedotto dal titolo.",
          suggestion: "Scrivere il capitolo, poi ripetere l\u2019audit.",
          location: {
            line: null,
            heading: null,
            excerpt: null
          },
          evidence: []
        }
      ],
      // L'esito non è incerto: l'assenza è un fatto constatato, non una stima.
      confidence: 1,
      summary: "Nessun collegamento e nessuna affermazione da verificare: audit delle fonti non eseguito."
    };
  }
  const result = await runAgent(sourceAuditorAgent, {
    ...chapter,
    claims
  }, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "verifica-fonti"
  });
  return result.output;
}
__name(auditSources, "auditSources");
async function enrichWithLibrary(context, claims, suggestions) {
  const db = createAdminClient();
  const { index, libraryEntries } = await buildProjectIndex(db, context.organizationId, context.projectId);
  if (libraryEntries === 0) {
    return {
      suggestions,
      unmatched: 0,
      libraryEntries: 0
    };
  }
  const research = researchClaims(claims, index);
  return {
    suggestions: mergeSuggestions(suggestions, research.suggestions),
    unmatched: research.unmatched,
    libraryEntries
  };
}
__name(enrichWithLibrary, "enrichWithLibrary");
async function verifyCitations(_context, citations) {
  const daControllare = citations.filter((citation) => citation.verification !== "non_valida");
  if (daControllare.length === 0) return {
    issues: [],
    verified: [],
    broken: 0
  };
  const esiti = await verifyUrls(daControllare.map((citation) => citation.url));
  const issues = [];
  const verified = [];
  for (let i = 0; i < esiti.length; i += 1) {
    const esito = esiti[i];
    const citation = daControllare[i];
    verified.push({
      url: citation.url,
      status: esito.status,
      ok: esito.ok,
      title: esito.title
    });
    if (esito.ok) {
      if (citation.isOfficial && !citation.inIndex) {
        issues.push({
          kind: "source",
          severity: "info",
          title: "Pagina ufficiale non ancora censita",
          detail: `${citation.url} risponde ${esito.status} e il titolo \xE8 \xAB${esito.title ?? "\u2014"}\xBB. Il riferimento \xE8 valido: manca soltanto dall\u2019indice curato.`,
          suggestion: "Valutare l\u2019aggiunta a catalog.data.ts con npm run sources:refresh.",
          location: {
            line: citation.line || null,
            heading: null,
            excerpt: citation.url
          },
          evidence: [
            citation.url
          ]
        });
      }
      continue;
    }
    issues.push({
      kind: "source",
      severity: "high",
      title: "Collegamento non raggiungibile",
      detail: `${citation.url} non risponde` + (esito.status !== null ? ` (stato ${esito.status}).` : ".") + " Un collegamento morto in un manuale stampato non \xE8 correggibile.",
      suggestion: esito.note ?? "Aprire il collegamento e sostituirlo.",
      location: {
        line: citation.line || null,
        heading: null,
        excerpt: citation.url
      },
      evidence: [
        citation.url
      ]
    });
  }
  return {
    issues,
    verified,
    broken: issues.filter((i) => i.severity === "high").length
  };
}
__name(verifyCitations, "verifyCitations");
async function persistAudit(context, technical, sources, suggestions, linkIssues, linkChecks) {
  const db = createAdminClient();
  const senzaSospetti = sources.issues.filter((issue) => issue.title !== "Riferimento ufficiale da verificare");
  const issues = [
    ...technical.issues,
    ...senzaSospetti,
    ...linkIssues
  ].map((issue) => ({
    ...issue,
    // «riga 0» non esiste: le righe partono da 1. Uno zero significa «non
    // determinata», e dirlo così evita di mandare il revisore a cercare il nulla.
    location: {
      ...issue.location,
      line: issue.location.line === 0 ? null : issue.location.line
    }
  }));
  await db.from("verification_issues").delete().eq("workflow_run_id", context.workflowRunId);
  if (issues.length > 0) {
    const rows = issues.map((issue) => ({
      project_id: context.projectId,
      organization_id: context.organizationId,
      chapter_id: context.chapterId,
      workflow_run_id: context.workflowRunId,
      kind: issue.kind,
      severity: issue.severity,
      status: "open",
      title: issue.title,
      detail: issue.detail,
      suggestion: issue.suggestion,
      location: issue.location,
      evidence: issue.evidence
    }));
    for (let i = 0; i < rows.length; i += 100) {
      await db.from("verification_issues").insert(rows.slice(i, i + 100));
    }
  }
  await db.from("citations").delete().eq("chapter_id", context.chapterId);
  if (sources.citations.length > 0) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await db.from("citations").insert(sources.citations.map((citation) => ({
      project_id: context.projectId,
      organization_id: context.organizationId,
      chapter_id: context.chapterId,
      url: citation.url,
      title: citation.indexedTitle ?? citation.text ?? null,
      publisher: citation.domain || null,
      is_official: citation.isOfficial,
      note: citation.note,
      // Ora `is_reachable` dice ciò che dovrebbe dire: se la pagina ha
      // risposto quando è stata aperta. Nullo solo per ciò che non è stato
      // interrogato.
      http_status: linkChecks.find((c) => c.url === citation.url)?.status ?? null,
      is_reachable: linkChecks.find((c) => c.url === citation.url)?.ok ?? null,
      last_checked_at: now
    })));
  }
  await db.from("source_suggestions").delete().eq("workflow_run_id", context.workflowRunId);
  const suggestionRows = suggestions.flatMap((suggestion) => suggestion.candidates.map((candidate, index) => ({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    workflow_run_id: context.workflowRunId,
    claim_line: suggestion.line,
    claim_excerpt: suggestion.statement,
    category: suggestion.category,
    url: candidate.url,
    title: candidate.title,
    section: candidate.section,
    score: candidate.score,
    rank: index + 1,
    matched_terms: candidate.matchedTerms,
    origin: candidate.origin,
    reference_id: candidate.referenceId,
    page: candidate.page,
    status: "proposed"
  })));
  for (let i = 0; i < suggestionRows.length; i += 100) {
    await db.from("source_suggestions").insert(suggestionRows.slice(i, i + 100));
  }
  return {
    issueCount: issues.length,
    critical: issues.filter((i) => i.severity === "critical").length,
    high: issues.filter((i) => i.severity === "high").length,
    suggestions: suggestions.length
  };
}
__name(persistAudit, "persistAudit");
async function proposeRevision(context, chapter, issues, suggestions, baseVersionId) {
  const db = createAdminClient();
  const result = await runAgent(technicalWriterAgent, {
    ...chapter,
    issues,
    suggestions
  }, {
    db,
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "proposta-revisione"
  });
  const revision = result.output;
  if (revision.changes.length === 0) {
    return {
      versionId: null,
      changeCount: 0,
      summary: revision.summary
    };
  }
  const { data: last } = await db.from("chapter_versions").select("version_no").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(revision.contentMd));
  const contentHash = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  const { data: created, error } = await db.from("chapter_versions").insert({
    chapter_id: context.chapterId,
    project_id: context.projectId,
    organization_id: context.organizationId,
    version_no: (last?.version_no ?? 0) + 1,
    origin: "ai_proposal",
    content_md: revision.contentMd,
    content_hash: contentHash,
    summary: revision.summary,
    word_count: revision.contentMd.split(/\s+/).filter(Boolean).length,
    parent_version_id: baseVersionId,
    workflow_run_id: context.workflowRunId,
    agent_run_id: result.agentRunId,
    created_by: context.actorId
  }).select("id").single();
  if (error || !created) throw new Error(`Salvataggio della proposta fallito: ${error?.message ?? ""}`);
  return {
    versionId: created.id,
    changeCount: revision.changes.length,
    summary: revision.summary
  };
}
__name(proposeRevision, "proposeRevision");
async function planVisuals(context, chapter, dataformRefs) {
  const result = await runAgent(visualPlanAgent, {
    ...chapter,
    dataformRefs
  }, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "piano-visuale"
  });
  return result.output;
}
__name(planVisuals, "planVisuals");
async function generateDiagrams(context, chapterTitle, dataformRefs, isIncremental) {
  const db = createAdminClient();
  const diagram = buildDependencyDag({
    target: chapterTitle,
    dependencies: dataformRefs,
    isIncremental
  });
  const { data: existing } = await db.from("visual_assets").select("version").eq("chapter_id", context.chapterId).eq("kind", "diagram").order("version", {
    ascending: false
  }).limit(1).maybeSingle();
  const { data: asset, error } = await db.from("visual_assets").insert({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    kind: "diagram",
    generator: "mermaid",
    // Anche un diagramma esatto richiede l'occhio umano prima di finire nel libro.
    status: "pending_approval",
    version: (existing?.version ?? 0) + 1,
    title: diagram.title,
    caption: diagram.caption,
    alt_text: diagram.altText,
    mermaid_source: diagram.mermaid,
    created_by: context.actorId
  }).select("id").single();
  if (error || !asset) throw new Error(`Salvataggio del diagramma fallito: ${error?.message ?? ""}`);
  return {
    assetIds: [
      asset.id
    ],
    mermaid: diagram.mermaid
  };
}
__name(generateDiagrams, "generateDiagrams");
async function requestApproval(context, baseVersionId, proposedVersionId, resumeToken, summary) {
  const db = createAdminClient();
  const { data, error } = await db.from("review_requests").insert({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    workflow_run_id: context.workflowRunId,
    base_version_id: baseVersionId,
    proposed_version_id: proposedVersionId,
    status: "pending",
    title: "Revisione proposta dall\u2019audit tecnico",
    summary,
    resume_token: resumeToken,
    requested_by: context.actorId
  }).select("id").single();
  if (error || !data) throw new Error(`Creazione della richiesta di revisione fallita: ${error?.message ?? ""}`);
  await db.from("workflow_runs").update({
    status: "awaiting_approval",
    current_step: "attesa-approvazione"
  }).eq("id", context.workflowRunId);
  await db.from("chapters").update({
    status: "in_review"
  }).eq("id", context.chapterId);
  return data.id;
}
__name(requestApproval, "requestApproval");
async function applyDecision(context, reviewRequestId, _proposedVersionIdAtCreation, decision, note, decidedBy) {
  const db = createAdminClient();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const { data: current } = await db.from("review_requests").select("proposed_version_id").eq("id", reviewRequestId).maybeSingle();
  const proposedVersionId = current?.proposed_version_id ?? _proposedVersionIdAtCreation;
  await db.from("review_requests").update({
    status: decision,
    decided_at: now,
    decided_by: decidedBy,
    decision_note: note
  }).eq("id", reviewRequestId);
  if (decision !== "approved" || !proposedVersionId) {
    await db.from("chapters").update({
      status: "draft"
    }).eq("id", context.chapterId);
    return {
      approvedVersionId: null
    };
  }
  await db.from("chapter_versions").update({
    origin: "approved",
    is_approved: true,
    approved_by: decidedBy,
    approved_at: now
  }).eq("id", proposedVersionId);
  await db.from("chapters").update({
    current_version_id: proposedVersionId,
    status: "approved"
  }).eq("id", context.chapterId);
  return {
    approvedVersionId: proposedVersionId
  };
}
__name(applyDecision, "applyDecision");
async function markStep(workflowRunId, step, completed, total) {
  await createAdminClient().from("workflow_runs").update({
    current_step: step,
    completed_steps: completed,
    total_steps: total,
    status: "running"
  }).eq("id", workflowRunId);
}
__name(markStep, "markStep");
async function finishRun(workflowRunId, status, output, error) {
  await createAdminClient().from("workflow_runs").update({
    status,
    output,
    error,
    finished_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", workflowRunId);
}
__name(finishRun, "finishRun");
async function updateVolumePreview(context) {
  try {
    const esito = await rebuildVolumePreviewWith(createAdminClient(), {
      projectId: context.projectId,
      organizationId: context.organizationId,
      actorId: context.actorId
    });
    return {
      ok: esito.ok,
      chapters: esito.chapters ?? 0,
      words: esito.words ?? 0,
      message: esito.message
    };
  } catch (error) {
    return {
      ok: false,
      chapters: 0,
      words: 0,
      message: `Anteprima non aggiornata: ${error.message}`
    };
  }
}
__name(updateVolumePreview, "updateVolumePreview");
registerStepFunction3("step//./src/workflows/chapter-audit-steps//loadChapter", loadChapter);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//draftChapter", draftChapter);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//verifyTechnical", verifyTechnical);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//auditSources", auditSources);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//enrichWithLibrary", enrichWithLibrary);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//verifyCitations", verifyCitations);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//persistAudit", persistAudit);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//proposeRevision", proposeRevision);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//planVisuals", planVisuals);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//generateDiagrams", generateDiagrams);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//requestApproval", requestApproval);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//applyDecision", applyDecision);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//markStep", markStep);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//finishRun", finishRun);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//updateVolumePreview", updateVolumePreview);

// virtual-entry.js
import { stepEntrypoint, stepEntrypoint as stepEntrypoint2 } from "workflow/runtime";
export {
  stepEntrypoint as HEAD,
  stepEntrypoint2 as POST
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3dvcmtmbG93L3NyYy9pbnRlcm5hbC9idWlsdGlucy50cyIsICIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvd29ya2Zsb3cvc3JjL3N0ZGxpYi50cyIsICIuLi8uLi8uLi8uLi8uLi93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy50cyIsICIuLi8uLi8uLi8uLi8uLi8uLi92aXJ0dWFsLWVudHJ5LmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKipcbiAqIFRoZXNlIGFyZSB0aGUgYnVpbHQtaW4gc3RlcHMgdGhhdCBhcmUgXCJhdXRvbWF0aWNhbGx5IGF2YWlsYWJsZVwiIGluIHRoZSB3b3JrZmxvdyBzY29wZS4gVGhleSBhcmVcbiAqIHNpbWlsYXIgdG8gXCJzdGRsaWJcIiBleGNlcHQgdGhhdCBhcmUgbm90IG1lYW50IHRvIGJlIGltcG9ydGVkIGJ5IHVzZXJzLCBidXQgYXJlIGluc3RlYWQgXCJqdXN0IGF2YWlsYWJsZVwiXG4gKiBhbG9uZ3NpZGUgdXNlciBkZWZpbmVkIHN0ZXBzLiBUaGV5IGFyZSB1c2VkIGludGVybmFsbHkgYnkgdGhlIHJ1bnRpbWVcbiAqL1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gX19idWlsdGluX3Jlc3BvbnNlX2FycmF5X2J1ZmZlcihcbiAgdGhpczogUmVxdWVzdCB8IFJlc3BvbnNlXG4pIHtcbiAgJ3VzZSBzdGVwJztcbiAgcmV0dXJuIHRoaXMuYXJyYXlCdWZmZXIoKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIF9fYnVpbHRpbl9yZXNwb25zZV9qc29uKHRoaXM6IFJlcXVlc3QgfCBSZXNwb25zZSkge1xuICAndXNlIHN0ZXAnO1xuICByZXR1cm4gdGhpcy5qc29uKCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBfX2J1aWx0aW5fcmVzcG9uc2VfdGV4dCh0aGlzOiBSZXF1ZXN0IHwgUmVzcG9uc2UpIHtcbiAgJ3VzZSBzdGVwJztcbiAgcmV0dXJuIHRoaXMudGV4dCgpO1xufVxuIiwgIi8qKlxuICogVGhpcyBpcyB0aGUgXCJzdGFuZGFyZCBsaWJyYXJ5XCIgb2Ygc3RlcHMgdGhhdCB3ZSBtYWtlIGF2YWlsYWJsZSB0byBhbGwgd29ya2Zsb3cgdXNlcnMuXG4gKiBUaGUgY2FuIGJlIGltcG9ydGVkIGxpa2Ugc286IGBpbXBvcnQgeyBmZXRjaCB9IGZyb20gJ3dvcmtmbG93J2AuIGFuZCB1c2VkIGluIHdvcmtmbG93LlxuICogVGhlIG5lZWQgdG8gYmUgZXhwb3J0ZWQgZGlyZWN0bHkgaW4gdGhpcyBwYWNrYWdlIGFuZCBjYW5ub3QgbGl2ZSBpbiBgY29yZWAgdG8gcHJldmVudFxuICogY2lyY3VsYXIgZGVwZW5kZW5jaWVzIHBvc3QtY29tcGlsYXRpb24uXG4gKi9cblxuLyoqXG4gKiBBIGhvaXN0ZWQgYGZldGNoKClgIGZ1bmN0aW9uIHRoYXQgaXMgZXhlY3V0ZWQgYXMgYSBcInN0ZXBcIiBmdW5jdGlvbixcbiAqIGZvciB1c2Ugd2l0aGluIHdvcmtmbG93IGZ1bmN0aW9ucy5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9GZXRjaF9BUElcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoKC4uLmFyZ3M6IFBhcmFtZXRlcnM8dHlwZW9mIGdsb2JhbFRoaXMuZmV0Y2g+KSB7XG4gICd1c2Ugc3RlcCc7XG4gIHJldHVybiBnbG9iYWxUaGlzLmZldGNoKC4uLmFyZ3MpO1xufVxuIiwgImltcG9ydCB7IHJlZ2lzdGVyU3RlcEZ1bmN0aW9uIH0gZnJvbSBcIndvcmtmbG93L2ludGVybmFsL3ByaXZhdGVcIjtcbmltcG9ydCAnc2VydmVyLW9ubHknO1xuaW1wb3J0IHsgY3JlYXRlQWRtaW5DbGllbnQgfSBmcm9tICdAL2xpYi9zdXBhYmFzZS9hZG1pbic7XG5pbXBvcnQgeyBydW5BZ2VudCB9IGZyb20gJ0AvbGliL2FnZW50cy9ydW5uZXInO1xuaW1wb3J0IHsgY2hhcHRlckFwcGFyYXR1c0FnZW50LCBjaGFwdGVyUGxhbkFnZW50LCBjaGFwdGVyU2VjdGlvbkFnZW50LCBzb3VyY2VBdWRpdG9yQWdlbnQsIHRlY2huaWNhbFZlcmlmaWVyQWdlbnQsIHRlY2huaWNhbFdyaXRlckFnZW50LCB2aXN1YWxQbGFuQWdlbnQgfSBmcm9tICdAL2xpYi9hZ2VudHMvZGVmaW5pdGlvbnMnO1xuaW1wb3J0IHsgYW5hbHl6ZU1hcmtkb3duIH0gZnJvbSAnQC9saWIvaW5nZXN0L21hcmtkb3duJztcbmltcG9ydCB7IGlzdHJ1emlvbmlFZGl0b3JpYWxpIH0gZnJvbSAnQC9saWIvZWRpdG9yaWFsL2RpcmV6aW9uZSc7XG5pbXBvcnQgeyBidWRnZXRQYXJvbGUsIGlzdHJ1emlvbmlCcmllZiB9IGZyb20gJ0AvbGliL2VkaXRvcmlhbC9icmllZic7XG5pbXBvcnQgeyByZWJ1aWxkVm9sdW1lUHJldmlld1dpdGggfSBmcm9tICdAL2xpYi9wdWJsaXNoL3ByZXZpZXcnO1xuaW1wb3J0IHsgYnVpbGRQcm9qZWN0SW5kZXggfSBmcm9tICdAL2xpYi9zb3VyY2VzL2xpYnJhcnknO1xuaW1wb3J0IHsgbWVyZ2VTdWdnZXN0aW9ucywgcmVzZWFyY2hDbGFpbXMgfSBmcm9tICdAL2xpYi9zb3VyY2VzL3Jlc2VhcmNoJztcbmltcG9ydCB7IHZlcmlmeVVybHMgfSBmcm9tICdAL2xpYi9zb3VyY2VzL3ZlcmlmeS11cmwnO1xuaW1wb3J0IHsgZXh0cmFjdENvbmZpZ0Jsb2NrIH0gZnJvbSAnQC9saWIvYWdlbnRzL2FuYWx5c2lzL2RhdGFmb3JtJztcbmltcG9ydCB7IGJ1aWxkRGVwZW5kZW5jeURhZyB9IGZyb20gJ0AvbGliL3Zpc3VhbC9tZXJtYWlkLWRhZyc7XG4vKipfX2ludGVybmFsX3dvcmtmbG93c3tcInN0ZXBzXCI6e1wic3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLnRzXCI6e1wiYXBwbHlEZWNpc2lvblwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2FwcGx5RGVjaXNpb25cIn0sXCJhdWRpdFNvdXJjZXNcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9hdWRpdFNvdXJjZXNcIn0sXCJkcmFmdENoYXB0ZXJcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9kcmFmdENoYXB0ZXJcIn0sXCJlbnJpY2hXaXRoTGlicmFyeVwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2VucmljaFdpdGhMaWJyYXJ5XCJ9LFwiZmluaXNoUnVuXCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZmluaXNoUnVuXCJ9LFwiZ2VuZXJhdGVEaWFncmFtc1wiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2dlbmVyYXRlRGlhZ3JhbXNcIn0sXCJsb2FkQ2hhcHRlclwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2xvYWRDaGFwdGVyXCJ9LFwibWFya1N0ZXBcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9tYXJrU3RlcFwifSxcInBlcnNpc3RBdWRpdFwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3BlcnNpc3RBdWRpdFwifSxcInBsYW5WaXN1YWxzXCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vcGxhblZpc3VhbHNcIn0sXCJwcm9wb3NlUmV2aXNpb25cIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9wcm9wb3NlUmV2aXNpb25cIn0sXCJyZXF1ZXN0QXBwcm92YWxcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9yZXF1ZXN0QXBwcm92YWxcIn0sXCJ1cGRhdGVWb2x1bWVQcmV2aWV3XCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vdXBkYXRlVm9sdW1lUHJldmlld1wifSxcInZlcmlmeUNpdGF0aW9uc1wiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3ZlcmlmeUNpdGF0aW9uc1wifSxcInZlcmlmeVRlY2huaWNhbFwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3ZlcmlmeVRlY2huaWNhbFwifX19fSovO1xuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAxIFx1MDBCNyBDYXJpY2FtZW50byBkZWwgY2FwaXRvbG8gZSBkZWxsZSBmb250aSBjb2xsZWdhdGVcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRDaGFwdGVyKGNvbnRleHQpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgeyBkYXRhOiBjaGFwdGVyLCBlcnJvciB9ID0gYXdhaXQgZGIuZnJvbSgnY2hhcHRlcnMnKS5zZWxlY3QoJ2lkLCBudW1iZXIsIHRpdGxlLCBjdXJyZW50X3ZlcnNpb25faWQsIG9yZ2FuaXphdGlvbl9pZCwgcHJvamVjdF9pZCcpLmVxKCdpZCcsIGNvbnRleHQuY2hhcHRlcklkKS5zaW5nbGUoKTtcbiAgICBpZiAoZXJyb3IgfHwgIWNoYXB0ZXIpIHRocm93IG5ldyBFcnJvcignQ2FwaXRvbG8gbm9uIHRyb3ZhdG8uJyk7XG4gICAgLy8gQ29udHJvbGxvIGRpIGFwcGFydGVuZW56YSBlc3BsaWNpdG86IGxvIHN0ZXAgdXNhIGlsIHNlcnZpY2Ugcm9sZSwgY2hlXG4gICAgLy8gaWdub3JhIGxhIFJMUy4gTGEgY29lcmVuemEgdmEgcml2ZXJpZmljYXRhIHF1aS5cbiAgICBpZiAoY2hhcHRlci5vcmdhbml6YXRpb25faWQgIT09IGNvbnRleHQub3JnYW5pemF0aW9uSWQgfHwgY2hhcHRlci5wcm9qZWN0X2lkICE9PSBjb250ZXh0LnByb2plY3RJZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lsIGNhcGl0b2xvIG5vbiBhcHBhcnRpZW5lIGFsIHByb2dldHRvIGluZGljYXRvLicpO1xuICAgIH1cbiAgICBjb25zdCB7IGRhdGE6IHZlcnNpb24gfSA9IGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS5zZWxlY3QoJ2lkLCBjb250ZW50X21kJykuZXEoJ2NoYXB0ZXJfaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCkub3JkZXIoJ3ZlcnNpb25fbm8nLCB7XG4gICAgICAgIGFzY2VuZGluZzogZmFsc2VcbiAgICB9KS5saW1pdCgxKS5tYXliZVNpbmdsZSgpO1xuICAgIGlmICghdmVyc2lvbikgdGhyb3cgbmV3IEVycm9yKCdJbCBjYXBpdG9sbyBub24gaGEgYWxjdW5hIHZlcnNpb25lIGRhIGFuYWxpenphcmUuJyk7XG4gICAgY29uc3QgYW5hbHlzaXMgPSBhbmFseXplTWFya2Rvd24odmVyc2lvbi5jb250ZW50X21kKTtcbiAgICBjb25zdCBpc0luY3JlbWVudGFsID0gYW5hbHlzaXMuY29kZUJsb2Nrcy5zb21lKChibG9jayk9PntcbiAgICAgICAgY29uc3QgY29uZmlnID0gZXh0cmFjdENvbmZpZ0Jsb2NrKGJsb2NrLmNvbnRlbnQpO1xuICAgICAgICByZXR1cm4gY29uZmlnICE9PSBudWxsICYmIC9cXGJ0eXBlXFxzKjpcXHMqW1wiJ11pbmNyZW1lbnRhbFtcIiddLy50ZXN0KGNvbmZpZyk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY2hhcHRlcjoge1xuICAgICAgICAgICAgY2hhcHRlcklkOiBjaGFwdGVyLmlkLFxuICAgICAgICAgICAgbnVtYmVyOiBjaGFwdGVyLm51bWJlcixcbiAgICAgICAgICAgIHRpdGxlOiBjaGFwdGVyLnRpdGxlLFxuICAgICAgICAgICAgY29udGVudE1kOiB2ZXJzaW9uLmNvbnRlbnRfbWQsXG4gICAgICAgICAgICBoZWFkaW5nczogYW5hbHlzaXMuaGVhZGluZ3MubWFwKChoKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgbGV2ZWw6IGgubGV2ZWwsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGgudGV4dCxcbiAgICAgICAgICAgICAgICAgICAgbGluZTogaC5saW5lXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgY29kZUJsb2NrczogYW5hbHlzaXMuY29kZUJsb2Nrcy5tYXAoKGIpPT4oe1xuICAgICAgICAgICAgICAgICAgICBsYW5ndWFnZTogYi5sYW5ndWFnZSxcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogYi5jb250ZW50LFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBiLmxpbmVcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBsaW5rczogYW5hbHlzaXMubGlua3MsXG4gICAgICAgICAgICBmaWd1cmVzOiBhbmFseXNpcy5maWd1cmVzLm1hcCgoZik9Pih7XG4gICAgICAgICAgICAgICAgICAgIGFsdDogZi5hbHQsXG4gICAgICAgICAgICAgICAgICAgIHNyYzogZi5zcmMsXG4gICAgICAgICAgICAgICAgICAgIGxpbmU6IGYubGluZVxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyczogYW5hbHlzaXMucGxhY2Vob2xkZXJzLm1hcCgocCk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBwLmxpbmVcbiAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgfSxcbiAgICAgICAgdmVyc2lvbklkOiB2ZXJzaW9uLmlkLFxuICAgICAgICBpc0luY3JlbWVudGFsXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMS1iaXMgXHUwMEI3IFN0ZXN1cmEgZGVsIGNhcGl0b2xvXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQ29tcG9uZSBpbCBjYXBpdG9sbyBkYWxsZSBwYXJ0aS5cbiAqXG4gKiBMJ2Fzc2VtYmxhZ2dpbyBcdTAwRTggY29kaWNlLCBub24gdW4ndWx0ZXJpb3JlIHJpY2hpZXN0YSBhbCBtb2RlbGxvOiBsJ29yZGluZVxuICogZGVsbGUgc2V6aW9uaSwgbGEgbnVtZXJhemlvbmUgZSBsYSBmb3JtYSBkZWxsJ2FwcGFyYXRvIHNvbm8gZGVjaXNpb25pXG4gKiBlZGl0b3JpYWxpIGdpXHUwMEUwIHByZXNlLCBlIGZhcmxlIHJpZXNlZ3VpcmUgYSB1biBtb2RlbGxvIGxlIHJlbmRlcmViYmUgaW5jZXJ0ZVxuICogYSBvZ25pIGVzZWN1emlvbmUuXG4gKi8gZnVuY3Rpb24gY29tcG9uaUNhcGl0b2xvKG51bWVybywgdGl0b2xvLCBvYmlldHRpdmksIGNvcnBvLCBhcHBhcmF0bykge1xuICAgIGNvbnN0IHBhcnRpID0gW1xuICAgICAgICBgIyAke251bWVybyAhPT0gbnVsbCA/IGBDYXBpdG9sbyAke251bWVyb30gLSBgIDogJyd9JHt0aXRvbG99YCxcbiAgICAgICAgJycsXG4gICAgICAgICc+ICoqT0JJRVRUSVZJIERFTCBDQVBJVE9MTyoqJyxcbiAgICAgICAgJz4nLFxuICAgICAgICAuLi5vYmlldHRpdmkubWFwKChvYmlldHRpdm8pPT5gPiAtICR7b2JpZXR0aXZvfWApLFxuICAgICAgICAnJyxcbiAgICAgICAgY29ycG8sXG4gICAgICAgICcnXG4gICAgXTtcbiAgICBpZiAoYXBwYXJhdG8uYmVzdFByYWN0aWNlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHBhcnRpLnB1c2goJyMjIEJlc3QgcHJhY3RpY2UnLCAnJywgLi4uYXBwYXJhdG8uYmVzdFByYWN0aWNlcy5tYXAoKHZvY2UpPT5gLSAke3ZvY2V9YCksICcnKTtcbiAgICB9XG4gICAgaWYgKGFwcGFyYXRvLmNvbW1vbkVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHBhcnRpLnB1c2goJyMjIEVycm9yaSBjb211bmknLCAnJywgLi4uYXBwYXJhdG8uY29tbW9uRXJyb3JzLm1hcCgodm9jZSk9PmAtICR7dm9jZX1gKSwgJycpO1xuICAgIH1cbiAgICBwYXJ0aS5wdXNoKCcjIyBSaWFzc3VudG8nLCAnJywgYXBwYXJhdG8uc3VtbWFyeSwgJycpO1xuICAgIHBhcnRpLnB1c2goJyMjIFB1bnRpIGNoaWF2ZScsICcnLCAuLi5hcHBhcmF0by5rZXlQb2ludHMubWFwKCh2b2NlKT0+YC0gJHt2b2NlfWApLCAnJyk7XG4gICAgaWYgKGFwcGFyYXRvLnF1aXoubGVuZ3RoID4gMCkge1xuICAgICAgICBwYXJ0aS5wdXNoKCcjIyBRdWl6JywgJycsICdQZXIgb2duaSBkb21hbmRhIHVuYSBzb2xhIHJpc3Bvc3RhIFx1MDBFOCBjb3JyZXR0YS4nLCAnJyk7XG4gICAgICAgIGFwcGFyYXRvLnF1aXouZm9yRWFjaCgoZG9tYW5kYSwgaW5kaWNlKT0+e1xuICAgICAgICAgICAgcGFydGkucHVzaChgJHtpbmRpY2UgKyAxfS4gKioke2RvbWFuZGEucXVlc3Rpb259KipgLCAnJyk7XG4gICAgICAgICAgICBkb21hbmRhLm9wdGlvbnMuZm9yRWFjaCgob3B6aW9uZSwgaSk9PntcbiAgICAgICAgICAgICAgICBwYXJ0aS5wdXNoKGAgICAke1N0cmluZy5mcm9tQ2hhckNvZGUoOTcgKyBpKX0pICR7b3B6aW9uZX1gKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcGFydGkucHVzaCgnJyk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBMZSBzb2x1emlvbmkgc3Rhbm5vIGluIGZvbmRvIGUgbm9uIGFjY2FudG8gYWxsYSBkb21hbmRhOiB1biBxdWl6IGNvbiBsYVxuICAgICAgICAvLyByaXNwb3N0YSBhIHZpc3RhIG5vbiB2ZXJpZmljYSBudWxsYS5cbiAgICAgICAgcGFydGkucHVzaCgnKipTb2x1emlvbmk6KiogJyArIGFwcGFyYXRvLnF1aXoubWFwKChkb21hbmRhLCBpbmRpY2UpPT5gJHtpbmRpY2UgKyAxfS0ke1N0cmluZy5mcm9tQ2hhckNvZGUoOTcgKyBkb21hbmRhLmNvcnJlY3QpfWApLmpvaW4oJywgJyksICcnKTtcbiAgICB9XG4gICAgaWYgKGFwcGFyYXRvLmxhYi50cmltKCkpIHBhcnRpLnB1c2goJyMjIExhYm9yYXRvcmlvJywgJycsIGFwcGFyYXRvLmxhYi50cmltKCksICcnKTtcbiAgICAvLyBOZXNzdW5hIHNlemlvbmUgZGkgcmlmZXJpbWVudGk6IGxlIGZvbnRpIGRlbGwnb3BlcmEgc3Rhbm5vIHR1dHRlIG5lbFxuICAgIC8vIGNhcGl0b2xvIGRpIGJpYmxpb2dyYWZpYSwgZG92ZSBzaSBhZ2dpb3JuYW5vIGluIHVuIHBvc3RvIHNvbG8gaW52ZWNlIGNoZVxuICAgIC8vIGluIHRyZW50YSBjb2RlIGRpIGNhcGl0b2xvLlxuICAgIHJldHVybiBwYXJ0aS5qb2luKCdcXG4nKTtcbn1cbi8qKlxuICogU2NyaXZlIGlsIGNhcGl0b2xvIHBlciBpbnRlcm8gcHJpbWEgY2hlIGwnYXVkaXQgbG8gZXNhbWluaS5cbiAqXG4gKiBMJ29yZGluZSBub24gXHUwMEU4IHVuIGRldHRhZ2xpbzogdmVyaWZpY2FyZSB1biBzZWduYXBvc3RvIHNpZ25pZmljYSB2ZXJpZmljYXJlXG4gKiBuaWVudGUsIGUgY2hpZWRlcmUgdW4nYXBwcm92YXppb25lIHN1IHRyZW50YWNpbnF1ZSBwYXJvbGUgc2lnbmlmaWNhIGNoaWVkZXJlXG4gKiBhIHVuYSBwZXJzb25hIGRpIGRlY2lkZXJlIHN1bCBudWxsYS5cbiAqXG4gKiBMYSBzdGVzdXJhIGF2dmllbmUgaW4gdHJlIHBhc3NhZ2dpIFx1MjAxNCBwaWFubywgc2V6aW9uaSwgYXBwYXJhdG8gXHUyMDE0IHBlcmNoXHUwMEU5IHVuXG4gKiBjYXBpdG9sbyBjb21wbGV0byBub24gZW50cmEgaW4gdW5hIHJpc3Bvc3RhIHNvbGE6IGNoaWVkZXJsbyBpbiB1bmEgdm9sdGFcbiAqIHByb2R1Y2UgdW4gY2FwaXRvbG8gY2hlIHNpIGFjY29yY2lhIGRhIHNvbG8gcGVyIHN0YXJjaSBkZW50cm8uXG4gKlxuICogTGEgdmVyc2lvbmUgY3JlYXRhIHF1aSBub24gc29zdGl0dWlzY2UgcXVlbGxhIGRpIHBhcnRlbnphOiBkaXZlbnRhIGxhXG4gKiBjb3JyZW50ZSwgbWEgaWwgc2VnbmFwb3N0byByZXN0YSBjb21lIHJhZGljZSBkZWxsYSBjYXRlbmEsIGVkIFx1MDBFOCBxdWVsbG8gY2hlIGlsXG4gKiByZXZpc29yZSB2ZWRyXHUwMEUwIGEgc2luaXN0cmEgbmVsIGNvbmZyb250by5cbiAqLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gZHJhZnRDaGFwdGVyKGNvbnRleHQsIGNoYXB0ZXIsIGJhc2VWZXJzaW9uSWQpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgW3sgZGF0YTogY2hhcHRlclJvdyB9LCB7IGRhdGE6IHByb2plY3QgfV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIGRiLmZyb20oJ2NoYXB0ZXJzJykuc2VsZWN0KCdwYXJ0X2lkJykuZXEoJ2lkJywgY29udGV4dC5jaGFwdGVySWQpLm1heWJlU2luZ2xlKCksXG4gICAgICAgIGRiLmZyb20oJ3Byb2plY3RzJykuc2VsZWN0KCdsYW5ndWFnZSwgbGV2ZWwsIHRvbmUsIHJlZ2lzdGVyLCBzdHlsZV9ub3Rlcywgd29ya19zaGFwZSwgdGFyZ2V0X3BhZ2VzLCBzY29wZSwgb3V0X29mX3Njb3BlLCBhdWRpZW5jZScpLmVxKCdpZCcsIGNvbnRleHQucHJvamVjdElkKS5tYXliZVNpbmdsZSgpXG4gICAgXSk7XG4gICAgY29uc3QgeyBkYXRhOiBwYXJ0IH0gPSBjaGFwdGVyUm93Py5wYXJ0X2lkID8gYXdhaXQgZGIuZnJvbSgncHVibGljYXRpb25fcGFydHMnKS5zZWxlY3QoJ3RpdGxlJykuZXEoJ2lkJywgY2hhcHRlclJvdy5wYXJ0X2lkKS5tYXliZVNpbmdsZSgpIDoge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgfTtcbiAgICAvLyBMZSBzdGVzc2UgZm9udGkgY2hlIGhhbm5vIHByb2RvdHRvIGxhIHN0cnV0dHVyYSBwcm9kdWNvbm8gaWwgdGVzdG86IHVuXG4gICAgLy8gY2FwaXRvbG8gbm9uIHB1XHUwMEYyIHBvZ2dpYXJlIHN1IG1hdGVyaWFsZSBjaGUgbCdpbmRpY2Ugbm9uIGNvbm9zY2V2YS5cbiAgICBjb25zdCBbeyBkYXRhOiByZWZlcmVuY2VzIH0sIHsgZGF0YTogcmVmZXJlbmNlQ2h1bmtzIH0sIHsgZGF0YTogc291cmNlQ2h1bmtzIH1dID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBkYi5mcm9tKCdyZWZlcmVuY2Vfc291cmNlcycpLnNlbGVjdCgndGl0bGUsIHB1Ymxpc2hlciwgdXJsJykub3IoYHByb2plY3RfaWQuZXEuJHtjb250ZXh0LnByb2plY3RJZH0scHJvamVjdF9pZC5pcy5udWxsYCkubmVxKCdzdGF0dXMnLCAncHJvcG9zZWQnKS5saW1pdCg2MCksXG4gICAgICAgIGRiLmZyb20oJ3JlZmVyZW5jZV9jaHVua3MnKS5zZWxlY3QoJ2hlYWRpbmcsIGNvbnRlbnQnKS5vcihgcHJvamVjdF9pZC5lcS4ke2NvbnRleHQucHJvamVjdElkfSxwcm9qZWN0X2lkLmlzLm51bGxgKS5vcmRlcignY2h1bmtfaW5kZXgnLCB7XG4gICAgICAgICAgICBhc2NlbmRpbmc6IHRydWVcbiAgICAgICAgfSkubGltaXQoMTIwKSxcbiAgICAgICAgZGIuZnJvbSgnc291cmNlX2NodW5rcycpLnNlbGVjdCgnaGVhZGluZ19wYXRoLCBjb250ZW50JykuZXEoJ3Byb2plY3RfaWQnLCBjb250ZXh0LnByb2plY3RJZCkub3JkZXIoJ2NodW5rX2luZGV4Jywge1xuICAgICAgICAgICAgYXNjZW5kaW5nOiB0cnVlXG4gICAgICAgIH0pLmxpbWl0KDEyMClcbiAgICBdKTtcbiAgICBjb25zdCBldmlkZW5jZSA9IFtcbiAgICAgICAgLi4uKHJlZmVyZW5jZUNodW5rcyA/PyBbXSkubWFwKChibG9jY28pPT5gJHtibG9jY28uaGVhZGluZyA/IGAjIyAke2Jsb2Njby5oZWFkaW5nfVxcbmAgOiAnJ30ke2Jsb2Njby5jb250ZW50fWApLFxuICAgICAgICAuLi4oc291cmNlQ2h1bmtzID8/IFtdKS5tYXAoKGJsb2Njbyk9PmAke2Jsb2Njby5oZWFkaW5nX3BhdGg/Lmxlbmd0aCA/IGAjIyAke2Jsb2Njby5oZWFkaW5nX3BhdGguam9pbignID4gJyl9XFxuYCA6ICcnfSR7YmxvY2NvLmNvbnRlbnR9YClcbiAgICBdLmpvaW4oJ1xcblxcbicpLnNsaWNlKDAsIDYwXzAwMCk7XG4gICAgLy8gTCdvYmlldHRpdm8gXHUwMEU4IGNpXHUwMEYyIGNoZSBsYSBmYXNlIGRpIHN0cnV0dHVyYSBoYSBwcm9tZXNzbyBwZXIgcXVlc3RvIGNhcGl0b2xvLlxuICAgIGNvbnN0IG9iaWV0dGl2byA9IGNoYXB0ZXIuY29udGVudE1kLm1hdGNoKC8jI1xccypPYmlldHRpdm9cXHMqXFxuKyhbXFxzXFxTXSo/KSg/OlxcbiN7MSwyfVxcc3wkKS9pKTtcbiAgICAvLyBRdWFudGkgY2FwaXRvbGkgc2kgZGl2aWRvbm8gaWwgYnVkZ2V0OiBxdWVsbGkgZGkgY2hpdXN1cmEgZ2VuZXJhdGkgZGFcbiAgICAvLyBjb2RpY2Ugbm9uIGNvbnN1bWFubyBxdW90YSwgcGVyY2hcdTAwRTkgbm9uIGxpIHNjcml2ZSB1biBtb2RlbGxvLlxuICAgIGNvbnN0IHsgY291bnQ6IGNhcGl0b2xpVG90YWxpIH0gPSBhd2FpdCBkYi5mcm9tKCdjaGFwdGVycycpLnNlbGVjdCgnaWQnLCB7XG4gICAgICAgIGNvdW50OiAnZXhhY3QnLFxuICAgICAgICBoZWFkOiB0cnVlXG4gICAgfSkuZXEoJ3Byb2plY3RfaWQnLCBjb250ZXh0LnByb2plY3RJZCkubmVxKCdraW5kJywgJ2JhY2tfbWF0dGVyJyk7XG4gICAgY29uc3QgYnVkZ2V0T3BlcmEgPSBidWRnZXRQYXJvbGUocHJvamVjdD8udGFyZ2V0X3BhZ2VzID8/IG51bGwpO1xuICAgIGNvbnN0IGJ1ZGdldENhcGl0b2xvID0gYnVkZ2V0T3BlcmEgIT09IG51bGwgJiYgKGNhcGl0b2xpVG90YWxpID8/IDApID4gMCA/IE1hdGgucm91bmQoYnVkZ2V0T3BlcmEgLyAoY2FwaXRvbGlUb3RhbGkgPz8gMSkpIDogbnVsbDtcbiAgICBjb25zdCBpbmdyZXNzbyA9IHtcbiAgICAgICAgY2hhcHRlcklkOiBjaGFwdGVyLmNoYXB0ZXJJZCxcbiAgICAgICAgbnVtYmVyOiBjaGFwdGVyLm51bWJlcixcbiAgICAgICAgdGl0bGU6IGNoYXB0ZXIudGl0bGUsXG4gICAgICAgIG9iamVjdGl2ZTogKG9iaWV0dGl2bz8uWzFdID8/ICcnKS50cmltKCkuc2xpY2UoMCwgMjAwMCksXG4gICAgICAgIHBhcnRUaXRsZTogcGFydD8udGl0bGUgPz8gbnVsbCxcbiAgICAgICAgbGFuZ3VhZ2U6IHByb2plY3Q/Lmxhbmd1YWdlID8/ICdpdCcsXG4gICAgICAgIC8vIFNlbnphIHF1ZXN0bywgdHJlIHZvbHVtaSBzdWxsbyBzdGVzc28gYXJnb21lbnRvIHByb2R1cnJlYmJlcm8gbG8gc3Rlc3NvXG4gICAgICAgIC8vIGNhcGl0b2xvIGNvbiB0cmUgdGl0b2xpIGRpdmVyc2kuXG4gICAgICAgIGRpcmV6aW9uZTogW1xuICAgICAgICAgICAgaXN0cnV6aW9uaUVkaXRvcmlhbGkoe1xuICAgICAgICAgICAgICAgIGxldmVsOiBwcm9qZWN0Py5sZXZlbCA/PyAnYmFzZScsXG4gICAgICAgICAgICAgICAgdG9uZTogcHJvamVjdD8udG9uZSA/PyAnZGlkYXR0aWNvJyxcbiAgICAgICAgICAgICAgICByZWdpc3RlcjogcHJvamVjdD8ucmVnaXN0ZXIgPz8gJ3RlY25pY29fb3BlcmF0aXZvJyxcbiAgICAgICAgICAgICAgICBzdHlsZU5vdGVzOiBwcm9qZWN0Py5zdHlsZV9ub3RlcyA/PyBudWxsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGlzdHJ1emlvbmlCcmllZih7XG4gICAgICAgICAgICAgICAgd29ya1NoYXBlOiBwcm9qZWN0Py53b3JrX3NoYXBlLFxuICAgICAgICAgICAgICAgIHRhcmdldFBhZ2VzOiBwcm9qZWN0Py50YXJnZXRfcGFnZXMsXG4gICAgICAgICAgICAgICAgc2NvcGU6IHByb2plY3Q/LnNjb3BlLFxuICAgICAgICAgICAgICAgIG91dE9mU2NvcGU6IHByb2plY3Q/Lm91dF9vZl9zY29wZSxcbiAgICAgICAgICAgICAgICBhdWRpZW5jZTogcHJvamVjdD8uYXVkaWVuY2VcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgLy8gSWwgYnVkZ2V0IGRlbCB2b2x1bWUgZGl2aXNvIHBlciBpIGNhcGl0b2xpIGNoZSBsbyBjb21wb25nb25vLiBTZW56YSxcbiAgICAgICAgICAgIC8vIFx1MDBBQmNlbnRvIHBhZ2luZVx1MDBCQiByZXN0YSB1bidpbnRlbnppb25lIGRlbGwnZWRpdG9yZSBjaGUgbm9uIHJhZ2dpdW5nZSBtYWlcbiAgICAgICAgICAgIC8vIGNoaSBzY3JpdmUgaWwgc2luZ29sbyBjYXBpdG9sby5cbiAgICAgICAgICAgIGJ1ZGdldENhcGl0b2xvICE9PSBudWxsID8gYC0gUXVlc3RvIGNhcGl0b2xvIGRldmUgYWdnaXJhcnNpIHN1bGxlICR7YnVkZ2V0Q2FwaXRvbG8udG9Mb2NhbGVTdHJpbmcoJ2l0LUlUJyl9IHBhcm9sZSwgYCArICdhcHBhcmF0byBkaSBjaGl1c3VyYSBjb21wcmVzbzogXHUwMEU4IGxhIHF1b3RhIGNoZSBnbGkgc3BldHRhIG5lbCB0b3RhbGUgZGVsbFx1MjAxOW9wZXJhLicgOiAnJ1xuICAgICAgICBdLmZpbHRlcihCb29sZWFuKS5qb2luKCdcXG4nKSxcbiAgICAgICAgcmVmZXJlbmNlczogKHJlZmVyZW5jZXMgPz8gW10pLm1hcCgocmlmZXJpbWVudG8pPT4oe1xuICAgICAgICAgICAgICAgIHRpdGxlOiByaWZlcmltZW50by50aXRsZSxcbiAgICAgICAgICAgICAgICBwdWJsaXNoZXI6IHJpZmVyaW1lbnRvLnB1Ymxpc2hlciA/PyBudWxsLFxuICAgICAgICAgICAgICAgIHVybDogcmlmZXJpbWVudG8udXJsID8/IG51bGxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgZXZpZGVuY2UsXG4gICAgICAgIGV4aXN0aW5nQ29udGVudDogY2hhcHRlci5jb250ZW50TWRcbiAgICB9O1xuICAgIGNvbnN0IGNvbnRlc3RvID0ge1xuICAgICAgICBkYixcbiAgICAgICAgb3JnYW5pemF0aW9uSWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHByb2plY3RJZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIGNoYXB0ZXJJZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHdvcmtmbG93UnVuSWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgc3RlcE5hbWU6ICdzdGVzdXJhLWNhcGl0b2xvJ1xuICAgIH07XG4gICAgY29uc3QgZ2FwcyA9IFtdO1xuICAgIGNvbnN0IHBpYW5vID0gKGF3YWl0IHJ1bkFnZW50KGNoYXB0ZXJQbGFuQWdlbnQsIGluZ3Jlc3NvLCBjb250ZXN0bykpLm91dHB1dDtcbiAgICBjb25zdCBzY2FsZXR0YSA9IHBpYW5vLnNlY3Rpb25zLm1hcCgoc2V6aW9uZSk9PnNlemlvbmUudGl0bGUpO1xuICAgIC8vIFVuYSBzZXppb25lIHBlciB2b2x0YSBlIGluIG9yZGluZTogb2dudW5hIHZlZGUgbGEgc2NhbGV0dGEgaW50ZXJhLCBjb3NcdTAwRUMgbm9uXG4gICAgLy8gcmlwZXRlIGNpXHUwMEYyIGNoZSBcdTAwRTggZ2lcdTAwRTAgc3RhdG8gZGV0dG8gblx1MDBFOSBhbnRpY2lwYSBjaVx1MDBGMiBjaGUgdmVyclx1MDBFMC5cbiAgICBjb25zdCBzZXppb25pID0gW107XG4gICAgZm9yIChjb25zdCBbaW5kaWNlLCBzZXppb25lXSBvZiBwaWFuby5zZWN0aW9ucy5lbnRyaWVzKCkpe1xuICAgICAgICBjb25zdCBzY3JpdHRhID0gKGF3YWl0IHJ1bkFnZW50KGNoYXB0ZXJTZWN0aW9uQWdlbnQsIHtcbiAgICAgICAgICAgIC4uLmluZ3Jlc3NvLFxuICAgICAgICAgICAgc2VjdGlvblRpdGxlOiBzZXppb25lLnRpdGxlLFxuICAgICAgICAgICAgc2VjdGlvbkludGVudDogc2V6aW9uZS5pbnRlbnQsXG4gICAgICAgICAgICBuZWVkc0NvZGU6IHNlemlvbmUubmVlZHNDb2RlLFxuICAgICAgICAgICAgbmVlZHNGaWd1cmU6IHNlemlvbmUubmVlZHNGaWd1cmUsXG4gICAgICAgICAgICBzZWN0aW9uTnVtYmVyOiBpbmRpY2UgKyAxLFxuICAgICAgICAgICAgb3V0bGluZTogc2NhbGV0dGEsXG4gICAgICAgICAgICBvYmplY3RpdmVzOiBwaWFuby5vYmplY3RpdmVzXG4gICAgICAgIH0sIGNvbnRlc3RvKSkub3V0cHV0O1xuICAgICAgICBzZXppb25pLnB1c2goc2NyaXR0YS5jb250ZW50TWQudHJpbSgpKTtcbiAgICAgICAgZ2Fwcy5wdXNoKC4uLnNjcml0dGEuZ2Fwcyk7XG4gICAgfVxuICAgIGNvbnN0IGNvcnBvID0gc2V6aW9uaS5qb2luKCdcXG5cXG4nKTtcbiAgICAvLyBMJ2FwcGFyYXRvIHJpY2V2ZSBpbCBjb3JwbyBnaVx1MDBFMCBzY3JpdHRvOiB1biByaWFzc3VudG8gZGVkb3R0byBkYWxsYSBzY2FsZXR0YVxuICAgIC8vIHJpYXNzdW1lcmViYmUgbGUgaW50ZW56aW9uaSwgbm9uIGlsIGNhcGl0b2xvLlxuICAgIGNvbnN0IGFwcGFyYXRvID0gKGF3YWl0IHJ1bkFnZW50KGNoYXB0ZXJBcHBhcmF0dXNBZ2VudCwge1xuICAgICAgICAuLi5pbmdyZXNzbyxcbiAgICAgICAgb2JqZWN0aXZlczogcGlhbm8ub2JqZWN0aXZlcyxcbiAgICAgICAgb3V0bGluZTogc2NhbGV0dGEsXG4gICAgICAgIGJvZHk6IGNvcnBvXG4gICAgfSwgY29udGVzdG8pKS5vdXRwdXQ7XG4gICAgZ2Fwcy5wdXNoKC4uLmFwcGFyYXRvLmdhcHMpO1xuICAgIGNvbnN0IGNvbnRlbnRNZCA9IGNvbXBvbmlDYXBpdG9sbyhjaGFwdGVyLm51bWJlciwgY2hhcHRlci50aXRsZSwgcGlhbm8ub2JqZWN0aXZlcywgY29ycG8sIGFwcGFyYXRvKTtcbiAgICBjb25zdCB7IGRhdGE6IGxhc3QgfSA9IGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS5zZWxlY3QoJ3ZlcnNpb25fbm8nKS5lcSgnY2hhcHRlcl9pZCcsIGNvbnRleHQuY2hhcHRlcklkKS5vcmRlcigndmVyc2lvbl9ubycsIHtcbiAgICAgICAgYXNjZW5kaW5nOiBmYWxzZVxuICAgIH0pLmxpbWl0KDEpLm1heWJlU2luZ2xlKCk7XG4gICAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoY29udGVudE1kKSk7XG4gICAgY29uc3QgY29udGVudEhhc2ggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpLm1hcCgoYnl0ZSk9PmJ5dGUudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpO1xuICAgIGNvbnN0IGFuYWx5c2lzID0gYW5hbHl6ZU1hcmtkb3duKGNvbnRlbnRNZCk7XG4gICAgY29uc3Qgd29yZENvdW50ID0gY29udGVudE1kLnNwbGl0KC9cXHMrLykuZmlsdGVyKEJvb2xlYW4pLmxlbmd0aDtcbiAgICBjb25zdCB7IGRhdGE6IGNyZWF0ZWQsIGVycm9yIH0gPSBhd2FpdCBkYi5mcm9tKCdjaGFwdGVyX3ZlcnNpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHByb2plY3RfaWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBvcmdhbml6YXRpb25faWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHZlcnNpb25fbm86IChsYXN0Py52ZXJzaW9uX25vID8/IDApICsgMSxcbiAgICAgICAgb3JpZ2luOiAnYWlfcHJvcG9zYWwnLFxuICAgICAgICBjb250ZW50X21kOiBjb250ZW50TWQsXG4gICAgICAgIGNvbnRlbnRfaGFzaDogY29udGVudEhhc2gsXG4gICAgICAgIHN1bW1hcnk6IGBDYXBpdG9sbyBzY3JpdHRvIGluICR7cGlhbm8uc2VjdGlvbnMubGVuZ3RofSBzZXppb25pYCArIGAke2dhcHMubGVuZ3RoID4gMCA/IGAsIGNvbiAke2dhcHMubGVuZ3RofSBwdW50aSBub24gY29wZXJ0aSBkYWxsZSBmb250aWAgOiAnJ30uYCxcbiAgICAgICAgd29yZF9jb3VudDogd29yZENvdW50LFxuICAgICAgICBwYXJlbnRfdmVyc2lvbl9pZDogYmFzZVZlcnNpb25JZCxcbiAgICAgICAgd29ya2Zsb3dfcnVuX2lkOiBjb250ZXh0LndvcmtmbG93UnVuSWRcbiAgICB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XG4gICAgaWYgKGVycm9yIHx8ICFjcmVhdGVkKSB0aHJvdyBuZXcgRXJyb3IoZXJyb3I/Lm1lc3NhZ2UgPz8gJ1N0ZXN1cmEgbm9uIHJlZ2lzdHJhdGEuJyk7XG4gICAgYXdhaXQgZGIuZnJvbSgnY2hhcHRlcnMnKS51cGRhdGUoe1xuICAgICAgICBjdXJyZW50X3ZlcnNpb25faWQ6IGNyZWF0ZWQuaWQsXG4gICAgICAgIHN0YXR1czogJ2luX3JldmlldycsXG4gICAgICAgIHdvcmRfY291bnQ6IHdvcmRDb3VudCxcbiAgICAgICAgY29kZV9ibG9ja19jb3VudDogYW5hbHlzaXMuY29kZUJsb2Nrcy5sZW5ndGgsXG4gICAgICAgIGhlYWRpbmdfY291bnQ6IGFuYWx5c2lzLmhlYWRpbmdzLmxlbmd0aCxcbiAgICAgICAgZmlndXJlX2NvdW50OiBhbmFseXNpcy5maWd1cmVzLmxlbmd0aCxcbiAgICAgICAgcGxhY2Vob2xkZXJfY291bnQ6IGFuYWx5c2lzLnBsYWNlaG9sZGVycy5sZW5ndGgsXG4gICAgICAgIGxpbmtfY291bnQ6IGFuYWx5c2lzLmxpbmtzLmxlbmd0aFxuICAgIH0pLmVxKCdpZCcsIGNvbnRleHQuY2hhcHRlcklkKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBjaGFwdGVyOiB7XG4gICAgICAgICAgICAuLi5jaGFwdGVyLFxuICAgICAgICAgICAgY29udGVudE1kLFxuICAgICAgICAgICAgaGVhZGluZ3M6IGFuYWx5c2lzLmhlYWRpbmdzLm1hcCgoaCk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGxldmVsOiBoLmxldmVsLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBoLnRleHQsXG4gICAgICAgICAgICAgICAgICAgIGxpbmU6IGgubGluZVxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIGNvZGVCbG9ja3M6IGFuYWx5c2lzLmNvZGVCbG9ja3MubWFwKChiKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgbGFuZ3VhZ2U6IGIubGFuZ3VhZ2UsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGIuY29udGVudCxcbiAgICAgICAgICAgICAgICAgICAgbGluZTogYi5saW5lXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgbGlua3M6IGFuYWx5c2lzLmxpbmtzLFxuICAgICAgICAgICAgZmlndXJlczogYW5hbHlzaXMuZmlndXJlcy5tYXAoKGYpPT4oe1xuICAgICAgICAgICAgICAgICAgICBhbHQ6IGYuYWx0LFxuICAgICAgICAgICAgICAgICAgICBzcmM6IGYuc3JjLFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBmLmxpbmVcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBwbGFjZWhvbGRlcnM6IGFuYWx5c2lzLnBsYWNlaG9sZGVycy5tYXAoKHApPT4oe1xuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogcC5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgbGluZTogcC5saW5lXG4gICAgICAgICAgICAgICAgfSkpXG4gICAgICAgIH0sXG4gICAgICAgIHZlcnNpb25JZDogY3JlYXRlZC5pZCxcbiAgICAgICAgZ2FwcyxcbiAgICAgICAgZ3JvdW5kZWQ6IGdhcHMubGVuZ3RoID09PSAwXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMiBcdTAwQjcgQW5hbGlzaSB0ZWNuaWNhIGRlbCBjb2RpY2UgZSBkZWxsZSBhZmZlcm1hemlvbmlcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZlcmlmeVRlY2huaWNhbChjb250ZXh0LCBjaGFwdGVyKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcnVuQWdlbnQodGVjaG5pY2FsVmVyaWZpZXJBZ2VudCwgY2hhcHRlciwge1xuICAgICAgICBkYjogY3JlYXRlQWRtaW5DbGllbnQoKSxcbiAgICAgICAgb3JnYW5pemF0aW9uSWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHByb2plY3RJZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIGNoYXB0ZXJJZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHdvcmtmbG93UnVuSWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgc3RlcE5hbWU6ICd2ZXJpZmljYS10ZWNuaWNhJ1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQub3V0cHV0O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAzIFx1MDBCNyBWZXJpZmljYSBkZWkgcmlmZXJpbWVudGkgZSByaWNlcmNhIGF1dG9tYXRpY2EgZGVsbGUgZm9udGkgbWFuY2FudGlcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBSaWNldmUgbGUgYWZmZXJtYXppb25pIGluZGl2aWR1YXRlIGFsIHBhc3NhZ2dpbyBwcmVjZWRlbnRlOiBzZW56YSBkaSBlc3NlXG4gKiBwb3RyZWJiZSBnaXVkaWNhcmUgbGUgZm9udGkgcHJlc2VudGksIG1hIG5vbiBjZXJjYXJlIHF1ZWxsZSBjaGUgbWFuY2Fuby5cbiAqXG4gKiBTZSBpbCBjYXBpdG9sbyBub24gb2ZmcmUgblx1MDBFOSBjb2xsZWdhbWVudGkgblx1MDBFOSBhZmZlcm1hemlvbmksIGwnYWdlbnRlIG5vbiB2aWVuZVxuICogaW50ZXJwZWxsYXRvOiBjb24gbGUgbWFuaSB2dW90ZSBkZWR1cnJlYmJlIGRhbCB0aXRvbG8gYWZmZXJtYXppb25pIGNoZSBuZWxcbiAqIHRlc3RvIG5vbiBjaSBzb25vLCBlIHVuIGVsZW5jbyB2ZXJvc2ltaWxlIFx1MDBFOCBwZWdnaW8gZGkgdW4gZWxlbmNvIHZ1b3RvIHBlcmNoXHUwMEU5XG4gKiBzZW1icmEgdW4gcmlzdWx0YXRvLlxuICovIGV4cG9ydCBhc3luYyBmdW5jdGlvbiBhdWRpdFNvdXJjZXMoY29udGV4dCwgY2hhcHRlciwgY2xhaW1zKSB7XG4gICAgaWYgKGNoYXB0ZXIubGlua3MubGVuZ3RoID09PSAwICYmIGNsYWltcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNpdGF0aW9uczogW10sXG4gICAgICAgICAgICBzdWdnZXN0aW9uczogW10sXG4gICAgICAgICAgICB1bm1hdGNoZWRDbGFpbXM6IDAsXG4gICAgICAgICAgICBpc3N1ZXM6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGtpbmQ6ICdzb3VyY2UnLFxuICAgICAgICAgICAgICAgICAgICBzZXZlcml0eTogJ2xvdycsXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnQ2FwaXRvbG8gc2VuemEgY29udGVudXRvIHZlcmlmaWNhYmlsZScsXG4gICAgICAgICAgICAgICAgICAgIGRldGFpbDogJ0lsIGNhcGl0b2xvIG5vbiBjb250aWVuZSBjb2xsZWdhbWVudGkgblx1MDBFOSBhZmZlcm1hemlvbmkgdGVjbmljaGUgZGEgc29zdGVuZXJlIGNvbiB1bmEgJyArICdmb250ZS4gTGEgdmVyaWZpY2EgZGVpIHJpZmVyaW1lbnRpIG5vbiBcdTAwRTggc3RhdGEgZXNlZ3VpdGE6IG5vbiBjXHUyMDE5XHUwMEU4IG51bGxhIGRhIHZlcmlmaWNhcmUsICcgKyAnZSBudWxsYSBcdTAwRTggc3RhdG8gZGVkb3R0byBkYWwgdGl0b2xvLicsXG4gICAgICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb246ICdTY3JpdmVyZSBpbCBjYXBpdG9sbywgcG9pIHJpcGV0ZXJlIGxcdTIwMTlhdWRpdC4nLFxuICAgICAgICAgICAgICAgICAgICBsb2NhdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRpbmc6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBleGNlcnB0OiBudWxsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBbXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAvLyBMJ2VzaXRvIG5vbiBcdTAwRTggaW5jZXJ0bzogbCdhc3NlbnphIFx1MDBFOCB1biBmYXR0byBjb25zdGF0YXRvLCBub24gdW5hIHN0aW1hLlxuICAgICAgICAgICAgY29uZmlkZW5jZTogMSxcbiAgICAgICAgICAgIHN1bW1hcnk6ICdOZXNzdW4gY29sbGVnYW1lbnRvIGUgbmVzc3VuYSBhZmZlcm1hemlvbmUgZGEgdmVyaWZpY2FyZTogYXVkaXQgZGVsbGUgZm9udGkgbm9uIGVzZWd1aXRvLidcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcnVuQWdlbnQoc291cmNlQXVkaXRvckFnZW50LCB7XG4gICAgICAgIC4uLmNoYXB0ZXIsXG4gICAgICAgIGNsYWltc1xuICAgIH0sIHtcbiAgICAgICAgZGI6IGNyZWF0ZUFkbWluQ2xpZW50KCksXG4gICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBjaGFwdGVySWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICB3b3JrZmxvd1J1bklkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIHN0ZXBOYW1lOiAndmVyaWZpY2EtZm9udGknXG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc3VsdC5vdXRwdXQ7XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDMtYmlzIFx1MDBCNyBCaWJsaW90ZWNhIGRlbCBwcm9nZXR0b1xuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vKipcbiAqIEFnZ2l1bmdlIGFsbGUgcHJvcG9zdGUgbGUgZm9udGkgY2hlIGwnYXV0b3JlIGhhIGNhcmljYXRvOiBsaW5rIGUgUERGLlxuICpcbiAqIFx1MDBDOCB1biBwYXNzYWdnaW8gYSBzXHUwMEU5IHBlcmNoXHUwMEU5IGwnYWdlbnRlIHJlc3RhIHB1cm8gXHUyMDE0IGludGVycm9nYSBsYSBzb2xhXG4gKiBkb2N1bWVudGF6aW9uZSB1ZmZpY2lhbGUgZSBub24gdG9jY2EgaWwgZGF0YWJhc2UgXHUyMDE0IG1lbnRyZSBsYSBiaWJsaW90ZWNhIHZpdmVcbiAqIG5lbGxlIHRhYmVsbGUgZGVsIHByb2dldHRvLiBMZSBkdWUgcmljZXJjaGUgdXNhbm8gbG8gc3Rlc3NvIGluZGljZSBjb3N0cnVpdG9cbiAqIGluc2llbWUsIHF1aW5kaSBpIHB1bnRlZ2dpIHJlc3Rhbm8gY29uZnJvbnRhYmlsaSBlIGwnb3JkaW5lIGRlaSBjYW5kaWRhdGlcbiAqIHNpZ25pZmljYSBxdWFsY29zYS5cbiAqLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5yaWNoV2l0aExpYnJhcnkoY29udGV4dCwgY2xhaW1zLCBzdWdnZXN0aW9ucykge1xuICAgIGNvbnN0IGRiID0gY3JlYXRlQWRtaW5DbGllbnQoKTtcbiAgICBjb25zdCB7IGluZGV4LCBsaWJyYXJ5RW50cmllcyB9ID0gYXdhaXQgYnVpbGRQcm9qZWN0SW5kZXgoZGIsIGNvbnRleHQub3JnYW5pemF0aW9uSWQsIGNvbnRleHQucHJvamVjdElkKTtcbiAgICAvLyBOZXNzdW5hIGZvbnRlIGNhcmljYXRhOiBub24gYydcdTAwRTggbnVsbGEgZGEgYWdnaXVuZ2VyZSwgZSByaWNhbGNvbGFyZVxuICAgIC8vIHN1bGwnaW5kaWNlIHVmZmljaWFsZSBkYXJlYmJlIGVzYXR0YW1lbnRlIGNpXHUwMEYyIGNoZSBzaSBoYSBnaVx1MDBFMC5cbiAgICBpZiAobGlicmFyeUVudHJpZXMgPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN1Z2dlc3Rpb25zLFxuICAgICAgICAgICAgdW5tYXRjaGVkOiAwLFxuICAgICAgICAgICAgbGlicmFyeUVudHJpZXM6IDBcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgcmVzZWFyY2ggPSByZXNlYXJjaENsYWltcyhjbGFpbXMsIGluZGV4KTtcbiAgICByZXR1cm4ge1xuICAgICAgICBzdWdnZXN0aW9uczogbWVyZ2VTdWdnZXN0aW9ucyhzdWdnZXN0aW9ucywgcmVzZWFyY2guc3VnZ2VzdGlvbnMpLFxuICAgICAgICB1bm1hdGNoZWQ6IHJlc2VhcmNoLnVubWF0Y2hlZCxcbiAgICAgICAgbGlicmFyeUVudHJpZXNcbiAgICB9O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAzLXRlciBcdTAwQjcgVmVyaWZpY2EgZGVpIGNvbGxlZ2FtZW50aSBjaXRhdGlcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBBcHJlIGkgY29sbGVnYW1lbnRpIGRlbCBjYXBpdG9sbyBlIHJpZmVyaXNjZSBjaGUgY29zYSBoYSB0cm92YXRvLlxuICpcbiAqIFNlbnphIHF1ZXN0byBwYXNzYWdnaW8gbCdhdWRpdCBwdVx1MDBGMiBzb2xvIGRpcmUgXHUwMEFCcXVlc3RhIHBhZ2luYSBub24gXHUwMEU4IG5lbCBtaW9cbiAqIGluZGljZVx1MDBCQiwgY2hlIFx1MDBFOCB1bidhZmZlcm1hemlvbmUgc3UgZGkgc1x1MDBFOSwgbm9uIHN1bCBtb25kbzogdW5hIHBhZ2luYSBwdVx1MDBGMlxuICogZXNpc3RlcmUgYmVuaXNzaW1vIHNlbnphIGVzc2VyZSBjZW5zaXRhLiBVbiBzb3NwZXR0byBkZWwgZ2VuZXJlLCBwcmVzZW50YXRvXG4gKiBjb21lIHJpbGlldm8sIGZhIHBlcmRlcmUgdGVtcG8gYWwgcmV2aXNvcmUgZSBcdTIwMTQgcGVnZ2lvIFx1MjAxNCBpbnNlZ25hIGEgbm9uIGZpZGFyc2lcbiAqIGRlaSByaWxpZXZpLlxuICpcbiAqIEFwcmVuZG8gbCdpbmRpcml6em8gbGEgZG9tYW5kYSBjYW1iaWE6IG5vbiBcdTAwQUJsbyBjb25vc2NvP1x1MDBCQiBtYSBcdTAwQUJyaXNwb25kZT9cdTAwQkIuXG4gKiBBbGxhIHByaW1hIG5lc3N1bm8gXHUwMEU4IHRlbnV0byBhIHJpc3BvbmRlcmU7IGFsbGEgc2Vjb25kYSByaXNwb25kZSBpbCB3ZWIuXG4gKi8gZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZlcmlmeUNpdGF0aW9ucyhfY29udGV4dCwgY2l0YXRpb25zKSB7XG4gICAgY29uc3QgZGFDb250cm9sbGFyZSA9IGNpdGF0aW9ucy5maWx0ZXIoKGNpdGF0aW9uKT0+Y2l0YXRpb24udmVyaWZpY2F0aW9uICE9PSAnbm9uX3ZhbGlkYScpO1xuICAgIGlmIChkYUNvbnRyb2xsYXJlLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHtcbiAgICAgICAgaXNzdWVzOiBbXSxcbiAgICAgICAgdmVyaWZpZWQ6IFtdLFxuICAgICAgICBicm9rZW46IDBcbiAgICB9O1xuICAgIGNvbnN0IGVzaXRpID0gYXdhaXQgdmVyaWZ5VXJscyhkYUNvbnRyb2xsYXJlLm1hcCgoY2l0YXRpb24pPT5jaXRhdGlvbi51cmwpKTtcbiAgICBjb25zdCBpc3N1ZXMgPSBbXTtcbiAgICBjb25zdCB2ZXJpZmllZCA9IFtdO1xuICAgIGZvcihsZXQgaSA9IDA7IGkgPCBlc2l0aS5sZW5ndGg7IGkgKz0gMSl7XG4gICAgICAgIGNvbnN0IGVzaXRvID0gZXNpdGlbaV07XG4gICAgICAgIGNvbnN0IGNpdGF0aW9uID0gZGFDb250cm9sbGFyZVtpXTtcbiAgICAgICAgdmVyaWZpZWQucHVzaCh7XG4gICAgICAgICAgICB1cmw6IGNpdGF0aW9uLnVybCxcbiAgICAgICAgICAgIHN0YXR1czogZXNpdG8uc3RhdHVzLFxuICAgICAgICAgICAgb2s6IGVzaXRvLm9rLFxuICAgICAgICAgICAgdGl0bGU6IGVzaXRvLnRpdGxlXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoZXNpdG8ub2spIHtcbiAgICAgICAgICAgIC8vIFBhZ2luYSB1ZmZpY2lhbGUgY2hlIHJpc3BvbmRlIG1hIG5vbiBcdTAwRTggY2Vuc2l0YTogbm9uIFx1MDBFOCB1biBwcm9ibGVtYSBkZWxcbiAgICAgICAgICAgIC8vIGNhcGl0b2xvLCBcdTAwRTggdW5hIGxhY3VuYSBkZWwgbm9zdHJvIGluZGljZS4gVmEgZGV0dG8gY29tZSB0YWxlLlxuICAgICAgICAgICAgaWYgKGNpdGF0aW9uLmlzT2ZmaWNpYWwgJiYgIWNpdGF0aW9uLmluSW5kZXgpIHtcbiAgICAgICAgICAgICAgICBpc3N1ZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIGtpbmQ6ICdzb3VyY2UnLFxuICAgICAgICAgICAgICAgICAgICBzZXZlcml0eTogJ2luZm8nLFxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1BhZ2luYSB1ZmZpY2lhbGUgbm9uIGFuY29yYSBjZW5zaXRhJyxcbiAgICAgICAgICAgICAgICAgICAgZGV0YWlsOiBgJHtjaXRhdGlvbi51cmx9IHJpc3BvbmRlICR7ZXNpdG8uc3RhdHVzfSBlIGlsIHRpdG9sbyBcdTAwRTggXHUwMEFCJHtlc2l0by50aXRsZSA/PyAnXHUyMDE0J31cdTAwQkIuIGAgKyAnSWwgcmlmZXJpbWVudG8gXHUwMEU4IHZhbGlkbzogbWFuY2Egc29sdGFudG8gZGFsbFx1MjAxOWluZGljZSBjdXJhdG8uJyxcbiAgICAgICAgICAgICAgICAgICAgc3VnZ2VzdGlvbjogJ1ZhbHV0YXJlIGxcdTIwMTlhZ2dpdW50YSBhIGNhdGFsb2cuZGF0YS50cyBjb24gbnBtIHJ1biBzb3VyY2VzOnJlZnJlc2guJyxcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmU6IGNpdGF0aW9uLmxpbmUgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRpbmc6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBleGNlcnB0OiBjaXRhdGlvbi51cmxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgZXZpZGVuY2U6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNpdGF0aW9uLnVybFxuICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpc3N1ZXMucHVzaCh7XG4gICAgICAgICAgICBraW5kOiAnc291cmNlJyxcbiAgICAgICAgICAgIHNldmVyaXR5OiAnaGlnaCcsXG4gICAgICAgICAgICB0aXRsZTogJ0NvbGxlZ2FtZW50byBub24gcmFnZ2l1bmdpYmlsZScsXG4gICAgICAgICAgICBkZXRhaWw6IGAke2NpdGF0aW9uLnVybH0gbm9uIHJpc3BvbmRlYCArIChlc2l0by5zdGF0dXMgIT09IG51bGwgPyBgIChzdGF0byAke2VzaXRvLnN0YXR1c30pLmAgOiAnLicpICsgJyBVbiBjb2xsZWdhbWVudG8gbW9ydG8gaW4gdW4gbWFudWFsZSBzdGFtcGF0byBub24gXHUwMEU4IGNvcnJlZ2dpYmlsZS4nLFxuICAgICAgICAgICAgc3VnZ2VzdGlvbjogZXNpdG8ubm90ZSA/PyAnQXByaXJlIGlsIGNvbGxlZ2FtZW50byBlIHNvc3RpdHVpcmxvLicsXG4gICAgICAgICAgICBsb2NhdGlvbjoge1xuICAgICAgICAgICAgICAgIGxpbmU6IGNpdGF0aW9uLmxpbmUgfHwgbnVsbCxcbiAgICAgICAgICAgICAgICBoZWFkaW5nOiBudWxsLFxuICAgICAgICAgICAgICAgIGV4Y2VycHQ6IGNpdGF0aW9uLnVybFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGV2aWRlbmNlOiBbXG4gICAgICAgICAgICAgICAgY2l0YXRpb24udXJsXG4gICAgICAgICAgICBdXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBpc3N1ZXMsXG4gICAgICAgIHZlcmlmaWVkLFxuICAgICAgICBicm9rZW46IGlzc3Vlcy5maWx0ZXIoKGkpPT5pLnNldmVyaXR5ID09PSAnaGlnaCcpLmxlbmd0aFxuICAgIH07XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDQgXHUwMEI3IFBlcnNpc3RlbnphIGRlbGwnYXVkaXRcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBlcnNpc3RBdWRpdChjb250ZXh0LCB0ZWNobmljYWwsIHNvdXJjZXMsIHN1Z2dlc3Rpb25zLCBsaW5rSXNzdWVzLCBsaW5rQ2hlY2tzKSB7XG4gICAgY29uc3QgZGIgPSBjcmVhdGVBZG1pbkNsaWVudCgpO1xuICAgIC8vIElsIHNvc3BldHRvIFx1MDBBQnBhZ2luYSBub24gY2Vuc2l0YVx1MDBCQiB2aWVuZSByaW1vc3NvOiBhbCBzdW8gcG9zdG8gYXJyaXZhIGwnZXNpdG9cbiAgICAvLyBkaSBjaGkgbCdoYSBhcGVydGEgZGF2dmVyby4gVGVuZXJlIGVudHJhbWJpIHNpZ25pZmljaGVyZWJiZSBmYXIgbGVnZ2VyZSBhbFxuICAgIC8vIHJldmlzb3JlIHVuIGR1YmJpbyBlIGxhIHN1YSByaXNwb3N0YSwgbmVsbCdvcmRpbmUgc2JhZ2xpYXRvLlxuICAgIGNvbnN0IHNlbnphU29zcGV0dGkgPSBzb3VyY2VzLmlzc3Vlcy5maWx0ZXIoKGlzc3VlKT0+aXNzdWUudGl0bGUgIT09ICdSaWZlcmltZW50byB1ZmZpY2lhbGUgZGEgdmVyaWZpY2FyZScpO1xuICAgIGNvbnN0IGlzc3VlcyA9IFtcbiAgICAgICAgLi4udGVjaG5pY2FsLmlzc3VlcyxcbiAgICAgICAgLi4uc2VuemFTb3NwZXR0aSxcbiAgICAgICAgLi4ubGlua0lzc3Vlc1xuICAgIF0ubWFwKChpc3N1ZSk9Pih7XG4gICAgICAgICAgICAuLi5pc3N1ZSxcbiAgICAgICAgICAgIC8vIFx1MDBBQnJpZ2EgMFx1MDBCQiBub24gZXNpc3RlOiBsZSByaWdoZSBwYXJ0b25vIGRhIDEuIFVubyB6ZXJvIHNpZ25pZmljYSBcdTAwQUJub25cbiAgICAgICAgICAgIC8vIGRldGVybWluYXRhXHUwMEJCLCBlIGRpcmxvIGNvc1x1MDBFQyBldml0YSBkaSBtYW5kYXJlIGlsIHJldmlzb3JlIGEgY2VyY2FyZSBpbCBudWxsYS5cbiAgICAgICAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgICAgICAgICAgLi4uaXNzdWUubG9jYXRpb24sXG4gICAgICAgICAgICAgICAgbGluZTogaXNzdWUubG9jYXRpb24ubGluZSA9PT0gMCA/IG51bGwgOiBpc3N1ZS5sb2NhdGlvbi5saW5lXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICAvLyBVbmEgcmllc2VjdXppb25lIHNvc3RpdHVpc2NlIGkgcmlsaWV2aSBkZWwgd29ya2Zsb3cgcHJlY2VkZW50ZSwgbm9uIHF1ZWxsaVxuICAgIC8vIGRpIGFsdHJlIGVzZWN1emlvbmk6IGlsIGZpbHRybyBcdTAwRTggc3VsbCdpZGVudGlmaWNhdGl2byBkZWwgcnVuLlxuICAgIGF3YWl0IGRiLmZyb20oJ3ZlcmlmaWNhdGlvbl9pc3N1ZXMnKS5kZWxldGUoKS5lcSgnd29ya2Zsb3dfcnVuX2lkJywgY29udGV4dC53b3JrZmxvd1J1bklkKTtcbiAgICBpZiAoaXNzdWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3Qgcm93cyA9IGlzc3Vlcy5tYXAoKGlzc3VlKT0+KHtcbiAgICAgICAgICAgICAgICBwcm9qZWN0X2lkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgICAgICAgICBvcmdhbml6YXRpb25faWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgICAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgICAgICAgICAgd29ya2Zsb3dfcnVuX2lkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgICAgICAgICAga2luZDogaXNzdWUua2luZCxcbiAgICAgICAgICAgICAgICBzZXZlcml0eTogaXNzdWUuc2V2ZXJpdHksXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAnb3BlbicsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGlzc3VlLnRpdGxlLFxuICAgICAgICAgICAgICAgIGRldGFpbDogaXNzdWUuZGV0YWlsLFxuICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb246IGlzc3VlLnN1Z2dlc3Rpb24sXG4gICAgICAgICAgICAgICAgbG9jYXRpb246IGlzc3VlLmxvY2F0aW9uLFxuICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBpc3N1ZS5ldmlkZW5jZVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICBmb3IobGV0IGkgPSAwOyBpIDwgcm93cy5sZW5ndGg7IGkgKz0gMTAwKXtcbiAgICAgICAgICAgIGF3YWl0IGRiLmZyb20oJ3ZlcmlmaWNhdGlvbl9pc3N1ZXMnKS5pbnNlcnQocm93cy5zbGljZShpLCBpICsgMTAwKSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gTGUgY2l0YXppb25pIGRpdmVudGFubyByaWdoZSBjb25zdWx0YWJpbGkgZSByaWNvbnRyb2xsYWJpbGkgbmVsIHRlbXBvLlxuICAgIGF3YWl0IGRiLmZyb20oJ2NpdGF0aW9ucycpLmRlbGV0ZSgpLmVxKCdjaGFwdGVyX2lkJywgY29udGV4dC5jaGFwdGVySWQpO1xuICAgIGlmIChzb3VyY2VzLmNpdGF0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgYXdhaXQgZGIuZnJvbSgnY2l0YXRpb25zJykuaW5zZXJ0KHNvdXJjZXMuY2l0YXRpb25zLm1hcCgoY2l0YXRpb24pPT4oe1xuICAgICAgICAgICAgICAgIHByb2plY3RfaWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbl9pZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgICAgICAgICBjaGFwdGVyX2lkOiBjb250ZXh0LmNoYXB0ZXJJZCxcbiAgICAgICAgICAgICAgICB1cmw6IGNpdGF0aW9uLnVybCxcbiAgICAgICAgICAgICAgICB0aXRsZTogY2l0YXRpb24uaW5kZXhlZFRpdGxlID8/IGNpdGF0aW9uLnRleHQgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICBwdWJsaXNoZXI6IGNpdGF0aW9uLmRvbWFpbiB8fCBudWxsLFxuICAgICAgICAgICAgICAgIGlzX29mZmljaWFsOiBjaXRhdGlvbi5pc09mZmljaWFsLFxuICAgICAgICAgICAgICAgIG5vdGU6IGNpdGF0aW9uLm5vdGUsXG4gICAgICAgICAgICAgICAgLy8gT3JhIGBpc19yZWFjaGFibGVgIGRpY2UgY2lcdTAwRjIgY2hlIGRvdnJlYmJlIGRpcmU6IHNlIGxhIHBhZ2luYSBoYVxuICAgICAgICAgICAgICAgIC8vIHJpc3Bvc3RvIHF1YW5kbyBcdTAwRTggc3RhdGEgYXBlcnRhLiBOdWxsbyBzb2xvIHBlciBjaVx1MDBGMiBjaGUgbm9uIFx1MDBFOCBzdGF0b1xuICAgICAgICAgICAgICAgIC8vIGludGVycm9nYXRvLlxuICAgICAgICAgICAgICAgIGh0dHBfc3RhdHVzOiBsaW5rQ2hlY2tzLmZpbmQoKGMpPT5jLnVybCA9PT0gY2l0YXRpb24udXJsKT8uc3RhdHVzID8/IG51bGwsXG4gICAgICAgICAgICAgICAgaXNfcmVhY2hhYmxlOiBsaW5rQ2hlY2tzLmZpbmQoKGMpPT5jLnVybCA9PT0gY2l0YXRpb24udXJsKT8ub2sgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICBsYXN0X2NoZWNrZWRfYXQ6IG5vd1xuICAgICAgICAgICAgfSkpKTtcbiAgICB9XG4gICAgLy8gTGUgZm9udGkgcHJvcG9zdGUgcmVzdGFubyByaWdoZSBkaXN0aW50ZTogdW5hIHByb3Bvc3RhIG5vbiBcdTAwRTggdW5hIGNpdGF6aW9uZVxuICAgIC8vIGZpbmNoXHUwMEU5IHF1YWxjdW5vIG5vbiBsJ2FjY2V0dGEuXG4gICAgYXdhaXQgZGIuZnJvbSgnc291cmNlX3N1Z2dlc3Rpb25zJykuZGVsZXRlKCkuZXEoJ3dvcmtmbG93X3J1bl9pZCcsIGNvbnRleHQud29ya2Zsb3dSdW5JZCk7XG4gICAgY29uc3Qgc3VnZ2VzdGlvblJvd3MgPSBzdWdnZXN0aW9ucy5mbGF0TWFwKChzdWdnZXN0aW9uKT0+c3VnZ2VzdGlvbi5jYW5kaWRhdGVzLm1hcCgoY2FuZGlkYXRlLCBpbmRleCk9Pih7XG4gICAgICAgICAgICAgICAgcHJvamVjdF9pZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uX2lkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICAgICAgICAgIGNoYXB0ZXJfaWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICAgICAgICAgIHdvcmtmbG93X3J1bl9pZDogY29udGV4dC53b3JrZmxvd1J1bklkLFxuICAgICAgICAgICAgICAgIGNsYWltX2xpbmU6IHN1Z2dlc3Rpb24ubGluZSxcbiAgICAgICAgICAgICAgICBjbGFpbV9leGNlcnB0OiBzdWdnZXN0aW9uLnN0YXRlbWVudCxcbiAgICAgICAgICAgICAgICBjYXRlZ29yeTogc3VnZ2VzdGlvbi5jYXRlZ29yeSxcbiAgICAgICAgICAgICAgICB1cmw6IGNhbmRpZGF0ZS51cmwsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGNhbmRpZGF0ZS50aXRsZSxcbiAgICAgICAgICAgICAgICBzZWN0aW9uOiBjYW5kaWRhdGUuc2VjdGlvbixcbiAgICAgICAgICAgICAgICBzY29yZTogY2FuZGlkYXRlLnNjb3JlLFxuICAgICAgICAgICAgICAgIHJhbms6IGluZGV4ICsgMSxcbiAgICAgICAgICAgICAgICBtYXRjaGVkX3Rlcm1zOiBjYW5kaWRhdGUubWF0Y2hlZFRlcm1zLFxuICAgICAgICAgICAgICAgIG9yaWdpbjogY2FuZGlkYXRlLm9yaWdpbixcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VfaWQ6IGNhbmRpZGF0ZS5yZWZlcmVuY2VJZCxcbiAgICAgICAgICAgICAgICBwYWdlOiBjYW5kaWRhdGUucGFnZSxcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdwcm9wb3NlZCdcbiAgICAgICAgICAgIH0pKSk7XG4gICAgZm9yKGxldCBpID0gMDsgaSA8IHN1Z2dlc3Rpb25Sb3dzLmxlbmd0aDsgaSArPSAxMDApe1xuICAgICAgICBhd2FpdCBkYi5mcm9tKCdzb3VyY2Vfc3VnZ2VzdGlvbnMnKS5pbnNlcnQoc3VnZ2VzdGlvblJvd3Muc2xpY2UoaSwgaSArIDEwMCkpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBpc3N1ZUNvdW50OiBpc3N1ZXMubGVuZ3RoLFxuICAgICAgICBjcml0aWNhbDogaXNzdWVzLmZpbHRlcigoaSk9Pmkuc2V2ZXJpdHkgPT09ICdjcml0aWNhbCcpLmxlbmd0aCxcbiAgICAgICAgaGlnaDogaXNzdWVzLmZpbHRlcigoaSk9Pmkuc2V2ZXJpdHkgPT09ICdoaWdoJykubGVuZ3RoLFxuICAgICAgICBzdWdnZXN0aW9uczogc3VnZ2VzdGlvbnMubGVuZ3RoXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gNSBcdTAwQjcgUHJvcG9zdGEgZGkgcmV2aXNpb25lIFx1MjAxNCBtYWkgdW5hIHNvdnJhc2NyaXR0dXJhXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcm9wb3NlUmV2aXNpb24oY29udGV4dCwgY2hhcHRlciwgaXNzdWVzLCBzdWdnZXN0aW9ucywgYmFzZVZlcnNpb25JZCkge1xuICAgIGNvbnN0IGRiID0gY3JlYXRlQWRtaW5DbGllbnQoKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBydW5BZ2VudCh0ZWNobmljYWxXcml0ZXJBZ2VudCwge1xuICAgICAgICAuLi5jaGFwdGVyLFxuICAgICAgICBpc3N1ZXMsXG4gICAgICAgIHN1Z2dlc3Rpb25zXG4gICAgfSwge1xuICAgICAgICBkYixcbiAgICAgICAgb3JnYW5pemF0aW9uSWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHByb2plY3RJZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIGNoYXB0ZXJJZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHdvcmtmbG93UnVuSWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgc3RlcE5hbWU6ICdwcm9wb3N0YS1yZXZpc2lvbmUnXG4gICAgfSk7XG4gICAgY29uc3QgcmV2aXNpb24gPSByZXN1bHQub3V0cHV0O1xuICAgIC8vIE5lc3N1biBpbnRlcnZlbnRvOiBub24gc2kgY3JlYSB1bmEgdmVyc2lvbmUgaWRlbnRpY2EgYWxsJ29yaWdpbmFsZS5cbiAgICBpZiAocmV2aXNpb24uY2hhbmdlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHZlcnNpb25JZDogbnVsbCxcbiAgICAgICAgICAgIGNoYW5nZUNvdW50OiAwLFxuICAgICAgICAgICAgc3VtbWFyeTogcmV2aXNpb24uc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB7IGRhdGE6IGxhc3QgfSA9IGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS5zZWxlY3QoJ3ZlcnNpb25fbm8nKS5lcSgnY2hhcHRlcl9pZCcsIGNvbnRleHQuY2hhcHRlcklkKS5vcmRlcigndmVyc2lvbl9ubycsIHtcbiAgICAgICAgYXNjZW5kaW5nOiBmYWxzZVxuICAgIH0pLmxpbWl0KDEpLm1heWJlU2luZ2xlKCk7XG4gICAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocmV2aXNpb24uY29udGVudE1kKSk7XG4gICAgY29uc3QgY29udGVudEhhc2ggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpLm1hcCgoYik9PmIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpLmpvaW4oJycpO1xuICAgIGNvbnN0IHsgZGF0YTogY3JlYXRlZCwgZXJyb3IgfSA9IGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS5pbnNlcnQoe1xuICAgICAgICBjaGFwdGVyX2lkOiBjb250ZXh0LmNoYXB0ZXJJZCxcbiAgICAgICAgcHJvamVjdF9pZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIG9yZ2FuaXphdGlvbl9pZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgdmVyc2lvbl9ubzogKGxhc3Q/LnZlcnNpb25fbm8gPz8gMCkgKyAxLFxuICAgICAgICBvcmlnaW46ICdhaV9wcm9wb3NhbCcsXG4gICAgICAgIGNvbnRlbnRfbWQ6IHJldmlzaW9uLmNvbnRlbnRNZCxcbiAgICAgICAgY29udGVudF9oYXNoOiBjb250ZW50SGFzaCxcbiAgICAgICAgc3VtbWFyeTogcmV2aXNpb24uc3VtbWFyeSxcbiAgICAgICAgd29yZF9jb3VudDogcmV2aXNpb24uY29udGVudE1kLnNwbGl0KC9cXHMrLykuZmlsdGVyKEJvb2xlYW4pLmxlbmd0aCxcbiAgICAgICAgcGFyZW50X3ZlcnNpb25faWQ6IGJhc2VWZXJzaW9uSWQsXG4gICAgICAgIHdvcmtmbG93X3J1bl9pZDogY29udGV4dC53b3JrZmxvd1J1bklkLFxuICAgICAgICBhZ2VudF9ydW5faWQ6IHJlc3VsdC5hZ2VudFJ1bklkLFxuICAgICAgICBjcmVhdGVkX2J5OiBjb250ZXh0LmFjdG9ySWRcbiAgICB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XG4gICAgaWYgKGVycm9yIHx8ICFjcmVhdGVkKSB0aHJvdyBuZXcgRXJyb3IoYFNhbHZhdGFnZ2lvIGRlbGxhIHByb3Bvc3RhIGZhbGxpdG86ICR7ZXJyb3I/Lm1lc3NhZ2UgPz8gJyd9YCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdmVyc2lvbklkOiBjcmVhdGVkLmlkLFxuICAgICAgICBjaGFuZ2VDb3VudDogcmV2aXNpb24uY2hhbmdlcy5sZW5ndGgsXG4gICAgICAgIHN1bW1hcnk6IHJldmlzaW9uLnN1bW1hcnlcbiAgICB9O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyA2IFx1MDBCNyBQaWFubyB2aXN1YWxlXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwbGFuVmlzdWFscyhjb250ZXh0LCBjaGFwdGVyLCBkYXRhZm9ybVJlZnMpIHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBydW5BZ2VudCh2aXN1YWxQbGFuQWdlbnQsIHtcbiAgICAgICAgLi4uY2hhcHRlcixcbiAgICAgICAgZGF0YWZvcm1SZWZzXG4gICAgfSwge1xuICAgICAgICBkYjogY3JlYXRlQWRtaW5DbGllbnQoKSxcbiAgICAgICAgb3JnYW5pemF0aW9uSWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHByb2plY3RJZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIGNoYXB0ZXJJZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHdvcmtmbG93UnVuSWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgc3RlcE5hbWU6ICdwaWFuby12aXN1YWxlJ1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQub3V0cHV0O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyA3IFx1MDBCNyBEaWFncmFtbWkgZGV0ZXJtaW5pc3RpY2lcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRGlhZ3JhbXMoY29udGV4dCwgY2hhcHRlclRpdGxlLCBkYXRhZm9ybVJlZnMsIGlzSW5jcmVtZW50YWwpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgZGlhZ3JhbSA9IGJ1aWxkRGVwZW5kZW5jeURhZyh7XG4gICAgICAgIHRhcmdldDogY2hhcHRlclRpdGxlLFxuICAgICAgICBkZXBlbmRlbmNpZXM6IGRhdGFmb3JtUmVmcyxcbiAgICAgICAgaXNJbmNyZW1lbnRhbFxuICAgIH0pO1xuICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IGRiLmZyb20oJ3Zpc3VhbF9hc3NldHMnKS5zZWxlY3QoJ3ZlcnNpb24nKS5lcSgnY2hhcHRlcl9pZCcsIGNvbnRleHQuY2hhcHRlcklkKS5lcSgna2luZCcsICdkaWFncmFtJykub3JkZXIoJ3ZlcnNpb24nLCB7XG4gICAgICAgIGFzY2VuZGluZzogZmFsc2VcbiAgICB9KS5saW1pdCgxKS5tYXliZVNpbmdsZSgpO1xuICAgIGNvbnN0IHsgZGF0YTogYXNzZXQsIGVycm9yIH0gPSBhd2FpdCBkYi5mcm9tKCd2aXN1YWxfYXNzZXRzJykuaW5zZXJ0KHtcbiAgICAgICAgcHJvamVjdF9pZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIG9yZ2FuaXphdGlvbl9pZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIGtpbmQ6ICdkaWFncmFtJyxcbiAgICAgICAgZ2VuZXJhdG9yOiAnbWVybWFpZCcsXG4gICAgICAgIC8vIEFuY2hlIHVuIGRpYWdyYW1tYSBlc2F0dG8gcmljaGllZGUgbCdvY2NoaW8gdW1hbm8gcHJpbWEgZGkgZmluaXJlIG5lbCBsaWJyby5cbiAgICAgICAgc3RhdHVzOiAncGVuZGluZ19hcHByb3ZhbCcsXG4gICAgICAgIHZlcnNpb246IChleGlzdGluZz8udmVyc2lvbiA/PyAwKSArIDEsXG4gICAgICAgIHRpdGxlOiBkaWFncmFtLnRpdGxlLFxuICAgICAgICBjYXB0aW9uOiBkaWFncmFtLmNhcHRpb24sXG4gICAgICAgIGFsdF90ZXh0OiBkaWFncmFtLmFsdFRleHQsXG4gICAgICAgIG1lcm1haWRfc291cmNlOiBkaWFncmFtLm1lcm1haWQsXG4gICAgICAgIGNyZWF0ZWRfYnk6IGNvbnRleHQuYWN0b3JJZFxuICAgIH0pLnNlbGVjdCgnaWQnKS5zaW5nbGUoKTtcbiAgICBpZiAoZXJyb3IgfHwgIWFzc2V0KSB0aHJvdyBuZXcgRXJyb3IoYFNhbHZhdGFnZ2lvIGRlbCBkaWFncmFtbWEgZmFsbGl0bzogJHtlcnJvcj8ubWVzc2FnZSA/PyAnJ31gKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBhc3NldElkczogW1xuICAgICAgICAgICAgYXNzZXQuaWRcbiAgICAgICAgXSxcbiAgICAgICAgbWVybWFpZDogZGlhZ3JhbS5tZXJtYWlkXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gOCBcdTAwQjcgUmljaGllc3RhIGRpIGFwcHJvdmF6aW9uZVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVxdWVzdEFwcHJvdmFsKGNvbnRleHQsIGJhc2VWZXJzaW9uSWQsIHByb3Bvc2VkVmVyc2lvbklkLCByZXN1bWVUb2tlbiwgc3VtbWFyeSkge1xuICAgIGNvbnN0IGRiID0gY3JlYXRlQWRtaW5DbGllbnQoKTtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBkYi5mcm9tKCdyZXZpZXdfcmVxdWVzdHMnKS5pbnNlcnQoe1xuICAgICAgICBwcm9qZWN0X2lkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgb3JnYW5pemF0aW9uX2lkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBjaGFwdGVyX2lkOiBjb250ZXh0LmNoYXB0ZXJJZCxcbiAgICAgICAgd29ya2Zsb3dfcnVuX2lkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIGJhc2VfdmVyc2lvbl9pZDogYmFzZVZlcnNpb25JZCxcbiAgICAgICAgcHJvcG9zZWRfdmVyc2lvbl9pZDogcHJvcG9zZWRWZXJzaW9uSWQsXG4gICAgICAgIHN0YXR1czogJ3BlbmRpbmcnLFxuICAgICAgICB0aXRsZTogJ1JldmlzaW9uZSBwcm9wb3N0YSBkYWxsXHUyMDE5YXVkaXQgdGVjbmljbycsXG4gICAgICAgIHN1bW1hcnksXG4gICAgICAgIHJlc3VtZV90b2tlbjogcmVzdW1lVG9rZW4sXG4gICAgICAgIHJlcXVlc3RlZF9ieTogY29udGV4dC5hY3RvcklkXG4gICAgfSkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xuICAgIGlmIChlcnJvciB8fCAhZGF0YSkgdGhyb3cgbmV3IEVycm9yKGBDcmVhemlvbmUgZGVsbGEgcmljaGllc3RhIGRpIHJldmlzaW9uZSBmYWxsaXRhOiAke2Vycm9yPy5tZXNzYWdlID8/ICcnfWApO1xuICAgIGF3YWl0IGRiLmZyb20oJ3dvcmtmbG93X3J1bnMnKS51cGRhdGUoe1xuICAgICAgICBzdGF0dXM6ICdhd2FpdGluZ19hcHByb3ZhbCcsXG4gICAgICAgIGN1cnJlbnRfc3RlcDogJ2F0dGVzYS1hcHByb3ZhemlvbmUnXG4gICAgfSkuZXEoJ2lkJywgY29udGV4dC53b3JrZmxvd1J1bklkKTtcbiAgICBhd2FpdCBkYi5mcm9tKCdjaGFwdGVycycpLnVwZGF0ZSh7XG4gICAgICAgIHN0YXR1czogJ2luX3JldmlldydcbiAgICB9KS5lcSgnaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCk7XG4gICAgcmV0dXJuIGRhdGEuaWQ7XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDkgXHUwMEI3IEVzaXRvIGRlbGxhIGRlY2lzaW9uZSB1bWFuYVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwbHlEZWNpc2lvbihjb250ZXh0LCByZXZpZXdSZXF1ZXN0SWQsIF9wcm9wb3NlZFZlcnNpb25JZEF0Q3JlYXRpb24sIGRlY2lzaW9uLCBub3RlLCBkZWNpZGVkQnkpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIC8vIExhIHByb3Bvc3RhIHZpZW5lIHJpbGV0dGEgYWRlc3NvLCBub24gdXNhdGEgY29tZSBlcmEgYWwgbW9tZW50byBkZWxsYVxuICAgIC8vIHJpY2hpZXN0YTogZnJhIGkgZHVlIGlzdGFudGkgaWwgcmV2aXNvcmUgcHVcdTAwRjIgYXZlciBhY2NldHRhdG8gc29sbyBhbGN1bmVcbiAgICAvLyBtb2RpZmljaGUgbyBpbnRlcnZlbnV0byBhIG1hbm8sIGdlbmVyYW5kbyB1bmEgdmVyc2lvbmUgZGl2ZXJzYS5cbiAgICBjb25zdCB7IGRhdGE6IGN1cnJlbnQgfSA9IGF3YWl0IGRiLmZyb20oJ3Jldmlld19yZXF1ZXN0cycpLnNlbGVjdCgncHJvcG9zZWRfdmVyc2lvbl9pZCcpLmVxKCdpZCcsIHJldmlld1JlcXVlc3RJZCkubWF5YmVTaW5nbGUoKTtcbiAgICBjb25zdCBwcm9wb3NlZFZlcnNpb25JZCA9IGN1cnJlbnQ/LnByb3Bvc2VkX3ZlcnNpb25faWQgPz8gX3Byb3Bvc2VkVmVyc2lvbklkQXRDcmVhdGlvbjtcbiAgICBhd2FpdCBkYi5mcm9tKCdyZXZpZXdfcmVxdWVzdHMnKS51cGRhdGUoe1xuICAgICAgICBzdGF0dXM6IGRlY2lzaW9uLFxuICAgICAgICBkZWNpZGVkX2F0OiBub3csXG4gICAgICAgIGRlY2lkZWRfYnk6IGRlY2lkZWRCeSxcbiAgICAgICAgZGVjaXNpb25fbm90ZTogbm90ZVxuICAgIH0pLmVxKCdpZCcsIHJldmlld1JlcXVlc3RJZCk7XG4gICAgaWYgKGRlY2lzaW9uICE9PSAnYXBwcm92ZWQnIHx8ICFwcm9wb3NlZFZlcnNpb25JZCkge1xuICAgICAgICBhd2FpdCBkYi5mcm9tKCdjaGFwdGVycycpLnVwZGF0ZSh7XG4gICAgICAgICAgICBzdGF0dXM6ICdkcmFmdCdcbiAgICAgICAgfSkuZXEoJ2lkJywgY29udGV4dC5jaGFwdGVySWQpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYXBwcm92ZWRWZXJzaW9uSWQ6IG51bGxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gTGEgcHJvcG9zdGEgYXBwcm92YXRhIGRpdmVudGEgbGEgdmVyc2lvbmUgY29ycmVudGUuIEwnb3JpZ2luYWxlIHJlc3RhXG4gICAgLy8gaW50YXR0bzogXHUwMEU4IHVuYSByaWdhIGRpc3RpbnRhLCBwcm90ZXR0YSBkYSB0cmlnZ2VyLlxuICAgIGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS51cGRhdGUoe1xuICAgICAgICBvcmlnaW46ICdhcHByb3ZlZCcsXG4gICAgICAgIGlzX2FwcHJvdmVkOiB0cnVlLFxuICAgICAgICBhcHByb3ZlZF9ieTogZGVjaWRlZEJ5LFxuICAgICAgICBhcHByb3ZlZF9hdDogbm93XG4gICAgfSkuZXEoJ2lkJywgcHJvcG9zZWRWZXJzaW9uSWQpO1xuICAgIGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJzJykudXBkYXRlKHtcbiAgICAgICAgY3VycmVudF92ZXJzaW9uX2lkOiBwcm9wb3NlZFZlcnNpb25JZCxcbiAgICAgICAgc3RhdHVzOiAnYXBwcm92ZWQnXG4gICAgfSkuZXEoJ2lkJywgY29udGV4dC5jaGFwdGVySWQpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGFwcHJvdmVkVmVyc2lvbklkOiBwcm9wb3NlZFZlcnNpb25JZFxuICAgIH07XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIEFnZ2lvcm5hbWVudG8gZGVsbG8gc3RhdG8gZGkgYXZhbnphbWVudG9cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hcmtTdGVwKHdvcmtmbG93UnVuSWQsIHN0ZXAsIGNvbXBsZXRlZCwgdG90YWwpIHtcbiAgICBhd2FpdCBjcmVhdGVBZG1pbkNsaWVudCgpLmZyb20oJ3dvcmtmbG93X3J1bnMnKS51cGRhdGUoe1xuICAgICAgICBjdXJyZW50X3N0ZXA6IHN0ZXAsXG4gICAgICAgIGNvbXBsZXRlZF9zdGVwczogY29tcGxldGVkLFxuICAgICAgICB0b3RhbF9zdGVwczogdG90YWwsXG4gICAgICAgIHN0YXR1czogJ3J1bm5pbmcnXG4gICAgfSkuZXEoJ2lkJywgd29ya2Zsb3dSdW5JZCk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmluaXNoUnVuKHdvcmtmbG93UnVuSWQsIHN0YXR1cywgb3V0cHV0LCBlcnJvcikge1xuICAgIGF3YWl0IGNyZWF0ZUFkbWluQ2xpZW50KCkuZnJvbSgnd29ya2Zsb3dfcnVucycpLnVwZGF0ZSh7XG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgb3V0cHV0LFxuICAgICAgICBlcnJvcixcbiAgICAgICAgZmluaXNoZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKVxuICAgIH0pLmVxKCdpZCcsIHdvcmtmbG93UnVuSWQpO1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAxMSBcdTAwQjcgQW50ZXByaW1hIGRlbCB2b2x1bWVcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBBZ2dpdW5nZSBpbCBjYXBpdG9sbyBhcHBlbmEgY29udmFsaWRhdG8gYWxsJ2FudGVwcmltYSBkZWwgdm9sdW1lLlxuICpcbiAqIFx1MDBDOCBsJ3VsdGltbyBwYXNzYWdnaW8sIGUgbm9uIFx1MDBFOCB1bidlc3BvcnRhemlvbmU6IFx1MDBFOCBpbCBtb21lbnRvIGluIGN1aSBpbCBsYXZvcm9cbiAqIGFwcGVuYSBhcHByb3ZhdG8gc21ldHRlIGRpIGVzc2VyZSB1biBjYXBpdG9sbyBhIHNcdTAwRTkgZSBkaXZlbnRhIHBhcnRlIGRlbCBsaWJyby5cbiAqIFZlZGVyZSBpbCB2b2x1bWUgY3Jlc2NlcmUgZG9wbyBvZ25pIGFwcHJvdmF6aW9uZSBcdTAwRTggY2lcdTAwRjIgY2hlIHJlbmRlIHZpc2liaWxlIGlsXG4gKiBwcm9ncmVzc28gXHUyMDE0IHVuIGVsZW5jbyBkaSBjYXBpdG9saSBhcHByb3ZhdGkgbm9uIGxvIG1vc3RyYSBhbGxvIHN0ZXNzbyBtb2RvLlxuICpcbiAqIElsIGZhbGxpbWVudG8gcXVpIG5vbiBhbm51bGxhIGwnYXBwcm92YXppb25lOiBsYSBkZWNpc2lvbmUgdW1hbmEgXHUwMEU4IGdpXHUwMEUwIHByZXNhXG4gKiBlIHJlZ2lzdHJhdGEsIGUgdW4gUERGIGNoZSBub24gc2kgY29tcG9uZSBcdTAwRTggdW4gaW5jb252ZW5pZW50ZSwgbm9uIHVuIG1vdGl2b1xuICogcGVyIHJpbWV0dGVyZSBpbiBkaXNjdXNzaW9uZSBjaVx1MDBGMiBjaGUgdW5hIHBlcnNvbmEgaGEgZGVjaXNvLlxuICovIGV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVWb2x1bWVQcmV2aWV3KGNvbnRleHQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBlc2l0byA9IGF3YWl0IHJlYnVpbGRWb2x1bWVQcmV2aWV3V2l0aChjcmVhdGVBZG1pbkNsaWVudCgpLCB7XG4gICAgICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICAgICAgb3JnYW5pemF0aW9uSWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgICAgICBhY3RvcklkOiBjb250ZXh0LmFjdG9ySWRcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBvazogZXNpdG8ub2ssXG4gICAgICAgICAgICBjaGFwdGVyczogZXNpdG8uY2hhcHRlcnMgPz8gMCxcbiAgICAgICAgICAgIHdvcmRzOiBlc2l0by53b3JkcyA/PyAwLFxuICAgICAgICAgICAgbWVzc2FnZTogZXNpdG8ubWVzc2FnZVxuICAgICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICBjaGFwdGVyczogMCxcbiAgICAgICAgICAgIHdvcmRzOiAwLFxuICAgICAgICAgICAgbWVzc2FnZTogYEFudGVwcmltYSBub24gYWdnaW9ybmF0YTogJHtlcnJvci5tZXNzYWdlfWBcbiAgICAgICAgfTtcbiAgICB9XG59XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9sb2FkQ2hhcHRlclwiLCBsb2FkQ2hhcHRlcik7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9kcmFmdENoYXB0ZXJcIiwgZHJhZnRDaGFwdGVyKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3ZlcmlmeVRlY2huaWNhbFwiLCB2ZXJpZnlUZWNobmljYWwpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vYXVkaXRTb3VyY2VzXCIsIGF1ZGl0U291cmNlcyk7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9lbnJpY2hXaXRoTGlicmFyeVwiLCBlbnJpY2hXaXRoTGlicmFyeSk7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy92ZXJpZnlDaXRhdGlvbnNcIiwgdmVyaWZ5Q2l0YXRpb25zKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3BlcnNpc3RBdWRpdFwiLCBwZXJzaXN0QXVkaXQpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vcHJvcG9zZVJldmlzaW9uXCIsIHByb3Bvc2VSZXZpc2lvbik7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9wbGFuVmlzdWFsc1wiLCBwbGFuVmlzdWFscyk7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9nZW5lcmF0ZURpYWdyYW1zXCIsIGdlbmVyYXRlRGlhZ3JhbXMpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vcmVxdWVzdEFwcHJvdmFsXCIsIHJlcXVlc3RBcHByb3ZhbCk7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9hcHBseURlY2lzaW9uXCIsIGFwcGx5RGVjaXNpb24pO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vbWFya1N0ZXBcIiwgbWFya1N0ZXApO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZmluaXNoUnVuXCIsIGZpbmlzaFJ1bik7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy91cGRhdGVWb2x1bWVQcmV2aWV3XCIsIHVwZGF0ZVZvbHVtZVByZXZpZXcpO1xuIiwgIlxuICAgIC8vIEJ1aWx0IGluIHN0ZXBzXG4gICAgaW1wb3J0ICd3b3JrZmxvdy9pbnRlcm5hbC9idWlsdGlucyc7XG4gICAgLy8gVXNlciBzdGVwc1xuICAgIGltcG9ydCAnLi9ub2RlX21vZHVsZXMvd29ya2Zsb3cvZGlzdC9zdGRsaWIuanMnO1xuaW1wb3J0ICcuL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy50cyc7XG4gICAgLy8gU2VyZGUgZmlsZXMgZm9yIGNyb3NzLWNvbnRleHQgY2xhc3MgcmVnaXN0cmF0aW9uXG4gICAgXG4gICAgLy8gQVBJIGVudHJ5cG9pbnRcbiAgICBleHBvcnQgeyBzdGVwRW50cnlwb2ludCBhcyBIRUFELCBzdGVwRW50cnlwb2ludCBhcyBQT1NUIH0gZnJvbSAnd29ya2Zsb3cvcnVudGltZSc7Il0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7OztBQUFBLFNBQUEsNEJBQUE7QUFTRSxlQUFXLGtDQUFBO0FBQ1gsU0FBTyxLQUFLLFlBQVc7QUFDekI7QUFGYTtBQUliLGVBQXNCLDBCQUF1QjtBQUMzQyxTQUFBLEtBQVcsS0FBQTs7QUFEUztBQUd0QixlQUFDLDBCQUFBO0FBRUQsU0FBTyxLQUFLLEtBQUE7O0FBRlg7cUJBSWlCLG1DQUFHLCtCQUFBO0FBQ3JCLHFCQUFDLDJCQUFBLHVCQUFBOzs7O0FDckJELFNBQUEsd0JBQUFBLDZCQUFBO0FBYUEsZUFBc0IsU0FBa0QsTUFBQTtBQUN0RSxTQUFBLFdBQVcsTUFBQSxHQUFBLElBQUE7O0FBRFM7QUFHdEJDLHNCQUFDLCtCQUFBLEtBQUE7OztBQ2hCRCxTQUFTLHdCQUFBQyw2QkFBNEI7QUFFckMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUIsa0JBQWtCLHFCQUFxQixvQkFBb0Isd0JBQXdCLHNCQUFzQix1QkFBdUI7QUFDaEssU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyw0QkFBNEI7QUFDckMsU0FBUyxjQUFjLHVCQUF1QjtBQUM5QyxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLGtCQUFrQixzQkFBc0I7QUFDakQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUywwQkFBMEI7QUFDbkMsU0FBUywwQkFBMEI7QUFLbkMsZUFBc0IsWUFBWSxTQUFTO0FBQ3ZDLFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxFQUFFLE1BQU0sU0FBUyxNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssVUFBVSxFQUFFLE9BQU8sb0VBQW9FLEVBQUUsR0FBRyxNQUFNLFFBQVEsU0FBUyxFQUFFLE9BQU87QUFDM0ssTUFBSSxTQUFTLENBQUMsUUFBUyxPQUFNLElBQUksTUFBTSx1QkFBdUI7QUFHOUQsTUFBSSxRQUFRLG9CQUFvQixRQUFRLGtCQUFrQixRQUFRLGVBQWUsUUFBUSxXQUFXO0FBQ2hHLFVBQU0sSUFBSSxNQUFNLGtEQUFrRDtBQUFBLEVBQ3RFO0FBQ0EsUUFBTSxFQUFFLE1BQU0sUUFBUSxJQUFJLE1BQU0sR0FBRyxLQUFLLGtCQUFrQixFQUFFLE9BQU8sZ0JBQWdCLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUyxFQUFFLE1BQU0sY0FBYztBQUFBLElBQ3pJLFdBQVc7QUFBQSxFQUNmLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRSxZQUFZO0FBQ3hCLE1BQUksQ0FBQyxRQUFTLE9BQU0sSUFBSSxNQUFNLG1EQUFtRDtBQUNqRixRQUFNLFdBQVcsZ0JBQWdCLFFBQVEsVUFBVTtBQUNuRCxRQUFNLGdCQUFnQixTQUFTLFdBQVcsS0FBSyxDQUFDLFVBQVE7QUFDcEQsVUFBTSxTQUFTLG1CQUFtQixNQUFNLE9BQU87QUFDL0MsV0FBTyxXQUFXLFFBQVEsbUNBQW1DLEtBQUssTUFBTTtBQUFBLEVBQzVFLENBQUM7QUFDRCxTQUFPO0FBQUEsSUFDSCxTQUFTO0FBQUEsTUFDTCxXQUFXLFFBQVE7QUFBQSxNQUNuQixRQUFRLFFBQVE7QUFBQSxNQUNoQixPQUFPLFFBQVE7QUFBQSxNQUNmLFdBQVcsUUFBUTtBQUFBLE1BQ25CLFVBQVUsU0FBUyxTQUFTLElBQUksQ0FBQyxPQUFLO0FBQUEsUUFDOUIsT0FBTyxFQUFFO0FBQUEsUUFDVCxNQUFNLEVBQUU7QUFBQSxRQUNSLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLE1BQ04sWUFBWSxTQUFTLFdBQVcsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUNsQyxVQUFVLEVBQUU7QUFBQSxRQUNaLFNBQVMsRUFBRTtBQUFBLFFBQ1gsTUFBTSxFQUFFO0FBQUEsTUFDWixFQUFFO0FBQUEsTUFDTixPQUFPLFNBQVM7QUFBQSxNQUNoQixTQUFTLFNBQVMsUUFBUSxJQUFJLENBQUMsT0FBSztBQUFBLFFBQzVCLEtBQUssRUFBRTtBQUFBLFFBQ1AsS0FBSyxFQUFFO0FBQUEsUUFDUCxNQUFNLEVBQUU7QUFBQSxNQUNaLEVBQUU7QUFBQSxNQUNOLGNBQWMsU0FBUyxhQUFhLElBQUksQ0FBQyxPQUFLO0FBQUEsUUFDdEMsYUFBYSxFQUFFO0FBQUEsUUFDZixNQUFNLEVBQUU7QUFBQSxNQUNaLEVBQUU7QUFBQSxJQUNWO0FBQUEsSUFDQSxXQUFXLFFBQVE7QUFBQSxJQUNuQjtBQUFBLEVBQ0o7QUFDSjtBQWhEc0I7QUEyRGxCLFNBQVMsZ0JBQWdCLFFBQVEsUUFBUSxXQUFXLE9BQU8sVUFBVTtBQUNyRSxRQUFNLFFBQVE7QUFBQSxJQUNWLEtBQUssV0FBVyxPQUFPLFlBQVksTUFBTSxRQUFRLEVBQUUsR0FBRyxNQUFNO0FBQUEsSUFDNUQ7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsR0FBRyxVQUFVLElBQUksQ0FBQyxjQUFZLE9BQU8sU0FBUyxFQUFFO0FBQUEsSUFDaEQ7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0o7QUFDQSxNQUFJLFNBQVMsY0FBYyxTQUFTLEdBQUc7QUFDbkMsVUFBTSxLQUFLLG9CQUFvQixJQUFJLEdBQUcsU0FBUyxjQUFjLElBQUksQ0FBQyxTQUFPLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRTtBQUFBLEVBQzdGO0FBQ0EsTUFBSSxTQUFTLGFBQWEsU0FBUyxHQUFHO0FBQ2xDLFVBQU0sS0FBSyxvQkFBb0IsSUFBSSxHQUFHLFNBQVMsYUFBYSxJQUFJLENBQUMsU0FBTyxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUU7QUFBQSxFQUM1RjtBQUNBLFFBQU0sS0FBSyxnQkFBZ0IsSUFBSSxTQUFTLFNBQVMsRUFBRTtBQUNuRCxRQUFNLEtBQUssbUJBQW1CLElBQUksR0FBRyxTQUFTLFVBQVUsSUFBSSxDQUFDLFNBQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFO0FBQ3BGLE1BQUksU0FBUyxLQUFLLFNBQVMsR0FBRztBQUMxQixVQUFNLEtBQUssV0FBVyxJQUFJLHFEQUFrRCxFQUFFO0FBQzlFLGFBQVMsS0FBSyxRQUFRLENBQUMsU0FBUyxXQUFTO0FBQ3JDLFlBQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLFFBQVEsUUFBUSxNQUFNLEVBQUU7QUFDdkQsY0FBUSxRQUFRLFFBQVEsQ0FBQyxTQUFTLE1BQUk7QUFDbEMsY0FBTSxLQUFLLE1BQU0sT0FBTyxhQUFhLEtBQUssQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO0FBQUEsTUFDOUQsQ0FBQztBQUNELFlBQU0sS0FBSyxFQUFFO0FBQUEsSUFDakIsQ0FBQztBQUdELFVBQU0sS0FBSyxvQkFBb0IsU0FBUyxLQUFLLElBQUksQ0FBQyxTQUFTLFdBQVMsR0FBRyxTQUFTLENBQUMsSUFBSSxPQUFPLGFBQWEsS0FBSyxRQUFRLE9BQU8sQ0FBQyxFQUFFLEVBQUUsS0FBSyxJQUFJLEdBQUcsRUFBRTtBQUFBLEVBQ3BKO0FBQ0EsTUFBSSxTQUFTLElBQUksS0FBSyxFQUFHLE9BQU0sS0FBSyxrQkFBa0IsSUFBSSxTQUFTLElBQUksS0FBSyxHQUFHLEVBQUU7QUFJakYsU0FBTyxNQUFNLEtBQUssSUFBSTtBQUMxQjtBQXJDYTtBQW9EVCxlQUFzQixhQUFhLFNBQVMsU0FBUyxlQUFlO0FBQ3BFLFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxDQUFDLEVBQUUsTUFBTSxXQUFXLEdBQUcsRUFBRSxNQUFNLFFBQVEsQ0FBQyxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQUEsSUFDaEUsR0FBRyxLQUFLLFVBQVUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTLEVBQUUsWUFBWTtBQUFBLElBQzlFLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTyx1R0FBdUcsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTLEVBQUUsWUFBWTtBQUFBLEVBQ2hMLENBQUM7QUFDRCxRQUFNLEVBQUUsTUFBTSxLQUFLLElBQUksWUFBWSxVQUFVLE1BQU0sR0FBRyxLQUFLLG1CQUFtQixFQUFFLE9BQU8sT0FBTyxFQUFFLEdBQUcsTUFBTSxXQUFXLE9BQU8sRUFBRSxZQUFZLElBQUk7QUFBQSxJQUN6SSxNQUFNO0FBQUEsRUFDVjtBQUdBLFFBQU0sQ0FBQyxFQUFFLE1BQU0sV0FBVyxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsR0FBRyxFQUFFLE1BQU0sYUFBYSxDQUFDLElBQUksTUFBTSxRQUFRLElBQUk7QUFBQSxJQUNoRyxHQUFHLEtBQUssbUJBQW1CLEVBQUUsT0FBTyx1QkFBdUIsRUFBRSxHQUFHLGlCQUFpQixRQUFRLFNBQVMscUJBQXFCLEVBQUUsSUFBSSxVQUFVLFVBQVUsRUFBRSxNQUFNLEVBQUU7QUFBQSxJQUMzSixHQUFHLEtBQUssa0JBQWtCLEVBQUUsT0FBTyxrQkFBa0IsRUFBRSxHQUFHLGlCQUFpQixRQUFRLFNBQVMscUJBQXFCLEVBQUUsTUFBTSxlQUFlO0FBQUEsTUFDcEksV0FBVztBQUFBLElBQ2YsQ0FBQyxFQUFFLE1BQU0sR0FBRztBQUFBLElBQ1osR0FBRyxLQUFLLGVBQWUsRUFBRSxPQUFPLHVCQUF1QixFQUFFLEdBQUcsY0FBYyxRQUFRLFNBQVMsRUFBRSxNQUFNLGVBQWU7QUFBQSxNQUM5RyxXQUFXO0FBQUEsSUFDZixDQUFDLEVBQUUsTUFBTSxHQUFHO0FBQUEsRUFDaEIsQ0FBQztBQUNELFFBQU0sV0FBVztBQUFBLElBQ2IsSUFBSSxtQkFBbUIsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFTLEdBQUcsT0FBTyxVQUFVLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFBTyxFQUFFLEdBQUcsT0FBTyxPQUFPLEVBQUU7QUFBQSxJQUM3RyxJQUFJLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVMsR0FBRyxPQUFPLGNBQWMsU0FBUyxNQUFNLE9BQU8sYUFBYSxLQUFLLEtBQUssQ0FBQztBQUFBLElBQU8sRUFBRSxHQUFHLE9BQU8sT0FBTyxFQUFFO0FBQUEsRUFDNUksRUFBRSxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsR0FBTTtBQUU5QixRQUFNLFlBQVksUUFBUSxVQUFVLE1BQU0saURBQWlEO0FBRzNGLFFBQU0sRUFBRSxPQUFPLGVBQWUsSUFBSSxNQUFNLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTyxNQUFNO0FBQUEsSUFDckUsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLEVBQ1YsQ0FBQyxFQUFFLEdBQUcsY0FBYyxRQUFRLFNBQVMsRUFBRSxJQUFJLFFBQVEsYUFBYTtBQUNoRSxRQUFNLGNBQWMsYUFBYSxTQUFTLGdCQUFnQixJQUFJO0FBQzlELFFBQU0saUJBQWlCLGdCQUFnQixTQUFTLGtCQUFrQixLQUFLLElBQUksS0FBSyxNQUFNLGVBQWUsa0JBQWtCLEVBQUUsSUFBSTtBQUM3SCxRQUFNLFdBQVc7QUFBQSxJQUNiLFdBQVcsUUFBUTtBQUFBLElBQ25CLFFBQVEsUUFBUTtBQUFBLElBQ2hCLE9BQU8sUUFBUTtBQUFBLElBQ2YsWUFBWSxZQUFZLENBQUMsS0FBSyxJQUFJLEtBQUssRUFBRSxNQUFNLEdBQUcsR0FBSTtBQUFBLElBQ3RELFdBQVcsTUFBTSxTQUFTO0FBQUEsSUFDMUIsVUFBVSxTQUFTLFlBQVk7QUFBQTtBQUFBO0FBQUEsSUFHL0IsV0FBVztBQUFBLE1BQ1AscUJBQXFCO0FBQUEsUUFDakIsT0FBTyxTQUFTLFNBQVM7QUFBQSxRQUN6QixNQUFNLFNBQVMsUUFBUTtBQUFBLFFBQ3ZCLFVBQVUsU0FBUyxZQUFZO0FBQUEsUUFDL0IsWUFBWSxTQUFTLGVBQWU7QUFBQSxNQUN4QyxDQUFDO0FBQUEsTUFDRCxnQkFBZ0I7QUFBQSxRQUNaLFdBQVcsU0FBUztBQUFBLFFBQ3BCLGFBQWEsU0FBUztBQUFBLFFBQ3RCLE9BQU8sU0FBUztBQUFBLFFBQ2hCLFlBQVksU0FBUztBQUFBLFFBQ3JCLFVBQVUsU0FBUztBQUFBLE1BQ3ZCLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlELG1CQUFtQixPQUFPLDBDQUEwQyxlQUFlLGVBQWUsT0FBTyxDQUFDLHFHQUFrRztBQUFBLElBQ2hOLEVBQUUsT0FBTyxPQUFPLEVBQUUsS0FBSyxJQUFJO0FBQUEsSUFDM0IsYUFBYSxjQUFjLENBQUMsR0FBRyxJQUFJLENBQUMsaUJBQWU7QUFBQSxNQUMzQyxPQUFPLFlBQVk7QUFBQSxNQUNuQixXQUFXLFlBQVksYUFBYTtBQUFBLE1BQ3BDLEtBQUssWUFBWSxPQUFPO0FBQUEsSUFDNUIsRUFBRTtBQUFBLElBQ047QUFBQSxJQUNBLGlCQUFpQixRQUFRO0FBQUEsRUFDN0I7QUFDQSxRQUFNLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQSxnQkFBZ0IsUUFBUTtBQUFBLElBQ3hCLFdBQVcsUUFBUTtBQUFBLElBQ25CLFdBQVcsUUFBUTtBQUFBLElBQ25CLGVBQWUsUUFBUTtBQUFBLElBQ3ZCLFVBQVU7QUFBQSxFQUNkO0FBQ0EsUUFBTSxPQUFPLENBQUM7QUFDZCxRQUFNLFNBQVMsTUFBTSxTQUFTLGtCQUFrQixVQUFVLFFBQVEsR0FBRztBQUNyRSxRQUFNLFdBQVcsTUFBTSxTQUFTLElBQUksQ0FBQyxZQUFVLFFBQVEsS0FBSztBQUc1RCxRQUFNLFVBQVUsQ0FBQztBQUNqQixhQUFXLENBQUMsUUFBUSxPQUFPLEtBQUssTUFBTSxTQUFTLFFBQVEsR0FBRTtBQUNyRCxVQUFNLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUFBLE1BQ2pELEdBQUc7QUFBQSxNQUNILGNBQWMsUUFBUTtBQUFBLE1BQ3RCLGVBQWUsUUFBUTtBQUFBLE1BQ3ZCLFdBQVcsUUFBUTtBQUFBLE1BQ25CLGFBQWEsUUFBUTtBQUFBLE1BQ3JCLGVBQWUsU0FBUztBQUFBLE1BQ3hCLFNBQVM7QUFBQSxNQUNULFlBQVksTUFBTTtBQUFBLElBQ3RCLEdBQUcsUUFBUSxHQUFHO0FBQ2QsWUFBUSxLQUFLLFFBQVEsVUFBVSxLQUFLLENBQUM7QUFDckMsU0FBSyxLQUFLLEdBQUcsUUFBUSxJQUFJO0FBQUEsRUFDN0I7QUFDQSxRQUFNLFFBQVEsUUFBUSxLQUFLLE1BQU07QUFHakMsUUFBTSxZQUFZLE1BQU0sU0FBUyx1QkFBdUI7QUFBQSxJQUNwRCxHQUFHO0FBQUEsSUFDSCxZQUFZLE1BQU07QUFBQSxJQUNsQixTQUFTO0FBQUEsSUFDVCxNQUFNO0FBQUEsRUFDVixHQUFHLFFBQVEsR0FBRztBQUNkLE9BQUssS0FBSyxHQUFHLFNBQVMsSUFBSTtBQUMxQixRQUFNLFlBQVksZ0JBQWdCLFFBQVEsUUFBUSxRQUFRLE9BQU8sTUFBTSxZQUFZLE9BQU8sUUFBUTtBQUNsRyxRQUFNLEVBQUUsTUFBTSxLQUFLLElBQUksTUFBTSxHQUFHLEtBQUssa0JBQWtCLEVBQUUsT0FBTyxZQUFZLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUyxFQUFFLE1BQU0sY0FBYztBQUFBLElBQ2xJLFdBQVc7QUFBQSxFQUNmLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRSxZQUFZO0FBQ3hCLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFDeEYsUUFBTSxjQUFjLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQU8sS0FBSyxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFO0FBQzlHLFFBQU0sV0FBVyxnQkFBZ0IsU0FBUztBQUMxQyxRQUFNLFlBQVksVUFBVSxNQUFNLEtBQUssRUFBRSxPQUFPLE9BQU8sRUFBRTtBQUN6RCxRQUFNLEVBQUUsTUFBTSxTQUFTLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxrQkFBa0IsRUFBRSxPQUFPO0FBQUEsSUFDdEUsWUFBWSxRQUFRO0FBQUEsSUFDcEIsWUFBWSxRQUFRO0FBQUEsSUFDcEIsaUJBQWlCLFFBQVE7QUFBQSxJQUN6QixhQUFhLE1BQU0sY0FBYyxLQUFLO0FBQUEsSUFDdEMsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osY0FBYztBQUFBLElBQ2QsU0FBUyx1QkFBdUIsTUFBTSxTQUFTLE1BQU0sV0FBZ0IsS0FBSyxTQUFTLElBQUksU0FBUyxLQUFLLE1BQU0sbUNBQW1DLEVBQUU7QUFBQSxJQUNoSixZQUFZO0FBQUEsSUFDWixtQkFBbUI7QUFBQSxJQUNuQixpQkFBaUIsUUFBUTtBQUFBLEVBQzdCLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPO0FBQ3ZCLE1BQUksU0FBUyxDQUFDLFFBQVMsT0FBTSxJQUFJLE1BQU0sT0FBTyxXQUFXLHlCQUF5QjtBQUNsRixRQUFNLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTztBQUFBLElBQzdCLG9CQUFvQixRQUFRO0FBQUEsSUFDNUIsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osa0JBQWtCLFNBQVMsV0FBVztBQUFBLElBQ3RDLGVBQWUsU0FBUyxTQUFTO0FBQUEsSUFDakMsY0FBYyxTQUFTLFFBQVE7QUFBQSxJQUMvQixtQkFBbUIsU0FBUyxhQUFhO0FBQUEsSUFDekMsWUFBWSxTQUFTLE1BQU07QUFBQSxFQUMvQixDQUFDLEVBQUUsR0FBRyxNQUFNLFFBQVEsU0FBUztBQUM3QixTQUFPO0FBQUEsSUFDSCxTQUFTO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSDtBQUFBLE1BQ0EsVUFBVSxTQUFTLFNBQVMsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUM5QixPQUFPLEVBQUU7QUFBQSxRQUNULE1BQU0sRUFBRTtBQUFBLFFBQ1IsTUFBTSxFQUFFO0FBQUEsTUFDWixFQUFFO0FBQUEsTUFDTixZQUFZLFNBQVMsV0FBVyxJQUFJLENBQUMsT0FBSztBQUFBLFFBQ2xDLFVBQVUsRUFBRTtBQUFBLFFBQ1osU0FBUyxFQUFFO0FBQUEsUUFDWCxNQUFNLEVBQUU7QUFBQSxNQUNaLEVBQUU7QUFBQSxNQUNOLE9BQU8sU0FBUztBQUFBLE1BQ2hCLFNBQVMsU0FBUyxRQUFRLElBQUksQ0FBQyxPQUFLO0FBQUEsUUFDNUIsS0FBSyxFQUFFO0FBQUEsUUFDUCxLQUFLLEVBQUU7QUFBQSxRQUNQLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLE1BQ04sY0FBYyxTQUFTLGFBQWEsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUN0QyxhQUFhLEVBQUU7QUFBQSxRQUNmLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLElBQ1Y7QUFBQSxJQUNBLFdBQVcsUUFBUTtBQUFBLElBQ25CO0FBQUEsSUFDQSxVQUFVLEtBQUssV0FBVztBQUFBLEVBQzlCO0FBQ0o7QUF6SzBCO0FBNksxQixlQUFzQixnQkFBZ0IsU0FBUyxTQUFTO0FBQ3BELFFBQU0sU0FBUyxNQUFNLFNBQVMsd0JBQXdCLFNBQVM7QUFBQSxJQUMzRCxJQUFJLGtCQUFrQjtBQUFBLElBQ3RCLGdCQUFnQixRQUFRO0FBQUEsSUFDeEIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsZUFBZSxRQUFRO0FBQUEsSUFDdkIsVUFBVTtBQUFBLEVBQ2QsQ0FBQztBQUNELFNBQU8sT0FBTztBQUNsQjtBQVZzQjtBQXNCbEIsZUFBc0IsYUFBYSxTQUFTLFNBQVMsUUFBUTtBQUM3RCxNQUFJLFFBQVEsTUFBTSxXQUFXLEtBQUssT0FBTyxXQUFXLEdBQUc7QUFDbkQsV0FBTztBQUFBLE1BQ0gsV0FBVyxDQUFDO0FBQUEsTUFDWixhQUFhLENBQUM7QUFBQSxNQUNkLGlCQUFpQjtBQUFBLE1BQ2pCLFFBQVE7QUFBQSxRQUNKO0FBQUEsVUFDSSxNQUFNO0FBQUEsVUFDTixVQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixZQUFZO0FBQUEsVUFDWixVQUFVO0FBQUEsWUFDTixNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxTQUFTO0FBQUEsVUFDYjtBQUFBLFVBQ0EsVUFBVSxDQUFDO0FBQUEsUUFDZjtBQUFBLE1BQ0o7QUFBQTtBQUFBLE1BRUEsWUFBWTtBQUFBLE1BQ1osU0FBUztBQUFBLElBQ2I7QUFBQSxFQUNKO0FBQ0EsUUFBTSxTQUFTLE1BQU0sU0FBUyxvQkFBb0I7QUFBQSxJQUM5QyxHQUFHO0FBQUEsSUFDSDtBQUFBLEVBQ0osR0FBRztBQUFBLElBQ0MsSUFBSSxrQkFBa0I7QUFBQSxJQUN0QixnQkFBZ0IsUUFBUTtBQUFBLElBQ3hCLFdBQVcsUUFBUTtBQUFBLElBQ25CLFdBQVcsUUFBUTtBQUFBLElBQ25CLGVBQWUsUUFBUTtBQUFBLElBQ3ZCLFVBQVU7QUFBQSxFQUNkLENBQUM7QUFDRCxTQUFPLE9BQU87QUFDbEI7QUF0QzBCO0FBa0R0QixlQUFzQixrQkFBa0IsU0FBUyxRQUFRLGFBQWE7QUFDdEUsUUFBTSxLQUFLLGtCQUFrQjtBQUM3QixRQUFNLEVBQUUsT0FBTyxlQUFlLElBQUksTUFBTSxrQkFBa0IsSUFBSSxRQUFRLGdCQUFnQixRQUFRLFNBQVM7QUFHdkcsTUFBSSxtQkFBbUIsR0FBRztBQUN0QixXQUFPO0FBQUEsTUFDSDtBQUFBLE1BQ0EsV0FBVztBQUFBLE1BQ1gsZ0JBQWdCO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQ0EsUUFBTSxXQUFXLGVBQWUsUUFBUSxLQUFLO0FBQzdDLFNBQU87QUFBQSxJQUNILGFBQWEsaUJBQWlCLGFBQWEsU0FBUyxXQUFXO0FBQUEsSUFDL0QsV0FBVyxTQUFTO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBQ0o7QUFsQjBCO0FBaUN0QixlQUFzQixnQkFBZ0IsVUFBVSxXQUFXO0FBQzNELFFBQU0sZ0JBQWdCLFVBQVUsT0FBTyxDQUFDLGFBQVcsU0FBUyxpQkFBaUIsWUFBWTtBQUN6RixNQUFJLGNBQWMsV0FBVyxFQUFHLFFBQU87QUFBQSxJQUNuQyxRQUFRLENBQUM7QUFBQSxJQUNULFVBQVUsQ0FBQztBQUFBLElBQ1gsUUFBUTtBQUFBLEVBQ1o7QUFDQSxRQUFNLFFBQVEsTUFBTSxXQUFXLGNBQWMsSUFBSSxDQUFDLGFBQVcsU0FBUyxHQUFHLENBQUM7QUFDMUUsUUFBTSxTQUFTLENBQUM7QUFDaEIsUUFBTSxXQUFXLENBQUM7QUFDbEIsV0FBUSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFFO0FBQ3BDLFVBQU0sUUFBUSxNQUFNLENBQUM7QUFDckIsVUFBTSxXQUFXLGNBQWMsQ0FBQztBQUNoQyxhQUFTLEtBQUs7QUFBQSxNQUNWLEtBQUssU0FBUztBQUFBLE1BQ2QsUUFBUSxNQUFNO0FBQUEsTUFDZCxJQUFJLE1BQU07QUFBQSxNQUNWLE9BQU8sTUFBTTtBQUFBLElBQ2pCLENBQUM7QUFDRCxRQUFJLE1BQU0sSUFBSTtBQUdWLFVBQUksU0FBUyxjQUFjLENBQUMsU0FBUyxTQUFTO0FBQzFDLGVBQU8sS0FBSztBQUFBLFVBQ1IsTUFBTTtBQUFBLFVBQ04sVUFBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFVBQ1AsUUFBUSxHQUFHLFNBQVMsR0FBRyxhQUFhLE1BQU0sTUFBTSx5QkFBbUIsTUFBTSxTQUFTLFFBQUc7QUFBQSxVQUNyRixZQUFZO0FBQUEsVUFDWixVQUFVO0FBQUEsWUFDTixNQUFNLFNBQVMsUUFBUTtBQUFBLFlBQ3ZCLFNBQVM7QUFBQSxZQUNULFNBQVMsU0FBUztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVO0FBQUEsWUFDTixTQUFTO0FBQUEsVUFDYjtBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ0w7QUFDQTtBQUFBLElBQ0o7QUFDQSxXQUFPLEtBQUs7QUFBQSxNQUNSLE1BQU07QUFBQSxNQUNOLFVBQVU7QUFBQSxNQUNWLE9BQU87QUFBQSxNQUNQLFFBQVEsR0FBRyxTQUFTLEdBQUcsbUJBQW1CLE1BQU0sV0FBVyxPQUFPLFdBQVcsTUFBTSxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQ3ZHLFlBQVksTUFBTSxRQUFRO0FBQUEsTUFDMUIsVUFBVTtBQUFBLFFBQ04sTUFBTSxTQUFTLFFBQVE7QUFBQSxRQUN2QixTQUFTO0FBQUEsUUFDVCxTQUFTLFNBQVM7QUFBQSxNQUN0QjtBQUFBLE1BQ0EsVUFBVTtBQUFBLFFBQ04sU0FBUztBQUFBLE1BQ2I7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBQ0EsU0FBTztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUEsSUFDQSxRQUFRLE9BQU8sT0FBTyxDQUFDLE1BQUksRUFBRSxhQUFhLE1BQU0sRUFBRTtBQUFBLEVBQ3REO0FBQ0o7QUE5RDBCO0FBa0UxQixlQUFzQixhQUFhLFNBQVMsV0FBVyxTQUFTLGFBQWEsWUFBWSxZQUFZO0FBQ2pHLFFBQU0sS0FBSyxrQkFBa0I7QUFJN0IsUUFBTSxnQkFBZ0IsUUFBUSxPQUFPLE9BQU8sQ0FBQyxVQUFRLE1BQU0sVUFBVSxxQ0FBcUM7QUFDMUcsUUFBTSxTQUFTO0FBQUEsSUFDWCxHQUFHLFVBQVU7QUFBQSxJQUNiLEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxFQUNQLEVBQUUsSUFBSSxDQUFDLFdBQVM7QUFBQSxJQUNSLEdBQUc7QUFBQTtBQUFBO0FBQUEsSUFHSCxVQUFVO0FBQUEsTUFDTixHQUFHLE1BQU07QUFBQSxNQUNULE1BQU0sTUFBTSxTQUFTLFNBQVMsSUFBSSxPQUFPLE1BQU0sU0FBUztBQUFBLElBQzVEO0FBQUEsRUFDSixFQUFFO0FBR04sUUFBTSxHQUFHLEtBQUsscUJBQXFCLEVBQUUsT0FBTyxFQUFFLEdBQUcsbUJBQW1CLFFBQVEsYUFBYTtBQUN6RixNQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ25CLFVBQU0sT0FBTyxPQUFPLElBQUksQ0FBQyxXQUFTO0FBQUEsTUFDMUIsWUFBWSxRQUFRO0FBQUEsTUFDcEIsaUJBQWlCLFFBQVE7QUFBQSxNQUN6QixZQUFZLFFBQVE7QUFBQSxNQUNwQixpQkFBaUIsUUFBUTtBQUFBLE1BQ3pCLE1BQU0sTUFBTTtBQUFBLE1BQ1osVUFBVSxNQUFNO0FBQUEsTUFDaEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxNQUFNO0FBQUEsTUFDYixRQUFRLE1BQU07QUFBQSxNQUNkLFlBQVksTUFBTTtBQUFBLE1BQ2xCLFVBQVUsTUFBTTtBQUFBLE1BQ2hCLFVBQVUsTUFBTTtBQUFBLElBQ3BCLEVBQUU7QUFDTixhQUFRLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLEtBQUk7QUFDckMsWUFBTSxHQUFHLEtBQUsscUJBQXFCLEVBQUUsT0FBTyxLQUFLLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQztBQUFBLElBQ3RFO0FBQUEsRUFDSjtBQUVBLFFBQU0sR0FBRyxLQUFLLFdBQVcsRUFBRSxPQUFPLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUztBQUN0RSxNQUFJLFFBQVEsVUFBVSxTQUFTLEdBQUc7QUFDOUIsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sR0FBRyxLQUFLLFdBQVcsRUFBRSxPQUFPLFFBQVEsVUFBVSxJQUFJLENBQUMsY0FBWTtBQUFBLE1BQzdELFlBQVksUUFBUTtBQUFBLE1BQ3BCLGlCQUFpQixRQUFRO0FBQUEsTUFDekIsWUFBWSxRQUFRO0FBQUEsTUFDcEIsS0FBSyxTQUFTO0FBQUEsTUFDZCxPQUFPLFNBQVMsZ0JBQWdCLFNBQVMsUUFBUTtBQUFBLE1BQ2pELFdBQVcsU0FBUyxVQUFVO0FBQUEsTUFDOUIsYUFBYSxTQUFTO0FBQUEsTUFDdEIsTUFBTSxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJZixhQUFhLFdBQVcsS0FBSyxDQUFDLE1BQUksRUFBRSxRQUFRLFNBQVMsR0FBRyxHQUFHLFVBQVU7QUFBQSxNQUNyRSxjQUFjLFdBQVcsS0FBSyxDQUFDLE1BQUksRUFBRSxRQUFRLFNBQVMsR0FBRyxHQUFHLE1BQU07QUFBQSxNQUNsRSxpQkFBaUI7QUFBQSxJQUNyQixFQUFFLENBQUM7QUFBQSxFQUNYO0FBR0EsUUFBTSxHQUFHLEtBQUssb0JBQW9CLEVBQUUsT0FBTyxFQUFFLEdBQUcsbUJBQW1CLFFBQVEsYUFBYTtBQUN4RixRQUFNLGlCQUFpQixZQUFZLFFBQVEsQ0FBQyxlQUFhLFdBQVcsV0FBVyxJQUFJLENBQUMsV0FBVyxXQUFTO0FBQUEsSUFDNUYsWUFBWSxRQUFRO0FBQUEsSUFDcEIsaUJBQWlCLFFBQVE7QUFBQSxJQUN6QixZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLFlBQVksV0FBVztBQUFBLElBQ3ZCLGVBQWUsV0FBVztBQUFBLElBQzFCLFVBQVUsV0FBVztBQUFBLElBQ3JCLEtBQUssVUFBVTtBQUFBLElBQ2YsT0FBTyxVQUFVO0FBQUEsSUFDakIsU0FBUyxVQUFVO0FBQUEsSUFDbkIsT0FBTyxVQUFVO0FBQUEsSUFDakIsTUFBTSxRQUFRO0FBQUEsSUFDZCxlQUFlLFVBQVU7QUFBQSxJQUN6QixRQUFRLFVBQVU7QUFBQSxJQUNsQixjQUFjLFVBQVU7QUFBQSxJQUN4QixNQUFNLFVBQVU7QUFBQSxJQUNoQixRQUFRO0FBQUEsRUFDWixFQUFFLENBQUM7QUFDWCxXQUFRLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUFLLEtBQUk7QUFDL0MsVUFBTSxHQUFHLEtBQUssb0JBQW9CLEVBQUUsT0FBTyxlQUFlLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQztBQUFBLEVBQy9FO0FBQ0EsU0FBTztBQUFBLElBQ0gsWUFBWSxPQUFPO0FBQUEsSUFDbkIsVUFBVSxPQUFPLE9BQU8sQ0FBQyxNQUFJLEVBQUUsYUFBYSxVQUFVLEVBQUU7QUFBQSxJQUN4RCxNQUFNLE9BQU8sT0FBTyxDQUFDLE1BQUksRUFBRSxhQUFhLE1BQU0sRUFBRTtBQUFBLElBQ2hELGFBQWEsWUFBWTtBQUFBLEVBQzdCO0FBQ0o7QUE3RnNCO0FBaUd0QixlQUFzQixnQkFBZ0IsU0FBUyxTQUFTLFFBQVEsYUFBYSxlQUFlO0FBQ3hGLFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxTQUFTLE1BQU0sU0FBUyxzQkFBc0I7QUFBQSxJQUNoRCxHQUFHO0FBQUEsSUFDSDtBQUFBLElBQ0E7QUFBQSxFQUNKLEdBQUc7QUFBQSxJQUNDO0FBQUEsSUFDQSxnQkFBZ0IsUUFBUTtBQUFBLElBQ3hCLFdBQVcsUUFBUTtBQUFBLElBQ25CLFdBQVcsUUFBUTtBQUFBLElBQ25CLGVBQWUsUUFBUTtBQUFBLElBQ3ZCLFVBQVU7QUFBQSxFQUNkLENBQUM7QUFDRCxRQUFNLFdBQVcsT0FBTztBQUV4QixNQUFJLFNBQVMsUUFBUSxXQUFXLEdBQUc7QUFDL0IsV0FBTztBQUFBLE1BQ0gsV0FBVztBQUFBLE1BQ1gsYUFBYTtBQUFBLE1BQ2IsU0FBUyxTQUFTO0FBQUEsSUFDdEI7QUFBQSxFQUNKO0FBQ0EsUUFBTSxFQUFFLE1BQU0sS0FBSyxJQUFJLE1BQU0sR0FBRyxLQUFLLGtCQUFrQixFQUFFLE9BQU8sWUFBWSxFQUFFLEdBQUcsY0FBYyxRQUFRLFNBQVMsRUFBRSxNQUFNLGNBQWM7QUFBQSxJQUNsSSxXQUFXO0FBQUEsRUFDZixDQUFDLEVBQUUsTUFBTSxDQUFDLEVBQUUsWUFBWTtBQUN4QixRQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUyxTQUFTLENBQUM7QUFDakcsUUFBTSxjQUFjLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFO0FBQ3hHLFFBQU0sRUFBRSxNQUFNLFNBQVMsTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLGtCQUFrQixFQUFFLE9BQU87QUFBQSxJQUN0RSxZQUFZLFFBQVE7QUFBQSxJQUNwQixZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLGFBQWEsTUFBTSxjQUFjLEtBQUs7QUFBQSxJQUN0QyxRQUFRO0FBQUEsSUFDUixZQUFZLFNBQVM7QUFBQSxJQUNyQixjQUFjO0FBQUEsSUFDZCxTQUFTLFNBQVM7QUFBQSxJQUNsQixZQUFZLFNBQVMsVUFBVSxNQUFNLEtBQUssRUFBRSxPQUFPLE9BQU8sRUFBRTtBQUFBLElBQzVELG1CQUFtQjtBQUFBLElBQ25CLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsY0FBYyxPQUFPO0FBQUEsSUFDckIsWUFBWSxRQUFRO0FBQUEsRUFDeEIsQ0FBQyxFQUFFLE9BQU8sSUFBSSxFQUFFLE9BQU87QUFDdkIsTUFBSSxTQUFTLENBQUMsUUFBUyxPQUFNLElBQUksTUFBTSx1Q0FBdUMsT0FBTyxXQUFXLEVBQUUsRUFBRTtBQUNwRyxTQUFPO0FBQUEsSUFDSCxXQUFXLFFBQVE7QUFBQSxJQUNuQixhQUFhLFNBQVMsUUFBUTtBQUFBLElBQzlCLFNBQVMsU0FBUztBQUFBLEVBQ3RCO0FBQ0o7QUFqRHNCO0FBcUR0QixlQUFzQixZQUFZLFNBQVMsU0FBUyxjQUFjO0FBQzlELFFBQU0sU0FBUyxNQUFNLFNBQVMsaUJBQWlCO0FBQUEsSUFDM0MsR0FBRztBQUFBLElBQ0g7QUFBQSxFQUNKLEdBQUc7QUFBQSxJQUNDLElBQUksa0JBQWtCO0FBQUEsSUFDdEIsZ0JBQWdCLFFBQVE7QUFBQSxJQUN4QixXQUFXLFFBQVE7QUFBQSxJQUNuQixXQUFXLFFBQVE7QUFBQSxJQUNuQixlQUFlLFFBQVE7QUFBQSxJQUN2QixVQUFVO0FBQUEsRUFDZCxDQUFDO0FBQ0QsU0FBTyxPQUFPO0FBQ2xCO0FBYnNCO0FBaUJ0QixlQUFzQixpQkFBaUIsU0FBUyxjQUFjLGNBQWMsZUFBZTtBQUN2RixRQUFNLEtBQUssa0JBQWtCO0FBQzdCLFFBQU0sVUFBVSxtQkFBbUI7QUFBQSxJQUMvQixRQUFRO0FBQUEsSUFDUixjQUFjO0FBQUEsSUFDZDtBQUFBLEVBQ0osQ0FBQztBQUNELFFBQU0sRUFBRSxNQUFNLFNBQVMsSUFBSSxNQUFNLEdBQUcsS0FBSyxlQUFlLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUyxFQUFFLEdBQUcsUUFBUSxTQUFTLEVBQUUsTUFBTSxXQUFXO0FBQUEsSUFDbkosV0FBVztBQUFBLEVBQ2YsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLFlBQVk7QUFDeEIsUUFBTSxFQUFFLE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssZUFBZSxFQUFFLE9BQU87QUFBQSxJQUNqRSxZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLFlBQVksUUFBUTtBQUFBLElBQ3BCLE1BQU07QUFBQSxJQUNOLFdBQVc7QUFBQTtBQUFBLElBRVgsUUFBUTtBQUFBLElBQ1IsVUFBVSxVQUFVLFdBQVcsS0FBSztBQUFBLElBQ3BDLE9BQU8sUUFBUTtBQUFBLElBQ2YsU0FBUyxRQUFRO0FBQUEsSUFDakIsVUFBVSxRQUFRO0FBQUEsSUFDbEIsZ0JBQWdCLFFBQVE7QUFBQSxJQUN4QixZQUFZLFFBQVE7QUFBQSxFQUN4QixDQUFDLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTztBQUN2QixNQUFJLFNBQVMsQ0FBQyxNQUFPLE9BQU0sSUFBSSxNQUFNLHNDQUFzQyxPQUFPLFdBQVcsRUFBRSxFQUFFO0FBQ2pHLFNBQU87QUFBQSxJQUNILFVBQVU7QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNWO0FBQUEsSUFDQSxTQUFTLFFBQVE7QUFBQSxFQUNyQjtBQUNKO0FBaENzQjtBQW9DdEIsZUFBc0IsZ0JBQWdCLFNBQVMsZUFBZSxtQkFBbUIsYUFBYSxTQUFTO0FBQ25HLFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLGlCQUFpQixFQUFFLE9BQU87QUFBQSxJQUM1RCxZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLFlBQVksUUFBUTtBQUFBLElBQ3BCLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsaUJBQWlCO0FBQUEsSUFDakIscUJBQXFCO0FBQUEsSUFDckIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1A7QUFBQSxJQUNBLGNBQWM7QUFBQSxJQUNkLGNBQWMsUUFBUTtBQUFBLEVBQzFCLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPO0FBQ3ZCLE1BQUksU0FBUyxDQUFDLEtBQU0sT0FBTSxJQUFJLE1BQU0sbURBQW1ELE9BQU8sV0FBVyxFQUFFLEVBQUU7QUFDN0csUUFBTSxHQUFHLEtBQUssZUFBZSxFQUFFLE9BQU87QUFBQSxJQUNsQyxRQUFRO0FBQUEsSUFDUixjQUFjO0FBQUEsRUFDbEIsQ0FBQyxFQUFFLEdBQUcsTUFBTSxRQUFRLGFBQWE7QUFDakMsUUFBTSxHQUFHLEtBQUssVUFBVSxFQUFFLE9BQU87QUFBQSxJQUM3QixRQUFRO0FBQUEsRUFDWixDQUFDLEVBQUUsR0FBRyxNQUFNLFFBQVEsU0FBUztBQUM3QixTQUFPLEtBQUs7QUFDaEI7QUF4QnNCO0FBNEJ0QixlQUFzQixjQUFjLFNBQVMsaUJBQWlCLDhCQUE4QixVQUFVLE1BQU0sV0FBVztBQUNuSCxRQUFNLEtBQUssa0JBQWtCO0FBQzdCLFFBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUluQyxRQUFNLEVBQUUsTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHLEtBQUssaUJBQWlCLEVBQUUsT0FBTyxxQkFBcUIsRUFBRSxHQUFHLE1BQU0sZUFBZSxFQUFFLFlBQVk7QUFDL0gsUUFBTSxvQkFBb0IsU0FBUyx1QkFBdUI7QUFDMUQsUUFBTSxHQUFHLEtBQUssaUJBQWlCLEVBQUUsT0FBTztBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGVBQWU7QUFBQSxFQUNuQixDQUFDLEVBQUUsR0FBRyxNQUFNLGVBQWU7QUFDM0IsTUFBSSxhQUFhLGNBQWMsQ0FBQyxtQkFBbUI7QUFDL0MsVUFBTSxHQUFHLEtBQUssVUFBVSxFQUFFLE9BQU87QUFBQSxNQUM3QixRQUFRO0FBQUEsSUFDWixDQUFDLEVBQUUsR0FBRyxNQUFNLFFBQVEsU0FBUztBQUM3QixXQUFPO0FBQUEsTUFDSCxtQkFBbUI7QUFBQSxJQUN2QjtBQUFBLEVBQ0o7QUFHQSxRQUFNLEdBQUcsS0FBSyxrQkFBa0IsRUFBRSxPQUFPO0FBQUEsSUFDckMsUUFBUTtBQUFBLElBQ1IsYUFBYTtBQUFBLElBQ2IsYUFBYTtBQUFBLElBQ2IsYUFBYTtBQUFBLEVBQ2pCLENBQUMsRUFBRSxHQUFHLE1BQU0saUJBQWlCO0FBQzdCLFFBQU0sR0FBRyxLQUFLLFVBQVUsRUFBRSxPQUFPO0FBQUEsSUFDN0Isb0JBQW9CO0FBQUEsSUFDcEIsUUFBUTtBQUFBLEVBQ1osQ0FBQyxFQUFFLEdBQUcsTUFBTSxRQUFRLFNBQVM7QUFDN0IsU0FBTztBQUFBLElBQ0gsbUJBQW1CO0FBQUEsRUFDdkI7QUFDSjtBQXJDc0I7QUF5Q3RCLGVBQXNCLFNBQVMsZUFBZSxNQUFNLFdBQVcsT0FBTztBQUNsRSxRQUFNLGtCQUFrQixFQUFFLEtBQUssZUFBZSxFQUFFLE9BQU87QUFBQSxJQUNuRCxjQUFjO0FBQUEsSUFDZCxpQkFBaUI7QUFBQSxJQUNqQixhQUFhO0FBQUEsSUFDYixRQUFRO0FBQUEsRUFDWixDQUFDLEVBQUUsR0FBRyxNQUFNLGFBQWE7QUFDN0I7QUFQc0I7QUFRdEIsZUFBc0IsVUFBVSxlQUFlLFFBQVEsUUFBUSxPQUFPO0FBQ2xFLFFBQU0sa0JBQWtCLEVBQUUsS0FBSyxlQUFlLEVBQUUsT0FBTztBQUFBLElBQ25EO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxFQUN4QyxDQUFDLEVBQUUsR0FBRyxNQUFNLGFBQWE7QUFDN0I7QUFQc0I7QUFzQmxCLGVBQXNCLG9CQUFvQixTQUFTO0FBQ25ELE1BQUk7QUFDQSxVQUFNLFFBQVEsTUFBTSx5QkFBeUIsa0JBQWtCLEdBQUc7QUFBQSxNQUM5RCxXQUFXLFFBQVE7QUFBQSxNQUNuQixnQkFBZ0IsUUFBUTtBQUFBLE1BQ3hCLFNBQVMsUUFBUTtBQUFBLElBQ3JCLENBQUM7QUFDRCxXQUFPO0FBQUEsTUFDSCxJQUFJLE1BQU07QUFBQSxNQUNWLFVBQVUsTUFBTSxZQUFZO0FBQUEsTUFDNUIsT0FBTyxNQUFNLFNBQVM7QUFBQSxNQUN0QixTQUFTLE1BQU07QUFBQSxJQUNuQjtBQUFBLEVBQ0osU0FBUyxPQUFPO0FBQ1osV0FBTztBQUFBLE1BQ0gsSUFBSTtBQUFBLE1BQ0osVUFBVTtBQUFBLE1BQ1YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkIsTUFBTSxPQUFPO0FBQUEsSUFDdkQ7QUFBQSxFQUNKO0FBQ0o7QUFyQjBCO0FBc0IxQkMsc0JBQXFCLDBEQUEwRCxXQUFXO0FBQzFGQSxzQkFBcUIsMkRBQTJELFlBQVk7QUFDNUZBLHNCQUFxQiw4REFBOEQsZUFBZTtBQUNsR0Esc0JBQXFCLDJEQUEyRCxZQUFZO0FBQzVGQSxzQkFBcUIsZ0VBQWdFLGlCQUFpQjtBQUN0R0Esc0JBQXFCLDhEQUE4RCxlQUFlO0FBQ2xHQSxzQkFBcUIsMkRBQTJELFlBQVk7QUFDNUZBLHNCQUFxQiw4REFBOEQsZUFBZTtBQUNsR0Esc0JBQXFCLDBEQUEwRCxXQUFXO0FBQzFGQSxzQkFBcUIsK0RBQStELGdCQUFnQjtBQUNwR0Esc0JBQXFCLDhEQUE4RCxlQUFlO0FBQ2xHQSxzQkFBcUIsNERBQTRELGFBQWE7QUFDOUZBLHNCQUFxQix1REFBdUQsUUFBUTtBQUNwRkEsc0JBQXFCLHdEQUF3RCxTQUFTO0FBQ3RGQSxzQkFBcUIsa0VBQWtFLG1CQUFtQjs7O0FDbHlCdEcsU0FBMkIsZ0JBQXdCLGtCQUFsQkMsdUJBQThCOyIsCiAgIm5hbWVzIjogWyJyZWdpc3RlclN0ZXBGdW5jdGlvbiIsICJyZWdpc3RlclN0ZXBGdW5jdGlvbiIsICJyZWdpc3RlclN0ZXBGdW5jdGlvbiIsICJyZWdpc3RlclN0ZXBGdW5jdGlvbiIsICJzdGVwRW50cnlwb2ludCJdCn0K
