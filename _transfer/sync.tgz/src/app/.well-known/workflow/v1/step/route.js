// biome-ignore-all lint: generated file
/* eslint-disable */

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// node_modules/workflow/dist/internal/builtins.js
import { registerStepFunction } from "workflow/internal/private";
async function __builtin_response_array_buffer() {
  return this.arrayBuffer();
}
__name(__builtin_response_array_buffer, "__builtin_response_array_buffer");
async function __builtin_response_json() {
  return this.json();
}
__name(__builtin_response_json, "__builtin_response_json");
async function __builtin_response_text() {
  return this.text();
}
__name(__builtin_response_text, "__builtin_response_text");
registerStepFunction("__builtin_response_array_buffer", __builtin_response_array_buffer);
registerStepFunction("__builtin_response_json", __builtin_response_json);
registerStepFunction("__builtin_response_text", __builtin_response_text);

// node_modules/workflow/dist/stdlib.js
import { registerStepFunction as registerStepFunction2 } from "workflow/internal/private";
async function fetch(...args) {
  return globalThis.fetch(...args);
}
__name(fetch, "fetch");
registerStepFunction2("step//workflow@4.8.1//fetch", fetch);

// src/workflows/chapter-audit-steps.ts
import { registerStepFunction as registerStepFunction3 } from "workflow/internal/private";
import { createAdminClient } from "../../../../../lib/supabase/admin.ts";
import { runAgent } from "../../../../../lib/agents/runner.ts";
import { chapterApparatusAgent, chapterPlanAgent, chapterSectionAgent, sourceAuditorAgent, technicalVerifierAgent, technicalWriterAgent, visualPlanAgent } from "../../../../../lib/agents/definitions.ts";
import { analyzeMarkdown } from "../../../../../lib/ingest/markdown.ts";
import { istruzioniEditoriali } from "../../../../../lib/editorial/direzione.ts";
import { rebuildVolumePreviewWith } from "../../../../../lib/publish/preview.ts";
import { buildProjectIndex } from "../../../../../lib/sources/library.ts";
import { mergeSuggestions, researchClaims } from "../../../../../lib/sources/research.ts";
import { verifyUrls } from "../../../../../lib/sources/verify-url.ts";
import { extractConfigBlock } from "../../../../../lib/agents/analysis/dataform.ts";
import { buildDependencyDag } from "../../../../../lib/visual/mermaid-dag.ts";
async function loadChapter(context) {
  const db = createAdminClient();
  const { data: chapter, error } = await db.from("chapters").select("id, number, title, current_version_id, organization_id, project_id").eq("id", context.chapterId).single();
  if (error || !chapter) throw new Error("Capitolo non trovato.");
  if (chapter.organization_id !== context.organizationId || chapter.project_id !== context.projectId) {
    throw new Error("Il capitolo non appartiene al progetto indicato.");
  }
  const { data: version } = await db.from("chapter_versions").select("id, content_md").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  if (!version) throw new Error("Il capitolo non ha alcuna versione da analizzare.");
  const analysis = analyzeMarkdown(version.content_md);
  const isIncremental = analysis.codeBlocks.some((block) => {
    const config = extractConfigBlock(block.content);
    return config !== null && /\btype\s*:\s*["']incremental["']/.test(config);
  });
  return {
    chapter: {
      chapterId: chapter.id,
      number: chapter.number,
      title: chapter.title,
      contentMd: version.content_md,
      headings: analysis.headings.map((h) => ({
        level: h.level,
        text: h.text,
        line: h.line
      })),
      codeBlocks: analysis.codeBlocks.map((b) => ({
        language: b.language,
        content: b.content,
        line: b.line
      })),
      links: analysis.links,
      figures: analysis.figures.map((f) => ({
        alt: f.alt,
        src: f.src,
        line: f.line
      })),
      placeholders: analysis.placeholders.map((p) => ({
        description: p.description,
        line: p.line
      }))
    },
    versionId: version.id,
    isIncremental
  };
}
__name(loadChapter, "loadChapter");
function componiCapitolo(numero, titolo, obiettivi, corpo, apparato) {
  const parti = [
    `# ${numero !== null ? `Capitolo ${numero} - ` : ""}${titolo}`,
    "",
    "> **OBIETTIVI DEL CAPITOLO**",
    ">",
    ...obiettivi.map((obiettivo) => `> - ${obiettivo}`),
    "",
    corpo,
    ""
  ];
  if (apparato.bestPractices.length > 0) {
    parti.push("## Best practice", "", ...apparato.bestPractices.map((voce) => `- ${voce}`), "");
  }
  if (apparato.commonErrors.length > 0) {
    parti.push("## Errori comuni", "", ...apparato.commonErrors.map((voce) => `- ${voce}`), "");
  }
  parti.push("## Riassunto", "", apparato.summary, "");
  parti.push("## Punti chiave", "", ...apparato.keyPoints.map((voce) => `- ${voce}`), "");
  if (apparato.quiz.length > 0) {
    parti.push("## Quiz", "", "Per ogni domanda una sola risposta \xE8 corretta.", "");
    apparato.quiz.forEach((domanda, indice) => {
      parti.push(`${indice + 1}. **${domanda.question}**`, "");
      domanda.options.forEach((opzione, i) => {
        parti.push(`   ${String.fromCharCode(97 + i)}) ${opzione}`);
      });
      parti.push("");
    });
    parti.push("**Soluzioni:** " + apparato.quiz.map((domanda, indice) => `${indice + 1}-${String.fromCharCode(97 + domanda.correct)}`).join(", "), "");
  }
  if (apparato.lab.trim()) parti.push("## Laboratorio", "", apparato.lab.trim(), "");
  return parti.join("\n");
}
__name(componiCapitolo, "componiCapitolo");
async function draftChapter(context, chapter, baseVersionId) {
  const db = createAdminClient();
  const [{ data: chapterRow }, { data: project }] = await Promise.all([
    db.from("chapters").select("part_id").eq("id", context.chapterId).maybeSingle(),
    db.from("projects").select("language, level, tone, register, style_notes").eq("id", context.projectId).maybeSingle()
  ]);
  const { data: part } = chapterRow?.part_id ? await db.from("publication_parts").select("title").eq("id", chapterRow.part_id).maybeSingle() : {
    data: null
  };
  const [{ data: references }, { data: referenceChunks }, { data: sourceChunks }] = await Promise.all([
    db.from("reference_sources").select("title, publisher, url").or(`project_id.eq.${context.projectId},project_id.is.null`).neq("status", "proposed").limit(60),
    db.from("reference_chunks").select("heading, content").or(`project_id.eq.${context.projectId},project_id.is.null`).order("chunk_index", {
      ascending: true
    }).limit(120),
    db.from("source_chunks").select("heading_path, content").eq("project_id", context.projectId).order("chunk_index", {
      ascending: true
    }).limit(120)
  ]);
  const evidence = [
    ...(referenceChunks ?? []).map((blocco) => `${blocco.heading ? `## ${blocco.heading}
` : ""}${blocco.content}`),
    ...(sourceChunks ?? []).map((blocco) => `${blocco.heading_path?.length ? `## ${blocco.heading_path.join(" > ")}
` : ""}${blocco.content}`)
  ].join("\n\n").slice(0, 6e4);
  const obiettivo = chapter.contentMd.match(/##\s*Obiettivo\s*\n+([\s\S]*?)(?:\n#{1,2}\s|$)/i);
  const ingresso = {
    chapterId: chapter.chapterId,
    number: chapter.number,
    title: chapter.title,
    objective: (obiettivo?.[1] ?? "").trim().slice(0, 2e3),
    partTitle: part?.title ?? null,
    language: project?.language ?? "it",
    // Senza questo, tre volumi sullo stesso argomento produrrebbero lo stesso
    // capitolo con tre titoli diversi.
    direzione: istruzioniEditoriali({
      level: project?.level ?? "base",
      tone: project?.tone ?? "didattico",
      register: project?.register ?? "tecnico_operativo",
      styleNotes: project?.style_notes ?? null
    }),
    references: (references ?? []).map((riferimento) => ({
      title: riferimento.title,
      publisher: riferimento.publisher ?? null,
      url: riferimento.url ?? null
    })),
    evidence,
    existingContent: chapter.contentMd
  };
  const contesto = {
    db,
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "stesura-capitolo"
  };
  const gaps = [];
  const piano = (await runAgent(chapterPlanAgent, ingresso, contesto)).output;
  const scaletta = piano.sections.map((sezione) => sezione.title);
  const sezioni = [];
  for (const [indice, sezione] of piano.sections.entries()) {
    const scritta = (await runAgent(chapterSectionAgent, {
      ...ingresso,
      sectionTitle: sezione.title,
      sectionIntent: sezione.intent,
      needsCode: sezione.needsCode,
      needsFigure: sezione.needsFigure,
      sectionNumber: indice + 1,
      outline: scaletta,
      objectives: piano.objectives
    }, contesto)).output;
    sezioni.push(scritta.contentMd.trim());
    gaps.push(...scritta.gaps);
  }
  const corpo = sezioni.join("\n\n");
  const apparato = (await runAgent(chapterApparatusAgent, {
    ...ingresso,
    objectives: piano.objectives,
    outline: scaletta,
    body: corpo
  }, contesto)).output;
  gaps.push(...apparato.gaps);
  const contentMd = componiCapitolo(chapter.number, chapter.title, piano.objectives, corpo, apparato);
  const { data: last } = await db.from("chapter_versions").select("version_no").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(contentMd));
  const contentHash = Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  const analysis = analyzeMarkdown(contentMd);
  const wordCount = contentMd.split(/\s+/).filter(Boolean).length;
  const { data: created, error } = await db.from("chapter_versions").insert({
    chapter_id: context.chapterId,
    project_id: context.projectId,
    organization_id: context.organizationId,
    version_no: (last?.version_no ?? 0) + 1,
    origin: "ai_proposal",
    content_md: contentMd,
    content_hash: contentHash,
    summary: `Capitolo scritto in ${piano.sections.length} sezioni${gaps.length > 0 ? `, con ${gaps.length} punti non coperti dalle fonti` : ""}.`,
    word_count: wordCount,
    parent_version_id: baseVersionId,
    workflow_run_id: context.workflowRunId
  }).select("id").single();
  if (error || !created) throw new Error(error?.message ?? "Stesura non registrata.");
  await db.from("chapters").update({
    current_version_id: created.id,
    status: "in_review",
    word_count: wordCount,
    code_block_count: analysis.codeBlocks.length,
    heading_count: analysis.headings.length,
    figure_count: analysis.figures.length,
    placeholder_count: analysis.placeholders.length,
    link_count: analysis.links.length
  }).eq("id", context.chapterId);
  return {
    chapter: {
      ...chapter,
      contentMd,
      headings: analysis.headings.map((h) => ({
        level: h.level,
        text: h.text,
        line: h.line
      })),
      codeBlocks: analysis.codeBlocks.map((b) => ({
        language: b.language,
        content: b.content,
        line: b.line
      })),
      links: analysis.links,
      figures: analysis.figures.map((f) => ({
        alt: f.alt,
        src: f.src,
        line: f.line
      })),
      placeholders: analysis.placeholders.map((p) => ({
        description: p.description,
        line: p.line
      }))
    },
    versionId: created.id,
    gaps,
    grounded: gaps.length === 0
  };
}
__name(draftChapter, "draftChapter");
async function verifyTechnical(context, chapter) {
  const result = await runAgent(technicalVerifierAgent, chapter, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "verifica-tecnica"
  });
  return result.output;
}
__name(verifyTechnical, "verifyTechnical");
async function auditSources(context, chapter, claims) {
  if (chapter.links.length === 0 && claims.length === 0) {
    return {
      citations: [],
      suggestions: [],
      unmatchedClaims: 0,
      issues: [
        {
          kind: "source",
          severity: "low",
          title: "Capitolo senza contenuto verificabile",
          detail: "Il capitolo non contiene collegamenti n\xE9 affermazioni tecniche da sostenere con una fonte. La verifica dei riferimenti non \xE8 stata eseguita: non c\u2019\xE8 nulla da verificare, e nulla \xE8 stato dedotto dal titolo.",
          suggestion: "Scrivere il capitolo, poi ripetere l\u2019audit.",
          location: {
            line: null,
            heading: null,
            excerpt: null
          },
          evidence: []
        }
      ],
      // L'esito non è incerto: l'assenza è un fatto constatato, non una stima.
      confidence: 1,
      summary: "Nessun collegamento e nessuna affermazione da verificare: audit delle fonti non eseguito."
    };
  }
  const result = await runAgent(sourceAuditorAgent, {
    ...chapter,
    claims
  }, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "verifica-fonti"
  });
  return result.output;
}
__name(auditSources, "auditSources");
async function enrichWithLibrary(context, claims, suggestions) {
  const db = createAdminClient();
  const { index, libraryEntries } = await buildProjectIndex(db, context.organizationId, context.projectId);
  if (libraryEntries === 0) {
    return {
      suggestions,
      unmatched: 0,
      libraryEntries: 0
    };
  }
  const research = researchClaims(claims, index);
  return {
    suggestions: mergeSuggestions(suggestions, research.suggestions),
    unmatched: research.unmatched,
    libraryEntries
  };
}
__name(enrichWithLibrary, "enrichWithLibrary");
async function verifyCitations(_context, citations) {
  const daControllare = citations.filter((citation) => citation.verification !== "non_valida");
  if (daControllare.length === 0) return {
    issues: [],
    verified: [],
    broken: 0
  };
  const esiti = await verifyUrls(daControllare.map((citation) => citation.url));
  const issues = [];
  const verified = [];
  for (let i = 0; i < esiti.length; i += 1) {
    const esito = esiti[i];
    const citation = daControllare[i];
    verified.push({
      url: citation.url,
      status: esito.status,
      ok: esito.ok,
      title: esito.title
    });
    if (esito.ok) {
      if (citation.isOfficial && !citation.inIndex) {
        issues.push({
          kind: "source",
          severity: "info",
          title: "Pagina ufficiale non ancora censita",
          detail: `${citation.url} risponde ${esito.status} e il titolo \xE8 \xAB${esito.title ?? "\u2014"}\xBB. Il riferimento \xE8 valido: manca soltanto dall\u2019indice curato.`,
          suggestion: "Valutare l\u2019aggiunta a catalog.data.ts con npm run sources:refresh.",
          location: {
            line: citation.line || null,
            heading: null,
            excerpt: citation.url
          },
          evidence: [
            citation.url
          ]
        });
      }
      continue;
    }
    issues.push({
      kind: "source",
      severity: "high",
      title: "Collegamento non raggiungibile",
      detail: `${citation.url} non risponde` + (esito.status !== null ? ` (stato ${esito.status}).` : ".") + " Un collegamento morto in un manuale stampato non \xE8 correggibile.",
      suggestion: esito.note ?? "Aprire il collegamento e sostituirlo.",
      location: {
        line: citation.line || null,
        heading: null,
        excerpt: citation.url
      },
      evidence: [
        citation.url
      ]
    });
  }
  return {
    issues,
    verified,
    broken: issues.filter((i) => i.severity === "high").length
  };
}
__name(verifyCitations, "verifyCitations");
async function persistAudit(context, technical, sources, suggestions, linkIssues, linkChecks) {
  const db = createAdminClient();
  const senzaSospetti = sources.issues.filter((issue) => issue.title !== "Riferimento ufficiale da verificare");
  const issues = [
    ...technical.issues,
    ...senzaSospetti,
    ...linkIssues
  ].map((issue) => ({
    ...issue,
    // «riga 0» non esiste: le righe partono da 1. Uno zero significa «non
    // determinata», e dirlo così evita di mandare il revisore a cercare il nulla.
    location: {
      ...issue.location,
      line: issue.location.line === 0 ? null : issue.location.line
    }
  }));
  await db.from("verification_issues").delete().eq("workflow_run_id", context.workflowRunId);
  if (issues.length > 0) {
    const rows = issues.map((issue) => ({
      project_id: context.projectId,
      organization_id: context.organizationId,
      chapter_id: context.chapterId,
      workflow_run_id: context.workflowRunId,
      kind: issue.kind,
      severity: issue.severity,
      status: "open",
      title: issue.title,
      detail: issue.detail,
      suggestion: issue.suggestion,
      location: issue.location,
      evidence: issue.evidence
    }));
    for (let i = 0; i < rows.length; i += 100) {
      await db.from("verification_issues").insert(rows.slice(i, i + 100));
    }
  }
  await db.from("citations").delete().eq("chapter_id", context.chapterId);
  if (sources.citations.length > 0) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await db.from("citations").insert(sources.citations.map((citation) => ({
      project_id: context.projectId,
      organization_id: context.organizationId,
      chapter_id: context.chapterId,
      url: citation.url,
      title: citation.indexedTitle ?? citation.text ?? null,
      publisher: citation.domain || null,
      is_official: citation.isOfficial,
      note: citation.note,
      // Ora `is_reachable` dice ciò che dovrebbe dire: se la pagina ha
      // risposto quando è stata aperta. Nullo solo per ciò che non è stato
      // interrogato.
      http_status: linkChecks.find((c) => c.url === citation.url)?.status ?? null,
      is_reachable: linkChecks.find((c) => c.url === citation.url)?.ok ?? null,
      last_checked_at: now
    })));
  }
  await db.from("source_suggestions").delete().eq("workflow_run_id", context.workflowRunId);
  const suggestionRows = suggestions.flatMap((suggestion) => suggestion.candidates.map((candidate, index) => ({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    workflow_run_id: context.workflowRunId,
    claim_line: suggestion.line,
    claim_excerpt: suggestion.statement,
    category: suggestion.category,
    url: candidate.url,
    title: candidate.title,
    section: candidate.section,
    score: candidate.score,
    rank: index + 1,
    matched_terms: candidate.matchedTerms,
    origin: candidate.origin,
    reference_id: candidate.referenceId,
    page: candidate.page,
    status: "proposed"
  })));
  for (let i = 0; i < suggestionRows.length; i += 100) {
    await db.from("source_suggestions").insert(suggestionRows.slice(i, i + 100));
  }
  return {
    issueCount: issues.length,
    critical: issues.filter((i) => i.severity === "critical").length,
    high: issues.filter((i) => i.severity === "high").length,
    suggestions: suggestions.length
  };
}
__name(persistAudit, "persistAudit");
async function proposeRevision(context, chapter, issues, suggestions, baseVersionId) {
  const db = createAdminClient();
  const result = await runAgent(technicalWriterAgent, {
    ...chapter,
    issues,
    suggestions
  }, {
    db,
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "proposta-revisione"
  });
  const revision = result.output;
  if (revision.changes.length === 0) {
    return {
      versionId: null,
      changeCount: 0,
      summary: revision.summary
    };
  }
  const { data: last } = await db.from("chapter_versions").select("version_no").eq("chapter_id", context.chapterId).order("version_no", {
    ascending: false
  }).limit(1).maybeSingle();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(revision.contentMd));
  const contentHash = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  const { data: created, error } = await db.from("chapter_versions").insert({
    chapter_id: context.chapterId,
    project_id: context.projectId,
    organization_id: context.organizationId,
    version_no: (last?.version_no ?? 0) + 1,
    origin: "ai_proposal",
    content_md: revision.contentMd,
    content_hash: contentHash,
    summary: revision.summary,
    word_count: revision.contentMd.split(/\s+/).filter(Boolean).length,
    parent_version_id: baseVersionId,
    workflow_run_id: context.workflowRunId,
    agent_run_id: result.agentRunId,
    created_by: context.actorId
  }).select("id").single();
  if (error || !created) throw new Error(`Salvataggio della proposta fallito: ${error?.message ?? ""}`);
  return {
    versionId: created.id,
    changeCount: revision.changes.length,
    summary: revision.summary
  };
}
__name(proposeRevision, "proposeRevision");
async function planVisuals(context, chapter, dataformRefs) {
  const result = await runAgent(visualPlanAgent, {
    ...chapter,
    dataformRefs
  }, {
    db: createAdminClient(),
    organizationId: context.organizationId,
    projectId: context.projectId,
    chapterId: context.chapterId,
    workflowRunId: context.workflowRunId,
    stepName: "piano-visuale"
  });
  return result.output;
}
__name(planVisuals, "planVisuals");
async function generateDiagrams(context, chapterTitle, dataformRefs, isIncremental) {
  const db = createAdminClient();
  const diagram = buildDependencyDag({
    target: chapterTitle,
    dependencies: dataformRefs,
    isIncremental
  });
  const { data: existing } = await db.from("visual_assets").select("version").eq("chapter_id", context.chapterId).eq("kind", "diagram").order("version", {
    ascending: false
  }).limit(1).maybeSingle();
  const { data: asset, error } = await db.from("visual_assets").insert({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    kind: "diagram",
    generator: "mermaid",
    // Anche un diagramma esatto richiede l'occhio umano prima di finire nel libro.
    status: "pending_approval",
    version: (existing?.version ?? 0) + 1,
    title: diagram.title,
    caption: diagram.caption,
    alt_text: diagram.altText,
    mermaid_source: diagram.mermaid,
    created_by: context.actorId
  }).select("id").single();
  if (error || !asset) throw new Error(`Salvataggio del diagramma fallito: ${error?.message ?? ""}`);
  return {
    assetIds: [
      asset.id
    ],
    mermaid: diagram.mermaid
  };
}
__name(generateDiagrams, "generateDiagrams");
async function requestApproval(context, baseVersionId, proposedVersionId, resumeToken, summary) {
  const db = createAdminClient();
  const { data, error } = await db.from("review_requests").insert({
    project_id: context.projectId,
    organization_id: context.organizationId,
    chapter_id: context.chapterId,
    workflow_run_id: context.workflowRunId,
    base_version_id: baseVersionId,
    proposed_version_id: proposedVersionId,
    status: "pending",
    title: "Revisione proposta dall\u2019audit tecnico",
    summary,
    resume_token: resumeToken,
    requested_by: context.actorId
  }).select("id").single();
  if (error || !data) throw new Error(`Creazione della richiesta di revisione fallita: ${error?.message ?? ""}`);
  await db.from("workflow_runs").update({
    status: "awaiting_approval",
    current_step: "attesa-approvazione"
  }).eq("id", context.workflowRunId);
  await db.from("chapters").update({
    status: "in_review"
  }).eq("id", context.chapterId);
  return data.id;
}
__name(requestApproval, "requestApproval");
async function applyDecision(context, reviewRequestId, _proposedVersionIdAtCreation, decision, note, decidedBy) {
  const db = createAdminClient();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const { data: current } = await db.from("review_requests").select("proposed_version_id").eq("id", reviewRequestId).maybeSingle();
  const proposedVersionId = current?.proposed_version_id ?? _proposedVersionIdAtCreation;
  await db.from("review_requests").update({
    status: decision,
    decided_at: now,
    decided_by: decidedBy,
    decision_note: note
  }).eq("id", reviewRequestId);
  if (decision !== "approved" || !proposedVersionId) {
    await db.from("chapters").update({
      status: "draft"
    }).eq("id", context.chapterId);
    return {
      approvedVersionId: null
    };
  }
  await db.from("chapter_versions").update({
    origin: "approved",
    is_approved: true,
    approved_by: decidedBy,
    approved_at: now
  }).eq("id", proposedVersionId);
  await db.from("chapters").update({
    current_version_id: proposedVersionId,
    status: "approved"
  }).eq("id", context.chapterId);
  return {
    approvedVersionId: proposedVersionId
  };
}
__name(applyDecision, "applyDecision");
async function markStep(workflowRunId, step, completed, total) {
  await createAdminClient().from("workflow_runs").update({
    current_step: step,
    completed_steps: completed,
    total_steps: total,
    status: "running"
  }).eq("id", workflowRunId);
}
__name(markStep, "markStep");
async function finishRun(workflowRunId, status, output, error) {
  await createAdminClient().from("workflow_runs").update({
    status,
    output,
    error,
    finished_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", workflowRunId);
}
__name(finishRun, "finishRun");
async function updateVolumePreview(context) {
  try {
    const esito = await rebuildVolumePreviewWith(createAdminClient(), {
      projectId: context.projectId,
      organizationId: context.organizationId,
      actorId: context.actorId
    });
    return {
      ok: esito.ok,
      chapters: esito.chapters ?? 0,
      words: esito.words ?? 0,
      message: esito.message
    };
  } catch (error) {
    return {
      ok: false,
      chapters: 0,
      words: 0,
      message: `Anteprima non aggiornata: ${error.message}`
    };
  }
}
__name(updateVolumePreview, "updateVolumePreview");
registerStepFunction3("step//./src/workflows/chapter-audit-steps//loadChapter", loadChapter);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//draftChapter", draftChapter);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//verifyTechnical", verifyTechnical);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//auditSources", auditSources);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//enrichWithLibrary", enrichWithLibrary);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//verifyCitations", verifyCitations);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//persistAudit", persistAudit);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//proposeRevision", proposeRevision);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//planVisuals", planVisuals);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//generateDiagrams", generateDiagrams);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//requestApproval", requestApproval);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//applyDecision", applyDecision);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//markStep", markStep);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//finishRun", finishRun);
registerStepFunction3("step//./src/workflows/chapter-audit-steps//updateVolumePreview", updateVolumePreview);

// virtual-entry.js
import { stepEntrypoint, stepEntrypoint as stepEntrypoint2 } from "workflow/runtime";
export {
  stepEntrypoint as HEAD,
  stepEntrypoint2 as POST
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3dvcmtmbG93L3NyYy9pbnRlcm5hbC9idWlsdGlucy50cyIsICIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvd29ya2Zsb3cvc3JjL3N0ZGxpYi50cyIsICIuLi8uLi8uLi8uLi8uLi93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy50cyIsICIuLi8uLi8uLi8uLi8uLi8uLi92aXJ0dWFsLWVudHJ5LmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKipcbiAqIFRoZXNlIGFyZSB0aGUgYnVpbHQtaW4gc3RlcHMgdGhhdCBhcmUgXCJhdXRvbWF0aWNhbGx5IGF2YWlsYWJsZVwiIGluIHRoZSB3b3JrZmxvdyBzY29wZS4gVGhleSBhcmVcbiAqIHNpbWlsYXIgdG8gXCJzdGRsaWJcIiBleGNlcHQgdGhhdCBhcmUgbm90IG1lYW50IHRvIGJlIGltcG9ydGVkIGJ5IHVzZXJzLCBidXQgYXJlIGluc3RlYWQgXCJqdXN0IGF2YWlsYWJsZVwiXG4gKiBhbG9uZ3NpZGUgdXNlciBkZWZpbmVkIHN0ZXBzLiBUaGV5IGFyZSB1c2VkIGludGVybmFsbHkgYnkgdGhlIHJ1bnRpbWVcbiAqL1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gX19idWlsdGluX3Jlc3BvbnNlX2FycmF5X2J1ZmZlcihcbiAgdGhpczogUmVxdWVzdCB8IFJlc3BvbnNlXG4pIHtcbiAgJ3VzZSBzdGVwJztcbiAgcmV0dXJuIHRoaXMuYXJyYXlCdWZmZXIoKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIF9fYnVpbHRpbl9yZXNwb25zZV9qc29uKHRoaXM6IFJlcXVlc3QgfCBSZXNwb25zZSkge1xuICAndXNlIHN0ZXAnO1xuICByZXR1cm4gdGhpcy5qc29uKCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBfX2J1aWx0aW5fcmVzcG9uc2VfdGV4dCh0aGlzOiBSZXF1ZXN0IHwgUmVzcG9uc2UpIHtcbiAgJ3VzZSBzdGVwJztcbiAgcmV0dXJuIHRoaXMudGV4dCgpO1xufVxuIiwgIi8qKlxuICogVGhpcyBpcyB0aGUgXCJzdGFuZGFyZCBsaWJyYXJ5XCIgb2Ygc3RlcHMgdGhhdCB3ZSBtYWtlIGF2YWlsYWJsZSB0byBhbGwgd29ya2Zsb3cgdXNlcnMuXG4gKiBUaGUgY2FuIGJlIGltcG9ydGVkIGxpa2Ugc286IGBpbXBvcnQgeyBmZXRjaCB9IGZyb20gJ3dvcmtmbG93J2AuIGFuZCB1c2VkIGluIHdvcmtmbG93LlxuICogVGhlIG5lZWQgdG8gYmUgZXhwb3J0ZWQgZGlyZWN0bHkgaW4gdGhpcyBwYWNrYWdlIGFuZCBjYW5ub3QgbGl2ZSBpbiBgY29yZWAgdG8gcHJldmVudFxuICogY2lyY3VsYXIgZGVwZW5kZW5jaWVzIHBvc3QtY29tcGlsYXRpb24uXG4gKi9cblxuLyoqXG4gKiBBIGhvaXN0ZWQgYGZldGNoKClgIGZ1bmN0aW9uIHRoYXQgaXMgZXhlY3V0ZWQgYXMgYSBcInN0ZXBcIiBmdW5jdGlvbixcbiAqIGZvciB1c2Ugd2l0aGluIHdvcmtmbG93IGZ1bmN0aW9ucy5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9GZXRjaF9BUElcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoKC4uLmFyZ3M6IFBhcmFtZXRlcnM8dHlwZW9mIGdsb2JhbFRoaXMuZmV0Y2g+KSB7XG4gICd1c2Ugc3RlcCc7XG4gIHJldHVybiBnbG9iYWxUaGlzLmZldGNoKC4uLmFyZ3MpO1xufVxuIiwgImltcG9ydCB7IHJlZ2lzdGVyU3RlcEZ1bmN0aW9uIH0gZnJvbSBcIndvcmtmbG93L2ludGVybmFsL3ByaXZhdGVcIjtcbmltcG9ydCAnc2VydmVyLW9ubHknO1xuaW1wb3J0IHsgY3JlYXRlQWRtaW5DbGllbnQgfSBmcm9tICdAL2xpYi9zdXBhYmFzZS9hZG1pbic7XG5pbXBvcnQgeyBydW5BZ2VudCB9IGZyb20gJ0AvbGliL2FnZW50cy9ydW5uZXInO1xuaW1wb3J0IHsgY2hhcHRlckFwcGFyYXR1c0FnZW50LCBjaGFwdGVyUGxhbkFnZW50LCBjaGFwdGVyU2VjdGlvbkFnZW50LCBzb3VyY2VBdWRpdG9yQWdlbnQsIHRlY2huaWNhbFZlcmlmaWVyQWdlbnQsIHRlY2huaWNhbFdyaXRlckFnZW50LCB2aXN1YWxQbGFuQWdlbnQgfSBmcm9tICdAL2xpYi9hZ2VudHMvZGVmaW5pdGlvbnMnO1xuaW1wb3J0IHsgYW5hbHl6ZU1hcmtkb3duIH0gZnJvbSAnQC9saWIvaW5nZXN0L21hcmtkb3duJztcbmltcG9ydCB7IGlzdHJ1emlvbmlFZGl0b3JpYWxpIH0gZnJvbSAnQC9saWIvZWRpdG9yaWFsL2RpcmV6aW9uZSc7XG5pbXBvcnQgeyByZWJ1aWxkVm9sdW1lUHJldmlld1dpdGggfSBmcm9tICdAL2xpYi9wdWJsaXNoL3ByZXZpZXcnO1xuaW1wb3J0IHsgYnVpbGRQcm9qZWN0SW5kZXggfSBmcm9tICdAL2xpYi9zb3VyY2VzL2xpYnJhcnknO1xuaW1wb3J0IHsgbWVyZ2VTdWdnZXN0aW9ucywgcmVzZWFyY2hDbGFpbXMgfSBmcm9tICdAL2xpYi9zb3VyY2VzL3Jlc2VhcmNoJztcbmltcG9ydCB7IHZlcmlmeVVybHMgfSBmcm9tICdAL2xpYi9zb3VyY2VzL3ZlcmlmeS11cmwnO1xuaW1wb3J0IHsgZXh0cmFjdENvbmZpZ0Jsb2NrIH0gZnJvbSAnQC9saWIvYWdlbnRzL2FuYWx5c2lzL2RhdGFmb3JtJztcbmltcG9ydCB7IGJ1aWxkRGVwZW5kZW5jeURhZyB9IGZyb20gJ0AvbGliL3Zpc3VhbC9tZXJtYWlkLWRhZyc7XG4vKipfX2ludGVybmFsX3dvcmtmbG93c3tcInN0ZXBzXCI6e1wic3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLnRzXCI6e1wiYXBwbHlEZWNpc2lvblwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2FwcGx5RGVjaXNpb25cIn0sXCJhdWRpdFNvdXJjZXNcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9hdWRpdFNvdXJjZXNcIn0sXCJkcmFmdENoYXB0ZXJcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9kcmFmdENoYXB0ZXJcIn0sXCJlbnJpY2hXaXRoTGlicmFyeVwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2VucmljaFdpdGhMaWJyYXJ5XCJ9LFwiZmluaXNoUnVuXCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZmluaXNoUnVuXCJ9LFwiZ2VuZXJhdGVEaWFncmFtc1wiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2dlbmVyYXRlRGlhZ3JhbXNcIn0sXCJsb2FkQ2hhcHRlclwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2xvYWRDaGFwdGVyXCJ9LFwibWFya1N0ZXBcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9tYXJrU3RlcFwifSxcInBlcnNpc3RBdWRpdFwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3BlcnNpc3RBdWRpdFwifSxcInBsYW5WaXN1YWxzXCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vcGxhblZpc3VhbHNcIn0sXCJwcm9wb3NlUmV2aXNpb25cIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9wcm9wb3NlUmV2aXNpb25cIn0sXCJyZXF1ZXN0QXBwcm92YWxcIjp7XCJzdGVwSWRcIjpcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9yZXF1ZXN0QXBwcm92YWxcIn0sXCJ1cGRhdGVWb2x1bWVQcmV2aWV3XCI6e1wic3RlcElkXCI6XCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vdXBkYXRlVm9sdW1lUHJldmlld1wifSxcInZlcmlmeUNpdGF0aW9uc1wiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3ZlcmlmeUNpdGF0aW9uc1wifSxcInZlcmlmeVRlY2huaWNhbFwiOntcInN0ZXBJZFwiOlwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3ZlcmlmeVRlY2huaWNhbFwifX19fSovO1xuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAxIFx1MDBCNyBDYXJpY2FtZW50byBkZWwgY2FwaXRvbG8gZSBkZWxsZSBmb250aSBjb2xsZWdhdGVcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRDaGFwdGVyKGNvbnRleHQpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgeyBkYXRhOiBjaGFwdGVyLCBlcnJvciB9ID0gYXdhaXQgZGIuZnJvbSgnY2hhcHRlcnMnKS5zZWxlY3QoJ2lkLCBudW1iZXIsIHRpdGxlLCBjdXJyZW50X3ZlcnNpb25faWQsIG9yZ2FuaXphdGlvbl9pZCwgcHJvamVjdF9pZCcpLmVxKCdpZCcsIGNvbnRleHQuY2hhcHRlcklkKS5zaW5nbGUoKTtcbiAgICBpZiAoZXJyb3IgfHwgIWNoYXB0ZXIpIHRocm93IG5ldyBFcnJvcignQ2FwaXRvbG8gbm9uIHRyb3ZhdG8uJyk7XG4gICAgLy8gQ29udHJvbGxvIGRpIGFwcGFydGVuZW56YSBlc3BsaWNpdG86IGxvIHN0ZXAgdXNhIGlsIHNlcnZpY2Ugcm9sZSwgY2hlXG4gICAgLy8gaWdub3JhIGxhIFJMUy4gTGEgY29lcmVuemEgdmEgcml2ZXJpZmljYXRhIHF1aS5cbiAgICBpZiAoY2hhcHRlci5vcmdhbml6YXRpb25faWQgIT09IGNvbnRleHQub3JnYW5pemF0aW9uSWQgfHwgY2hhcHRlci5wcm9qZWN0X2lkICE9PSBjb250ZXh0LnByb2plY3RJZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lsIGNhcGl0b2xvIG5vbiBhcHBhcnRpZW5lIGFsIHByb2dldHRvIGluZGljYXRvLicpO1xuICAgIH1cbiAgICBjb25zdCB7IGRhdGE6IHZlcnNpb24gfSA9IGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJfdmVyc2lvbnMnKS5zZWxlY3QoJ2lkLCBjb250ZW50X21kJykuZXEoJ2NoYXB0ZXJfaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCkub3JkZXIoJ3ZlcnNpb25fbm8nLCB7XG4gICAgICAgIGFzY2VuZGluZzogZmFsc2VcbiAgICB9KS5saW1pdCgxKS5tYXliZVNpbmdsZSgpO1xuICAgIGlmICghdmVyc2lvbikgdGhyb3cgbmV3IEVycm9yKCdJbCBjYXBpdG9sbyBub24gaGEgYWxjdW5hIHZlcnNpb25lIGRhIGFuYWxpenphcmUuJyk7XG4gICAgY29uc3QgYW5hbHlzaXMgPSBhbmFseXplTWFya2Rvd24odmVyc2lvbi5jb250ZW50X21kKTtcbiAgICBjb25zdCBpc0luY3JlbWVudGFsID0gYW5hbHlzaXMuY29kZUJsb2Nrcy5zb21lKChibG9jayk9PntcbiAgICAgICAgY29uc3QgY29uZmlnID0gZXh0cmFjdENvbmZpZ0Jsb2NrKGJsb2NrLmNvbnRlbnQpO1xuICAgICAgICByZXR1cm4gY29uZmlnICE9PSBudWxsICYmIC9cXGJ0eXBlXFxzKjpcXHMqW1wiJ11pbmNyZW1lbnRhbFtcIiddLy50ZXN0KGNvbmZpZyk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY2hhcHRlcjoge1xuICAgICAgICAgICAgY2hhcHRlcklkOiBjaGFwdGVyLmlkLFxuICAgICAgICAgICAgbnVtYmVyOiBjaGFwdGVyLm51bWJlcixcbiAgICAgICAgICAgIHRpdGxlOiBjaGFwdGVyLnRpdGxlLFxuICAgICAgICAgICAgY29udGVudE1kOiB2ZXJzaW9uLmNvbnRlbnRfbWQsXG4gICAgICAgICAgICBoZWFkaW5nczogYW5hbHlzaXMuaGVhZGluZ3MubWFwKChoKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgbGV2ZWw6IGgubGV2ZWwsXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGgudGV4dCxcbiAgICAgICAgICAgICAgICAgICAgbGluZTogaC5saW5lXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgY29kZUJsb2NrczogYW5hbHlzaXMuY29kZUJsb2Nrcy5tYXAoKGIpPT4oe1xuICAgICAgICAgICAgICAgICAgICBsYW5ndWFnZTogYi5sYW5ndWFnZSxcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogYi5jb250ZW50LFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBiLmxpbmVcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBsaW5rczogYW5hbHlzaXMubGlua3MsXG4gICAgICAgICAgICBmaWd1cmVzOiBhbmFseXNpcy5maWd1cmVzLm1hcCgoZik9Pih7XG4gICAgICAgICAgICAgICAgICAgIGFsdDogZi5hbHQsXG4gICAgICAgICAgICAgICAgICAgIHNyYzogZi5zcmMsXG4gICAgICAgICAgICAgICAgICAgIGxpbmU6IGYubGluZVxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyczogYW5hbHlzaXMucGxhY2Vob2xkZXJzLm1hcCgocCk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBwLmxpbmVcbiAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgfSxcbiAgICAgICAgdmVyc2lvbklkOiB2ZXJzaW9uLmlkLFxuICAgICAgICBpc0luY3JlbWVudGFsXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMS1iaXMgXHUwMEI3IFN0ZXN1cmEgZGVsIGNhcGl0b2xvXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQ29tcG9uZSBpbCBjYXBpdG9sbyBkYWxsZSBwYXJ0aS5cbiAqXG4gKiBMJ2Fzc2VtYmxhZ2dpbyBcdTAwRTggY29kaWNlLCBub24gdW4ndWx0ZXJpb3JlIHJpY2hpZXN0YSBhbCBtb2RlbGxvOiBsJ29yZGluZVxuICogZGVsbGUgc2V6aW9uaSwgbGEgbnVtZXJhemlvbmUgZSBsYSBmb3JtYSBkZWxsJ2FwcGFyYXRvIHNvbm8gZGVjaXNpb25pXG4gKiBlZGl0b3JpYWxpIGdpXHUwMEUwIHByZXNlLCBlIGZhcmxlIHJpZXNlZ3VpcmUgYSB1biBtb2RlbGxvIGxlIHJlbmRlcmViYmUgaW5jZXJ0ZVxuICogYSBvZ25pIGVzZWN1emlvbmUuXG4gKi8gZnVuY3Rpb24gY29tcG9uaUNhcGl0b2xvKG51bWVybywgdGl0b2xvLCBvYmlldHRpdmksIGNvcnBvLCBhcHBhcmF0bykge1xuICAgIGNvbnN0IHBhcnRpID0gW1xuICAgICAgICBgIyAke251bWVybyAhPT0gbnVsbCA/IGBDYXBpdG9sbyAke251bWVyb30gLSBgIDogJyd9JHt0aXRvbG99YCxcbiAgICAgICAgJycsXG4gICAgICAgICc+ICoqT0JJRVRUSVZJIERFTCBDQVBJVE9MTyoqJyxcbiAgICAgICAgJz4nLFxuICAgICAgICAuLi5vYmlldHRpdmkubWFwKChvYmlldHRpdm8pPT5gPiAtICR7b2JpZXR0aXZvfWApLFxuICAgICAgICAnJyxcbiAgICAgICAgY29ycG8sXG4gICAgICAgICcnXG4gICAgXTtcbiAgICBpZiAoYXBwYXJhdG8uYmVzdFByYWN0aWNlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHBhcnRpLnB1c2goJyMjIEJlc3QgcHJhY3RpY2UnLCAnJywgLi4uYXBwYXJhdG8uYmVzdFByYWN0aWNlcy5tYXAoKHZvY2UpPT5gLSAke3ZvY2V9YCksICcnKTtcbiAgICB9XG4gICAgaWYgKGFwcGFyYXRvLmNvbW1vbkVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHBhcnRpLnB1c2goJyMjIEVycm9yaSBjb211bmknLCAnJywgLi4uYXBwYXJhdG8uY29tbW9uRXJyb3JzLm1hcCgodm9jZSk9PmAtICR7dm9jZX1gKSwgJycpO1xuICAgIH1cbiAgICBwYXJ0aS5wdXNoKCcjIyBSaWFzc3VudG8nLCAnJywgYXBwYXJhdG8uc3VtbWFyeSwgJycpO1xuICAgIHBhcnRpLnB1c2goJyMjIFB1bnRpIGNoaWF2ZScsICcnLCAuLi5hcHBhcmF0by5rZXlQb2ludHMubWFwKCh2b2NlKT0+YC0gJHt2b2NlfWApLCAnJyk7XG4gICAgaWYgKGFwcGFyYXRvLnF1aXoubGVuZ3RoID4gMCkge1xuICAgICAgICBwYXJ0aS5wdXNoKCcjIyBRdWl6JywgJycsICdQZXIgb2duaSBkb21hbmRhIHVuYSBzb2xhIHJpc3Bvc3RhIFx1MDBFOCBjb3JyZXR0YS4nLCAnJyk7XG4gICAgICAgIGFwcGFyYXRvLnF1aXouZm9yRWFjaCgoZG9tYW5kYSwgaW5kaWNlKT0+e1xuICAgICAgICAgICAgcGFydGkucHVzaChgJHtpbmRpY2UgKyAxfS4gKioke2RvbWFuZGEucXVlc3Rpb259KipgLCAnJyk7XG4gICAgICAgICAgICBkb21hbmRhLm9wdGlvbnMuZm9yRWFjaCgob3B6aW9uZSwgaSk9PntcbiAgICAgICAgICAgICAgICBwYXJ0aS5wdXNoKGAgICAke1N0cmluZy5mcm9tQ2hhckNvZGUoOTcgKyBpKX0pICR7b3B6aW9uZX1gKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcGFydGkucHVzaCgnJyk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBMZSBzb2x1emlvbmkgc3Rhbm5vIGluIGZvbmRvIGUgbm9uIGFjY2FudG8gYWxsYSBkb21hbmRhOiB1biBxdWl6IGNvbiBsYVxuICAgICAgICAvLyByaXNwb3N0YSBhIHZpc3RhIG5vbiB2ZXJpZmljYSBudWxsYS5cbiAgICAgICAgcGFydGkucHVzaCgnKipTb2x1emlvbmk6KiogJyArIGFwcGFyYXRvLnF1aXoubWFwKChkb21hbmRhLCBpbmRpY2UpPT5gJHtpbmRpY2UgKyAxfS0ke1N0cmluZy5mcm9tQ2hhckNvZGUoOTcgKyBkb21hbmRhLmNvcnJlY3QpfWApLmpvaW4oJywgJyksICcnKTtcbiAgICB9XG4gICAgaWYgKGFwcGFyYXRvLmxhYi50cmltKCkpIHBhcnRpLnB1c2goJyMjIExhYm9yYXRvcmlvJywgJycsIGFwcGFyYXRvLmxhYi50cmltKCksICcnKTtcbiAgICAvLyBOZXNzdW5hIHNlemlvbmUgZGkgcmlmZXJpbWVudGk6IGxlIGZvbnRpIGRlbGwnb3BlcmEgc3Rhbm5vIHR1dHRlIG5lbFxuICAgIC8vIGNhcGl0b2xvIGRpIGJpYmxpb2dyYWZpYSwgZG92ZSBzaSBhZ2dpb3JuYW5vIGluIHVuIHBvc3RvIHNvbG8gaW52ZWNlIGNoZVxuICAgIC8vIGluIHRyZW50YSBjb2RlIGRpIGNhcGl0b2xvLlxuICAgIHJldHVybiBwYXJ0aS5qb2luKCdcXG4nKTtcbn1cbi8qKlxuICogU2NyaXZlIGlsIGNhcGl0b2xvIHBlciBpbnRlcm8gcHJpbWEgY2hlIGwnYXVkaXQgbG8gZXNhbWluaS5cbiAqXG4gKiBMJ29yZGluZSBub24gXHUwMEU4IHVuIGRldHRhZ2xpbzogdmVyaWZpY2FyZSB1biBzZWduYXBvc3RvIHNpZ25pZmljYSB2ZXJpZmljYXJlXG4gKiBuaWVudGUsIGUgY2hpZWRlcmUgdW4nYXBwcm92YXppb25lIHN1IHRyZW50YWNpbnF1ZSBwYXJvbGUgc2lnbmlmaWNhIGNoaWVkZXJlXG4gKiBhIHVuYSBwZXJzb25hIGRpIGRlY2lkZXJlIHN1bCBudWxsYS5cbiAqXG4gKiBMYSBzdGVzdXJhIGF2dmllbmUgaW4gdHJlIHBhc3NhZ2dpIFx1MjAxNCBwaWFubywgc2V6aW9uaSwgYXBwYXJhdG8gXHUyMDE0IHBlcmNoXHUwMEU5IHVuXG4gKiBjYXBpdG9sbyBjb21wbGV0byBub24gZW50cmEgaW4gdW5hIHJpc3Bvc3RhIHNvbGE6IGNoaWVkZXJsbyBpbiB1bmEgdm9sdGFcbiAqIHByb2R1Y2UgdW4gY2FwaXRvbG8gY2hlIHNpIGFjY29yY2lhIGRhIHNvbG8gcGVyIHN0YXJjaSBkZW50cm8uXG4gKlxuICogTGEgdmVyc2lvbmUgY3JlYXRhIHF1aSBub24gc29zdGl0dWlzY2UgcXVlbGxhIGRpIHBhcnRlbnphOiBkaXZlbnRhIGxhXG4gKiBjb3JyZW50ZSwgbWEgaWwgc2VnbmFwb3N0byByZXN0YSBjb21lIHJhZGljZSBkZWxsYSBjYXRlbmEsIGVkIFx1MDBFOCBxdWVsbG8gY2hlIGlsXG4gKiByZXZpc29yZSB2ZWRyXHUwMEUwIGEgc2luaXN0cmEgbmVsIGNvbmZyb250by5cbiAqLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gZHJhZnRDaGFwdGVyKGNvbnRleHQsIGNoYXB0ZXIsIGJhc2VWZXJzaW9uSWQpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgW3sgZGF0YTogY2hhcHRlclJvdyB9LCB7IGRhdGE6IHByb2plY3QgfV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIGRiLmZyb20oJ2NoYXB0ZXJzJykuc2VsZWN0KCdwYXJ0X2lkJykuZXEoJ2lkJywgY29udGV4dC5jaGFwdGVySWQpLm1heWJlU2luZ2xlKCksXG4gICAgICAgIGRiLmZyb20oJ3Byb2plY3RzJykuc2VsZWN0KCdsYW5ndWFnZSwgbGV2ZWwsIHRvbmUsIHJlZ2lzdGVyLCBzdHlsZV9ub3RlcycpLmVxKCdpZCcsIGNvbnRleHQucHJvamVjdElkKS5tYXliZVNpbmdsZSgpXG4gICAgXSk7XG4gICAgY29uc3QgeyBkYXRhOiBwYXJ0IH0gPSBjaGFwdGVyUm93Py5wYXJ0X2lkID8gYXdhaXQgZGIuZnJvbSgncHVibGljYXRpb25fcGFydHMnKS5zZWxlY3QoJ3RpdGxlJykuZXEoJ2lkJywgY2hhcHRlclJvdy5wYXJ0X2lkKS5tYXliZVNpbmdsZSgpIDoge1xuICAgICAgICBkYXRhOiBudWxsXG4gICAgfTtcbiAgICAvLyBMZSBzdGVzc2UgZm9udGkgY2hlIGhhbm5vIHByb2RvdHRvIGxhIHN0cnV0dHVyYSBwcm9kdWNvbm8gaWwgdGVzdG86IHVuXG4gICAgLy8gY2FwaXRvbG8gbm9uIHB1XHUwMEYyIHBvZ2dpYXJlIHN1IG1hdGVyaWFsZSBjaGUgbCdpbmRpY2Ugbm9uIGNvbm9zY2V2YS5cbiAgICBjb25zdCBbeyBkYXRhOiByZWZlcmVuY2VzIH0sIHsgZGF0YTogcmVmZXJlbmNlQ2h1bmtzIH0sIHsgZGF0YTogc291cmNlQ2h1bmtzIH1dID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICBkYi5mcm9tKCdyZWZlcmVuY2Vfc291cmNlcycpLnNlbGVjdCgndGl0bGUsIHB1Ymxpc2hlciwgdXJsJykub3IoYHByb2plY3RfaWQuZXEuJHtjb250ZXh0LnByb2plY3RJZH0scHJvamVjdF9pZC5pcy5udWxsYCkubmVxKCdzdGF0dXMnLCAncHJvcG9zZWQnKS5saW1pdCg2MCksXG4gICAgICAgIGRiLmZyb20oJ3JlZmVyZW5jZV9jaHVua3MnKS5zZWxlY3QoJ2hlYWRpbmcsIGNvbnRlbnQnKS5vcihgcHJvamVjdF9pZC5lcS4ke2NvbnRleHQucHJvamVjdElkfSxwcm9qZWN0X2lkLmlzLm51bGxgKS5vcmRlcignY2h1bmtfaW5kZXgnLCB7XG4gICAgICAgICAgICBhc2NlbmRpbmc6IHRydWVcbiAgICAgICAgfSkubGltaXQoMTIwKSxcbiAgICAgICAgZGIuZnJvbSgnc291cmNlX2NodW5rcycpLnNlbGVjdCgnaGVhZGluZ19wYXRoLCBjb250ZW50JykuZXEoJ3Byb2plY3RfaWQnLCBjb250ZXh0LnByb2plY3RJZCkub3JkZXIoJ2NodW5rX2luZGV4Jywge1xuICAgICAgICAgICAgYXNjZW5kaW5nOiB0cnVlXG4gICAgICAgIH0pLmxpbWl0KDEyMClcbiAgICBdKTtcbiAgICBjb25zdCBldmlkZW5jZSA9IFtcbiAgICAgICAgLi4uKHJlZmVyZW5jZUNodW5rcyA/PyBbXSkubWFwKChibG9jY28pPT5gJHtibG9jY28uaGVhZGluZyA/IGAjIyAke2Jsb2Njby5oZWFkaW5nfVxcbmAgOiAnJ30ke2Jsb2Njby5jb250ZW50fWApLFxuICAgICAgICAuLi4oc291cmNlQ2h1bmtzID8/IFtdKS5tYXAoKGJsb2Njbyk9PmAke2Jsb2Njby5oZWFkaW5nX3BhdGg/Lmxlbmd0aCA/IGAjIyAke2Jsb2Njby5oZWFkaW5nX3BhdGguam9pbignID4gJyl9XFxuYCA6ICcnfSR7YmxvY2NvLmNvbnRlbnR9YClcbiAgICBdLmpvaW4oJ1xcblxcbicpLnNsaWNlKDAsIDYwXzAwMCk7XG4gICAgLy8gTCdvYmlldHRpdm8gXHUwMEU4IGNpXHUwMEYyIGNoZSBsYSBmYXNlIGRpIHN0cnV0dHVyYSBoYSBwcm9tZXNzbyBwZXIgcXVlc3RvIGNhcGl0b2xvLlxuICAgIGNvbnN0IG9iaWV0dGl2byA9IGNoYXB0ZXIuY29udGVudE1kLm1hdGNoKC8jI1xccypPYmlldHRpdm9cXHMqXFxuKyhbXFxzXFxTXSo/KSg/OlxcbiN7MSwyfVxcc3wkKS9pKTtcbiAgICBjb25zdCBpbmdyZXNzbyA9IHtcbiAgICAgICAgY2hhcHRlcklkOiBjaGFwdGVyLmNoYXB0ZXJJZCxcbiAgICAgICAgbnVtYmVyOiBjaGFwdGVyLm51bWJlcixcbiAgICAgICAgdGl0bGU6IGNoYXB0ZXIudGl0bGUsXG4gICAgICAgIG9iamVjdGl2ZTogKG9iaWV0dGl2bz8uWzFdID8/ICcnKS50cmltKCkuc2xpY2UoMCwgMjAwMCksXG4gICAgICAgIHBhcnRUaXRsZTogcGFydD8udGl0bGUgPz8gbnVsbCxcbiAgICAgICAgbGFuZ3VhZ2U6IHByb2plY3Q/Lmxhbmd1YWdlID8/ICdpdCcsXG4gICAgICAgIC8vIFNlbnphIHF1ZXN0bywgdHJlIHZvbHVtaSBzdWxsbyBzdGVzc28gYXJnb21lbnRvIHByb2R1cnJlYmJlcm8gbG8gc3Rlc3NvXG4gICAgICAgIC8vIGNhcGl0b2xvIGNvbiB0cmUgdGl0b2xpIGRpdmVyc2kuXG4gICAgICAgIGRpcmV6aW9uZTogaXN0cnV6aW9uaUVkaXRvcmlhbGkoe1xuICAgICAgICAgICAgbGV2ZWw6IHByb2plY3Q/LmxldmVsID8/ICdiYXNlJyxcbiAgICAgICAgICAgIHRvbmU6IHByb2plY3Q/LnRvbmUgPz8gJ2RpZGF0dGljbycsXG4gICAgICAgICAgICByZWdpc3RlcjogcHJvamVjdD8ucmVnaXN0ZXIgPz8gJ3RlY25pY29fb3BlcmF0aXZvJyxcbiAgICAgICAgICAgIHN0eWxlTm90ZXM6IHByb2plY3Q/LnN0eWxlX25vdGVzID8/IG51bGxcbiAgICAgICAgfSksXG4gICAgICAgIHJlZmVyZW5jZXM6IChyZWZlcmVuY2VzID8/IFtdKS5tYXAoKHJpZmVyaW1lbnRvKT0+KHtcbiAgICAgICAgICAgICAgICB0aXRsZTogcmlmZXJpbWVudG8udGl0bGUsXG4gICAgICAgICAgICAgICAgcHVibGlzaGVyOiByaWZlcmltZW50by5wdWJsaXNoZXIgPz8gbnVsbCxcbiAgICAgICAgICAgICAgICB1cmw6IHJpZmVyaW1lbnRvLnVybCA/PyBudWxsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgIGV2aWRlbmNlLFxuICAgICAgICBleGlzdGluZ0NvbnRlbnQ6IGNoYXB0ZXIuY29udGVudE1kXG4gICAgfTtcbiAgICBjb25zdCBjb250ZXN0byA9IHtcbiAgICAgICAgZGIsXG4gICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBjaGFwdGVySWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICB3b3JrZmxvd1J1bklkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIHN0ZXBOYW1lOiAnc3Rlc3VyYS1jYXBpdG9sbydcbiAgICB9O1xuICAgIGNvbnN0IGdhcHMgPSBbXTtcbiAgICBjb25zdCBwaWFubyA9IChhd2FpdCBydW5BZ2VudChjaGFwdGVyUGxhbkFnZW50LCBpbmdyZXNzbywgY29udGVzdG8pKS5vdXRwdXQ7XG4gICAgY29uc3Qgc2NhbGV0dGEgPSBwaWFuby5zZWN0aW9ucy5tYXAoKHNlemlvbmUpPT5zZXppb25lLnRpdGxlKTtcbiAgICAvLyBVbmEgc2V6aW9uZSBwZXIgdm9sdGEgZSBpbiBvcmRpbmU6IG9nbnVuYSB2ZWRlIGxhIHNjYWxldHRhIGludGVyYSwgY29zXHUwMEVDIG5vblxuICAgIC8vIHJpcGV0ZSBjaVx1MDBGMiBjaGUgXHUwMEU4IGdpXHUwMEUwIHN0YXRvIGRldHRvIG5cdTAwRTkgYW50aWNpcGEgY2lcdTAwRjIgY2hlIHZlcnJcdTAwRTAuXG4gICAgY29uc3Qgc2V6aW9uaSA9IFtdO1xuICAgIGZvciAoY29uc3QgW2luZGljZSwgc2V6aW9uZV0gb2YgcGlhbm8uc2VjdGlvbnMuZW50cmllcygpKXtcbiAgICAgICAgY29uc3Qgc2NyaXR0YSA9IChhd2FpdCBydW5BZ2VudChjaGFwdGVyU2VjdGlvbkFnZW50LCB7XG4gICAgICAgICAgICAuLi5pbmdyZXNzbyxcbiAgICAgICAgICAgIHNlY3Rpb25UaXRsZTogc2V6aW9uZS50aXRsZSxcbiAgICAgICAgICAgIHNlY3Rpb25JbnRlbnQ6IHNlemlvbmUuaW50ZW50LFxuICAgICAgICAgICAgbmVlZHNDb2RlOiBzZXppb25lLm5lZWRzQ29kZSxcbiAgICAgICAgICAgIG5lZWRzRmlndXJlOiBzZXppb25lLm5lZWRzRmlndXJlLFxuICAgICAgICAgICAgc2VjdGlvbk51bWJlcjogaW5kaWNlICsgMSxcbiAgICAgICAgICAgIG91dGxpbmU6IHNjYWxldHRhLFxuICAgICAgICAgICAgb2JqZWN0aXZlczogcGlhbm8ub2JqZWN0aXZlc1xuICAgICAgICB9LCBjb250ZXN0bykpLm91dHB1dDtcbiAgICAgICAgc2V6aW9uaS5wdXNoKHNjcml0dGEuY29udGVudE1kLnRyaW0oKSk7XG4gICAgICAgIGdhcHMucHVzaCguLi5zY3JpdHRhLmdhcHMpO1xuICAgIH1cbiAgICBjb25zdCBjb3JwbyA9IHNlemlvbmkuam9pbignXFxuXFxuJyk7XG4gICAgLy8gTCdhcHBhcmF0byByaWNldmUgaWwgY29ycG8gZ2lcdTAwRTAgc2NyaXR0bzogdW4gcmlhc3N1bnRvIGRlZG90dG8gZGFsbGEgc2NhbGV0dGFcbiAgICAvLyByaWFzc3VtZXJlYmJlIGxlIGludGVuemlvbmksIG5vbiBpbCBjYXBpdG9sby5cbiAgICBjb25zdCBhcHBhcmF0byA9IChhd2FpdCBydW5BZ2VudChjaGFwdGVyQXBwYXJhdHVzQWdlbnQsIHtcbiAgICAgICAgLi4uaW5ncmVzc28sXG4gICAgICAgIG9iamVjdGl2ZXM6IHBpYW5vLm9iamVjdGl2ZXMsXG4gICAgICAgIG91dGxpbmU6IHNjYWxldHRhLFxuICAgICAgICBib2R5OiBjb3Jwb1xuICAgIH0sIGNvbnRlc3RvKSkub3V0cHV0O1xuICAgIGdhcHMucHVzaCguLi5hcHBhcmF0by5nYXBzKTtcbiAgICBjb25zdCBjb250ZW50TWQgPSBjb21wb25pQ2FwaXRvbG8oY2hhcHRlci5udW1iZXIsIGNoYXB0ZXIudGl0bGUsIHBpYW5vLm9iamVjdGl2ZXMsIGNvcnBvLCBhcHBhcmF0byk7XG4gICAgY29uc3QgeyBkYXRhOiBsYXN0IH0gPSBhd2FpdCBkYi5mcm9tKCdjaGFwdGVyX3ZlcnNpb25zJykuc2VsZWN0KCd2ZXJzaW9uX25vJykuZXEoJ2NoYXB0ZXJfaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCkub3JkZXIoJ3ZlcnNpb25fbm8nLCB7XG4gICAgICAgIGFzY2VuZGluZzogZmFsc2VcbiAgICB9KS5saW1pdCgxKS5tYXliZVNpbmdsZSgpO1xuICAgIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGNvbnRlbnRNZCkpO1xuICAgIGNvbnN0IGNvbnRlbnRIYXNoID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKS5tYXAoKGJ5dGUpPT5ieXRlLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCcnKTtcbiAgICBjb25zdCBhbmFseXNpcyA9IGFuYWx5emVNYXJrZG93bihjb250ZW50TWQpO1xuICAgIGNvbnN0IHdvcmRDb3VudCA9IGNvbnRlbnRNZC5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKS5sZW5ndGg7XG4gICAgY29uc3QgeyBkYXRhOiBjcmVhdGVkLCBlcnJvciB9ID0gYXdhaXQgZGIuZnJvbSgnY2hhcHRlcl92ZXJzaW9ucycpLmluc2VydCh7XG4gICAgICAgIGNoYXB0ZXJfaWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICBwcm9qZWN0X2lkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgb3JnYW5pemF0aW9uX2lkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICB2ZXJzaW9uX25vOiAobGFzdD8udmVyc2lvbl9ubyA/PyAwKSArIDEsXG4gICAgICAgIG9yaWdpbjogJ2FpX3Byb3Bvc2FsJyxcbiAgICAgICAgY29udGVudF9tZDogY29udGVudE1kLFxuICAgICAgICBjb250ZW50X2hhc2g6IGNvbnRlbnRIYXNoLFxuICAgICAgICBzdW1tYXJ5OiBgQ2FwaXRvbG8gc2NyaXR0byBpbiAke3BpYW5vLnNlY3Rpb25zLmxlbmd0aH0gc2V6aW9uaWAgKyBgJHtnYXBzLmxlbmd0aCA+IDAgPyBgLCBjb24gJHtnYXBzLmxlbmd0aH0gcHVudGkgbm9uIGNvcGVydGkgZGFsbGUgZm9udGlgIDogJyd9LmAsXG4gICAgICAgIHdvcmRfY291bnQ6IHdvcmRDb3VudCxcbiAgICAgICAgcGFyZW50X3ZlcnNpb25faWQ6IGJhc2VWZXJzaW9uSWQsXG4gICAgICAgIHdvcmtmbG93X3J1bl9pZDogY29udGV4dC53b3JrZmxvd1J1bklkXG4gICAgfSkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xuICAgIGlmIChlcnJvciB8fCAhY3JlYXRlZCkgdGhyb3cgbmV3IEVycm9yKGVycm9yPy5tZXNzYWdlID8/ICdTdGVzdXJhIG5vbiByZWdpc3RyYXRhLicpO1xuICAgIGF3YWl0IGRiLmZyb20oJ2NoYXB0ZXJzJykudXBkYXRlKHtcbiAgICAgICAgY3VycmVudF92ZXJzaW9uX2lkOiBjcmVhdGVkLmlkLFxuICAgICAgICBzdGF0dXM6ICdpbl9yZXZpZXcnLFxuICAgICAgICB3b3JkX2NvdW50OiB3b3JkQ291bnQsXG4gICAgICAgIGNvZGVfYmxvY2tfY291bnQ6IGFuYWx5c2lzLmNvZGVCbG9ja3MubGVuZ3RoLFxuICAgICAgICBoZWFkaW5nX2NvdW50OiBhbmFseXNpcy5oZWFkaW5ncy5sZW5ndGgsXG4gICAgICAgIGZpZ3VyZV9jb3VudDogYW5hbHlzaXMuZmlndXJlcy5sZW5ndGgsXG4gICAgICAgIHBsYWNlaG9sZGVyX2NvdW50OiBhbmFseXNpcy5wbGFjZWhvbGRlcnMubGVuZ3RoLFxuICAgICAgICBsaW5rX2NvdW50OiBhbmFseXNpcy5saW5rcy5sZW5ndGhcbiAgICB9KS5lcSgnaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY2hhcHRlcjoge1xuICAgICAgICAgICAgLi4uY2hhcHRlcixcbiAgICAgICAgICAgIGNvbnRlbnRNZCxcbiAgICAgICAgICAgIGhlYWRpbmdzOiBhbmFseXNpcy5oZWFkaW5ncy5tYXAoKGgpPT4oe1xuICAgICAgICAgICAgICAgICAgICBsZXZlbDogaC5sZXZlbCxcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogaC50ZXh0LFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBoLmxpbmVcbiAgICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBjb2RlQmxvY2tzOiBhbmFseXNpcy5jb2RlQmxvY2tzLm1hcCgoYik9Pih7XG4gICAgICAgICAgICAgICAgICAgIGxhbmd1YWdlOiBiLmxhbmd1YWdlLFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBiLmNvbnRlbnQsXG4gICAgICAgICAgICAgICAgICAgIGxpbmU6IGIubGluZVxuICAgICAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIGxpbmtzOiBhbmFseXNpcy5saW5rcyxcbiAgICAgICAgICAgIGZpZ3VyZXM6IGFuYWx5c2lzLmZpZ3VyZXMubWFwKChmKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgYWx0OiBmLmFsdCxcbiAgICAgICAgICAgICAgICAgICAgc3JjOiBmLnNyYyxcbiAgICAgICAgICAgICAgICAgICAgbGluZTogZi5saW5lXG4gICAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgcGxhY2Vob2xkZXJzOiBhbmFseXNpcy5wbGFjZWhvbGRlcnMubWFwKChwKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHAuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgIGxpbmU6IHAubGluZVxuICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICB9LFxuICAgICAgICB2ZXJzaW9uSWQ6IGNyZWF0ZWQuaWQsXG4gICAgICAgIGdhcHMsXG4gICAgICAgIGdyb3VuZGVkOiBnYXBzLmxlbmd0aCA9PT0gMFxuICAgIH07XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDIgXHUwMEI3IEFuYWxpc2kgdGVjbmljYSBkZWwgY29kaWNlIGUgZGVsbGUgYWZmZXJtYXppb25pXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB2ZXJpZnlUZWNobmljYWwoY29udGV4dCwgY2hhcHRlcikge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJ1bkFnZW50KHRlY2huaWNhbFZlcmlmaWVyQWdlbnQsIGNoYXB0ZXIsIHtcbiAgICAgICAgZGI6IGNyZWF0ZUFkbWluQ2xpZW50KCksXG4gICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBjaGFwdGVySWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICB3b3JrZmxvd1J1bklkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIHN0ZXBOYW1lOiAndmVyaWZpY2EtdGVjbmljYSdcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0Lm91dHB1dDtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMyBcdTAwQjcgVmVyaWZpY2EgZGVpIHJpZmVyaW1lbnRpIGUgcmljZXJjYSBhdXRvbWF0aWNhIGRlbGxlIGZvbnRpIG1hbmNhbnRpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogUmljZXZlIGxlIGFmZmVybWF6aW9uaSBpbmRpdmlkdWF0ZSBhbCBwYXNzYWdnaW8gcHJlY2VkZW50ZTogc2VuemEgZGkgZXNzZVxuICogcG90cmViYmUgZ2l1ZGljYXJlIGxlIGZvbnRpIHByZXNlbnRpLCBtYSBub24gY2VyY2FyZSBxdWVsbGUgY2hlIG1hbmNhbm8uXG4gKlxuICogU2UgaWwgY2FwaXRvbG8gbm9uIG9mZnJlIG5cdTAwRTkgY29sbGVnYW1lbnRpIG5cdTAwRTkgYWZmZXJtYXppb25pLCBsJ2FnZW50ZSBub24gdmllbmVcbiAqIGludGVycGVsbGF0bzogY29uIGxlIG1hbmkgdnVvdGUgZGVkdXJyZWJiZSBkYWwgdGl0b2xvIGFmZmVybWF6aW9uaSBjaGUgbmVsXG4gKiB0ZXN0byBub24gY2kgc29ubywgZSB1biBlbGVuY28gdmVyb3NpbWlsZSBcdTAwRTggcGVnZ2lvIGRpIHVuIGVsZW5jbyB2dW90byBwZXJjaFx1MDBFOVxuICogc2VtYnJhIHVuIHJpc3VsdGF0by5cbiAqLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gYXVkaXRTb3VyY2VzKGNvbnRleHQsIGNoYXB0ZXIsIGNsYWltcykge1xuICAgIGlmIChjaGFwdGVyLmxpbmtzLmxlbmd0aCA9PT0gMCAmJiBjbGFpbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjaXRhdGlvbnM6IFtdLFxuICAgICAgICAgICAgc3VnZ2VzdGlvbnM6IFtdLFxuICAgICAgICAgICAgdW5tYXRjaGVkQ2xhaW1zOiAwLFxuICAgICAgICAgICAgaXNzdWVzOiBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBraW5kOiAnc291cmNlJyxcbiAgICAgICAgICAgICAgICAgICAgc2V2ZXJpdHk6ICdsb3cnLFxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0NhcGl0b2xvIHNlbnphIGNvbnRlbnV0byB2ZXJpZmljYWJpbGUnLFxuICAgICAgICAgICAgICAgICAgICBkZXRhaWw6ICdJbCBjYXBpdG9sbyBub24gY29udGllbmUgY29sbGVnYW1lbnRpIG5cdTAwRTkgYWZmZXJtYXppb25pIHRlY25pY2hlIGRhIHNvc3RlbmVyZSBjb24gdW5hICcgKyAnZm9udGUuIExhIHZlcmlmaWNhIGRlaSByaWZlcmltZW50aSBub24gXHUwMEU4IHN0YXRhIGVzZWd1aXRhOiBub24gY1x1MjAxOVx1MDBFOCBudWxsYSBkYSB2ZXJpZmljYXJlLCAnICsgJ2UgbnVsbGEgXHUwMEU4IHN0YXRvIGRlZG90dG8gZGFsIHRpdG9sby4nLFxuICAgICAgICAgICAgICAgICAgICBzdWdnZXN0aW9uOiAnU2NyaXZlcmUgaWwgY2FwaXRvbG8sIHBvaSByaXBldGVyZSBsXHUyMDE5YXVkaXQuJyxcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmU6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkaW5nOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhjZXJwdDogbnVsbFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBldmlkZW5jZTogW11cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgLy8gTCdlc2l0byBub24gXHUwMEU4IGluY2VydG86IGwnYXNzZW56YSBcdTAwRTggdW4gZmF0dG8gY29uc3RhdGF0bywgbm9uIHVuYSBzdGltYS5cbiAgICAgICAgICAgIGNvbmZpZGVuY2U6IDEsXG4gICAgICAgICAgICBzdW1tYXJ5OiAnTmVzc3VuIGNvbGxlZ2FtZW50byBlIG5lc3N1bmEgYWZmZXJtYXppb25lIGRhIHZlcmlmaWNhcmU6IGF1ZGl0IGRlbGxlIGZvbnRpIG5vbiBlc2VndWl0by4nXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJ1bkFnZW50KHNvdXJjZUF1ZGl0b3JBZ2VudCwge1xuICAgICAgICAuLi5jaGFwdGVyLFxuICAgICAgICBjbGFpbXNcbiAgICB9LCB7XG4gICAgICAgIGRiOiBjcmVhdGVBZG1pbkNsaWVudCgpLFxuICAgICAgICBvcmdhbml6YXRpb25JZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgcHJvamVjdElkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgY2hhcHRlcklkOiBjb250ZXh0LmNoYXB0ZXJJZCxcbiAgICAgICAgd29ya2Zsb3dSdW5JZDogY29udGV4dC53b3JrZmxvd1J1bklkLFxuICAgICAgICBzdGVwTmFtZTogJ3ZlcmlmaWNhLWZvbnRpJ1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQub3V0cHV0O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAzLWJpcyBcdTAwQjcgQmlibGlvdGVjYSBkZWwgcHJvZ2V0dG9cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBBZ2dpdW5nZSBhbGxlIHByb3Bvc3RlIGxlIGZvbnRpIGNoZSBsJ2F1dG9yZSBoYSBjYXJpY2F0bzogbGluayBlIFBERi5cbiAqXG4gKiBcdTAwQzggdW4gcGFzc2FnZ2lvIGEgc1x1MDBFOSBwZXJjaFx1MDBFOSBsJ2FnZW50ZSByZXN0YSBwdXJvIFx1MjAxNCBpbnRlcnJvZ2EgbGEgc29sYVxuICogZG9jdW1lbnRhemlvbmUgdWZmaWNpYWxlIGUgbm9uIHRvY2NhIGlsIGRhdGFiYXNlIFx1MjAxNCBtZW50cmUgbGEgYmlibGlvdGVjYSB2aXZlXG4gKiBuZWxsZSB0YWJlbGxlIGRlbCBwcm9nZXR0by4gTGUgZHVlIHJpY2VyY2hlIHVzYW5vIGxvIHN0ZXNzbyBpbmRpY2UgY29zdHJ1aXRvXG4gKiBpbnNpZW1lLCBxdWluZGkgaSBwdW50ZWdnaSByZXN0YW5vIGNvbmZyb250YWJpbGkgZSBsJ29yZGluZSBkZWkgY2FuZGlkYXRpXG4gKiBzaWduaWZpY2EgcXVhbGNvc2EuXG4gKi8gZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucmljaFdpdGhMaWJyYXJ5KGNvbnRleHQsIGNsYWltcywgc3VnZ2VzdGlvbnMpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgeyBpbmRleCwgbGlicmFyeUVudHJpZXMgfSA9IGF3YWl0IGJ1aWxkUHJvamVjdEluZGV4KGRiLCBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLCBjb250ZXh0LnByb2plY3RJZCk7XG4gICAgLy8gTmVzc3VuYSBmb250ZSBjYXJpY2F0YTogbm9uIGMnXHUwMEU4IG51bGxhIGRhIGFnZ2l1bmdlcmUsIGUgcmljYWxjb2xhcmVcbiAgICAvLyBzdWxsJ2luZGljZSB1ZmZpY2lhbGUgZGFyZWJiZSBlc2F0dGFtZW50ZSBjaVx1MDBGMiBjaGUgc2kgaGEgZ2lcdTAwRTAuXG4gICAgaWYgKGxpYnJhcnlFbnRyaWVzID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWdnZXN0aW9ucyxcbiAgICAgICAgICAgIHVubWF0Y2hlZDogMCxcbiAgICAgICAgICAgIGxpYnJhcnlFbnRyaWVzOiAwXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHJlc2VhcmNoID0gcmVzZWFyY2hDbGFpbXMoY2xhaW1zLCBpbmRleCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3VnZ2VzdGlvbnM6IG1lcmdlU3VnZ2VzdGlvbnMoc3VnZ2VzdGlvbnMsIHJlc2VhcmNoLnN1Z2dlc3Rpb25zKSxcbiAgICAgICAgdW5tYXRjaGVkOiByZXNlYXJjaC51bm1hdGNoZWQsXG4gICAgICAgIGxpYnJhcnlFbnRyaWVzXG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMy10ZXIgXHUwMEI3IFZlcmlmaWNhIGRlaSBjb2xsZWdhbWVudGkgY2l0YXRpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQXByZSBpIGNvbGxlZ2FtZW50aSBkZWwgY2FwaXRvbG8gZSByaWZlcmlzY2UgY2hlIGNvc2EgaGEgdHJvdmF0by5cbiAqXG4gKiBTZW56YSBxdWVzdG8gcGFzc2FnZ2lvIGwnYXVkaXQgcHVcdTAwRjIgc29sbyBkaXJlIFx1MDBBQnF1ZXN0YSBwYWdpbmEgbm9uIFx1MDBFOCBuZWwgbWlvXG4gKiBpbmRpY2VcdTAwQkIsIGNoZSBcdTAwRTggdW4nYWZmZXJtYXppb25lIHN1IGRpIHNcdTAwRTksIG5vbiBzdWwgbW9uZG86IHVuYSBwYWdpbmEgcHVcdTAwRjJcbiAqIGVzaXN0ZXJlIGJlbmlzc2ltbyBzZW56YSBlc3NlcmUgY2Vuc2l0YS4gVW4gc29zcGV0dG8gZGVsIGdlbmVyZSwgcHJlc2VudGF0b1xuICogY29tZSByaWxpZXZvLCBmYSBwZXJkZXJlIHRlbXBvIGFsIHJldmlzb3JlIGUgXHUyMDE0IHBlZ2dpbyBcdTIwMTQgaW5zZWduYSBhIG5vbiBmaWRhcnNpXG4gKiBkZWkgcmlsaWV2aS5cbiAqXG4gKiBBcHJlbmRvIGwnaW5kaXJpenpvIGxhIGRvbWFuZGEgY2FtYmlhOiBub24gXHUwMEFCbG8gY29ub3Njbz9cdTAwQkIgbWEgXHUwMEFCcmlzcG9uZGU/XHUwMEJCLlxuICogQWxsYSBwcmltYSBuZXNzdW5vIFx1MDBFOCB0ZW51dG8gYSByaXNwb25kZXJlOyBhbGxhIHNlY29uZGEgcmlzcG9uZGUgaWwgd2ViLlxuICovIGV4cG9ydCBhc3luYyBmdW5jdGlvbiB2ZXJpZnlDaXRhdGlvbnMoX2NvbnRleHQsIGNpdGF0aW9ucykge1xuICAgIGNvbnN0IGRhQ29udHJvbGxhcmUgPSBjaXRhdGlvbnMuZmlsdGVyKChjaXRhdGlvbik9PmNpdGF0aW9uLnZlcmlmaWNhdGlvbiAhPT0gJ25vbl92YWxpZGEnKTtcbiAgICBpZiAoZGFDb250cm9sbGFyZS5sZW5ndGggPT09IDApIHJldHVybiB7XG4gICAgICAgIGlzc3VlczogW10sXG4gICAgICAgIHZlcmlmaWVkOiBbXSxcbiAgICAgICAgYnJva2VuOiAwXG4gICAgfTtcbiAgICBjb25zdCBlc2l0aSA9IGF3YWl0IHZlcmlmeVVybHMoZGFDb250cm9sbGFyZS5tYXAoKGNpdGF0aW9uKT0+Y2l0YXRpb24udXJsKSk7XG4gICAgY29uc3QgaXNzdWVzID0gW107XG4gICAgY29uc3QgdmVyaWZpZWQgPSBbXTtcbiAgICBmb3IobGV0IGkgPSAwOyBpIDwgZXNpdGkubGVuZ3RoOyBpICs9IDEpe1xuICAgICAgICBjb25zdCBlc2l0byA9IGVzaXRpW2ldO1xuICAgICAgICBjb25zdCBjaXRhdGlvbiA9IGRhQ29udHJvbGxhcmVbaV07XG4gICAgICAgIHZlcmlmaWVkLnB1c2goe1xuICAgICAgICAgICAgdXJsOiBjaXRhdGlvbi51cmwsXG4gICAgICAgICAgICBzdGF0dXM6IGVzaXRvLnN0YXR1cyxcbiAgICAgICAgICAgIG9rOiBlc2l0by5vayxcbiAgICAgICAgICAgIHRpdGxlOiBlc2l0by50aXRsZVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGVzaXRvLm9rKSB7XG4gICAgICAgICAgICAvLyBQYWdpbmEgdWZmaWNpYWxlIGNoZSByaXNwb25kZSBtYSBub24gXHUwMEU4IGNlbnNpdGE6IG5vbiBcdTAwRTggdW4gcHJvYmxlbWEgZGVsXG4gICAgICAgICAgICAvLyBjYXBpdG9sbywgXHUwMEU4IHVuYSBsYWN1bmEgZGVsIG5vc3RybyBpbmRpY2UuIFZhIGRldHRvIGNvbWUgdGFsZS5cbiAgICAgICAgICAgIGlmIChjaXRhdGlvbi5pc09mZmljaWFsICYmICFjaXRhdGlvbi5pbkluZGV4KSB7XG4gICAgICAgICAgICAgICAgaXNzdWVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICBraW5kOiAnc291cmNlJyxcbiAgICAgICAgICAgICAgICAgICAgc2V2ZXJpdHk6ICdpbmZvJyxcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdQYWdpbmEgdWZmaWNpYWxlIG5vbiBhbmNvcmEgY2Vuc2l0YScsXG4gICAgICAgICAgICAgICAgICAgIGRldGFpbDogYCR7Y2l0YXRpb24udXJsfSByaXNwb25kZSAke2VzaXRvLnN0YXR1c30gZSBpbCB0aXRvbG8gXHUwMEU4IFx1MDBBQiR7ZXNpdG8udGl0bGUgPz8gJ1x1MjAxNCd9XHUwMEJCLiBgICsgJ0lsIHJpZmVyaW1lbnRvIFx1MDBFOCB2YWxpZG86IG1hbmNhIHNvbHRhbnRvIGRhbGxcdTIwMTlpbmRpY2UgY3VyYXRvLicsXG4gICAgICAgICAgICAgICAgICAgIHN1Z2dlc3Rpb246ICdWYWx1dGFyZSBsXHUyMDE5YWdnaXVudGEgYSBjYXRhbG9nLmRhdGEudHMgY29uIG5wbSBydW4gc291cmNlczpyZWZyZXNoLicsXG4gICAgICAgICAgICAgICAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5lOiBjaXRhdGlvbi5saW5lIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkaW5nOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhjZXJwdDogY2l0YXRpb24udXJsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICBjaXRhdGlvbi51cmxcbiAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaXNzdWVzLnB1c2goe1xuICAgICAgICAgICAga2luZDogJ3NvdXJjZScsXG4gICAgICAgICAgICBzZXZlcml0eTogJ2hpZ2gnLFxuICAgICAgICAgICAgdGl0bGU6ICdDb2xsZWdhbWVudG8gbm9uIHJhZ2dpdW5naWJpbGUnLFxuICAgICAgICAgICAgZGV0YWlsOiBgJHtjaXRhdGlvbi51cmx9IG5vbiByaXNwb25kZWAgKyAoZXNpdG8uc3RhdHVzICE9PSBudWxsID8gYCAoc3RhdG8gJHtlc2l0by5zdGF0dXN9KS5gIDogJy4nKSArICcgVW4gY29sbGVnYW1lbnRvIG1vcnRvIGluIHVuIG1hbnVhbGUgc3RhbXBhdG8gbm9uIFx1MDBFOCBjb3JyZWdnaWJpbGUuJyxcbiAgICAgICAgICAgIHN1Z2dlc3Rpb246IGVzaXRvLm5vdGUgPz8gJ0FwcmlyZSBpbCBjb2xsZWdhbWVudG8gZSBzb3N0aXR1aXJsby4nLFxuICAgICAgICAgICAgbG9jYXRpb246IHtcbiAgICAgICAgICAgICAgICBsaW5lOiBjaXRhdGlvbi5saW5lIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgaGVhZGluZzogbnVsbCxcbiAgICAgICAgICAgICAgICBleGNlcnB0OiBjaXRhdGlvbi51cmxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBldmlkZW5jZTogW1xuICAgICAgICAgICAgICAgIGNpdGF0aW9uLnVybFxuICAgICAgICAgICAgXVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaXNzdWVzLFxuICAgICAgICB2ZXJpZmllZCxcbiAgICAgICAgYnJva2VuOiBpc3N1ZXMuZmlsdGVyKChpKT0+aS5zZXZlcml0eSA9PT0gJ2hpZ2gnKS5sZW5ndGhcbiAgICB9O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyA0IFx1MDBCNyBQZXJzaXN0ZW56YSBkZWxsJ2F1ZGl0XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwZXJzaXN0QXVkaXQoY29udGV4dCwgdGVjaG5pY2FsLCBzb3VyY2VzLCBzdWdnZXN0aW9ucywgbGlua0lzc3VlcywgbGlua0NoZWNrcykge1xuICAgIGNvbnN0IGRiID0gY3JlYXRlQWRtaW5DbGllbnQoKTtcbiAgICAvLyBJbCBzb3NwZXR0byBcdTAwQUJwYWdpbmEgbm9uIGNlbnNpdGFcdTAwQkIgdmllbmUgcmltb3NzbzogYWwgc3VvIHBvc3RvIGFycml2YSBsJ2VzaXRvXG4gICAgLy8gZGkgY2hpIGwnaGEgYXBlcnRhIGRhdnZlcm8uIFRlbmVyZSBlbnRyYW1iaSBzaWduaWZpY2hlcmViYmUgZmFyIGxlZ2dlcmUgYWxcbiAgICAvLyByZXZpc29yZSB1biBkdWJiaW8gZSBsYSBzdWEgcmlzcG9zdGEsIG5lbGwnb3JkaW5lIHNiYWdsaWF0by5cbiAgICBjb25zdCBzZW56YVNvc3BldHRpID0gc291cmNlcy5pc3N1ZXMuZmlsdGVyKChpc3N1ZSk9Pmlzc3VlLnRpdGxlICE9PSAnUmlmZXJpbWVudG8gdWZmaWNpYWxlIGRhIHZlcmlmaWNhcmUnKTtcbiAgICBjb25zdCBpc3N1ZXMgPSBbXG4gICAgICAgIC4uLnRlY2huaWNhbC5pc3N1ZXMsXG4gICAgICAgIC4uLnNlbnphU29zcGV0dGksXG4gICAgICAgIC4uLmxpbmtJc3N1ZXNcbiAgICBdLm1hcCgoaXNzdWUpPT4oe1xuICAgICAgICAgICAgLi4uaXNzdWUsXG4gICAgICAgICAgICAvLyBcdTAwQUJyaWdhIDBcdTAwQkIgbm9uIGVzaXN0ZTogbGUgcmlnaGUgcGFydG9ubyBkYSAxLiBVbm8gemVybyBzaWduaWZpY2EgXHUwMEFCbm9uXG4gICAgICAgICAgICAvLyBkZXRlcm1pbmF0YVx1MDBCQiwgZSBkaXJsbyBjb3NcdTAwRUMgZXZpdGEgZGkgbWFuZGFyZSBpbCByZXZpc29yZSBhIGNlcmNhcmUgaWwgbnVsbGEuXG4gICAgICAgICAgICBsb2NhdGlvbjoge1xuICAgICAgICAgICAgICAgIC4uLmlzc3VlLmxvY2F0aW9uLFxuICAgICAgICAgICAgICAgIGxpbmU6IGlzc3VlLmxvY2F0aW9uLmxpbmUgPT09IDAgPyBudWxsIDogaXNzdWUubG9jYXRpb24ubGluZVxuICAgICAgICAgICAgfVxuICAgICAgICB9KSk7XG4gICAgLy8gVW5hIHJpZXNlY3V6aW9uZSBzb3N0aXR1aXNjZSBpIHJpbGlldmkgZGVsIHdvcmtmbG93IHByZWNlZGVudGUsIG5vbiBxdWVsbGlcbiAgICAvLyBkaSBhbHRyZSBlc2VjdXppb25pOiBpbCBmaWx0cm8gXHUwMEU4IHN1bGwnaWRlbnRpZmljYXRpdm8gZGVsIHJ1bi5cbiAgICBhd2FpdCBkYi5mcm9tKCd2ZXJpZmljYXRpb25faXNzdWVzJykuZGVsZXRlKCkuZXEoJ3dvcmtmbG93X3J1bl9pZCcsIGNvbnRleHQud29ya2Zsb3dSdW5JZCk7XG4gICAgaWYgKGlzc3Vlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IHJvd3MgPSBpc3N1ZXMubWFwKChpc3N1ZSk9Pih7XG4gICAgICAgICAgICAgICAgcHJvamVjdF9pZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uX2lkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICAgICAgICAgIGNoYXB0ZXJfaWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICAgICAgICAgIHdvcmtmbG93X3J1bl9pZDogY29udGV4dC53b3JrZmxvd1J1bklkLFxuICAgICAgICAgICAgICAgIGtpbmQ6IGlzc3VlLmtpbmQsXG4gICAgICAgICAgICAgICAgc2V2ZXJpdHk6IGlzc3VlLnNldmVyaXR5LFxuICAgICAgICAgICAgICAgIHN0YXR1czogJ29wZW4nLFxuICAgICAgICAgICAgICAgIHRpdGxlOiBpc3N1ZS50aXRsZSxcbiAgICAgICAgICAgICAgICBkZXRhaWw6IGlzc3VlLmRldGFpbCxcbiAgICAgICAgICAgICAgICBzdWdnZXN0aW9uOiBpc3N1ZS5zdWdnZXN0aW9uLFxuICAgICAgICAgICAgICAgIGxvY2F0aW9uOiBpc3N1ZS5sb2NhdGlvbixcbiAgICAgICAgICAgICAgICBldmlkZW5jZTogaXNzdWUuZXZpZGVuY2VcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgZm9yKGxldCBpID0gMDsgaSA8IHJvd3MubGVuZ3RoOyBpICs9IDEwMCl7XG4gICAgICAgICAgICBhd2FpdCBkYi5mcm9tKCd2ZXJpZmljYXRpb25faXNzdWVzJykuaW5zZXJ0KHJvd3Muc2xpY2UoaSwgaSArIDEwMCkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIExlIGNpdGF6aW9uaSBkaXZlbnRhbm8gcmlnaGUgY29uc3VsdGFiaWxpIGUgcmljb250cm9sbGFiaWxpIG5lbCB0ZW1wby5cbiAgICBhd2FpdCBkYi5mcm9tKCdjaXRhdGlvbnMnKS5kZWxldGUoKS5lcSgnY2hhcHRlcl9pZCcsIGNvbnRleHQuY2hhcHRlcklkKTtcbiAgICBpZiAoc291cmNlcy5jaXRhdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGF3YWl0IGRiLmZyb20oJ2NpdGF0aW9ucycpLmluc2VydChzb3VyY2VzLmNpdGF0aW9ucy5tYXAoKGNpdGF0aW9uKT0+KHtcbiAgICAgICAgICAgICAgICBwcm9qZWN0X2lkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgICAgICAgICBvcmdhbml6YXRpb25faWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgICAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgICAgICAgICAgdXJsOiBjaXRhdGlvbi51cmwsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGNpdGF0aW9uLmluZGV4ZWRUaXRsZSA/PyBjaXRhdGlvbi50ZXh0ID8/IG51bGwsXG4gICAgICAgICAgICAgICAgcHVibGlzaGVyOiBjaXRhdGlvbi5kb21haW4gfHwgbnVsbCxcbiAgICAgICAgICAgICAgICBpc19vZmZpY2lhbDogY2l0YXRpb24uaXNPZmZpY2lhbCxcbiAgICAgICAgICAgICAgICBub3RlOiBjaXRhdGlvbi5ub3RlLFxuICAgICAgICAgICAgICAgIC8vIE9yYSBgaXNfcmVhY2hhYmxlYCBkaWNlIGNpXHUwMEYyIGNoZSBkb3ZyZWJiZSBkaXJlOiBzZSBsYSBwYWdpbmEgaGFcbiAgICAgICAgICAgICAgICAvLyByaXNwb3N0byBxdWFuZG8gXHUwMEU4IHN0YXRhIGFwZXJ0YS4gTnVsbG8gc29sbyBwZXIgY2lcdTAwRjIgY2hlIG5vbiBcdTAwRTggc3RhdG9cbiAgICAgICAgICAgICAgICAvLyBpbnRlcnJvZ2F0by5cbiAgICAgICAgICAgICAgICBodHRwX3N0YXR1czogbGlua0NoZWNrcy5maW5kKChjKT0+Yy51cmwgPT09IGNpdGF0aW9uLnVybCk/LnN0YXR1cyA/PyBudWxsLFxuICAgICAgICAgICAgICAgIGlzX3JlYWNoYWJsZTogbGlua0NoZWNrcy5maW5kKChjKT0+Yy51cmwgPT09IGNpdGF0aW9uLnVybCk/Lm9rID8/IG51bGwsXG4gICAgICAgICAgICAgICAgbGFzdF9jaGVja2VkX2F0OiBub3dcbiAgICAgICAgICAgIH0pKSk7XG4gICAgfVxuICAgIC8vIExlIGZvbnRpIHByb3Bvc3RlIHJlc3Rhbm8gcmlnaGUgZGlzdGludGU6IHVuYSBwcm9wb3N0YSBub24gXHUwMEU4IHVuYSBjaXRhemlvbmVcbiAgICAvLyBmaW5jaFx1MDBFOSBxdWFsY3VubyBub24gbCdhY2NldHRhLlxuICAgIGF3YWl0IGRiLmZyb20oJ3NvdXJjZV9zdWdnZXN0aW9ucycpLmRlbGV0ZSgpLmVxKCd3b3JrZmxvd19ydW5faWQnLCBjb250ZXh0LndvcmtmbG93UnVuSWQpO1xuICAgIGNvbnN0IHN1Z2dlc3Rpb25Sb3dzID0gc3VnZ2VzdGlvbnMuZmxhdE1hcCgoc3VnZ2VzdGlvbik9PnN1Z2dlc3Rpb24uY2FuZGlkYXRlcy5tYXAoKGNhbmRpZGF0ZSwgaW5kZXgpPT4oe1xuICAgICAgICAgICAgICAgIHByb2plY3RfaWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbl9pZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgICAgICAgICBjaGFwdGVyX2lkOiBjb250ZXh0LmNoYXB0ZXJJZCxcbiAgICAgICAgICAgICAgICB3b3JrZmxvd19ydW5faWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgICAgICAgICBjbGFpbV9saW5lOiBzdWdnZXN0aW9uLmxpbmUsXG4gICAgICAgICAgICAgICAgY2xhaW1fZXhjZXJwdDogc3VnZ2VzdGlvbi5zdGF0ZW1lbnQsXG4gICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHN1Z2dlc3Rpb24uY2F0ZWdvcnksXG4gICAgICAgICAgICAgICAgdXJsOiBjYW5kaWRhdGUudXJsLFxuICAgICAgICAgICAgICAgIHRpdGxlOiBjYW5kaWRhdGUudGl0bGUsXG4gICAgICAgICAgICAgICAgc2VjdGlvbjogY2FuZGlkYXRlLnNlY3Rpb24sXG4gICAgICAgICAgICAgICAgc2NvcmU6IGNhbmRpZGF0ZS5zY29yZSxcbiAgICAgICAgICAgICAgICByYW5rOiBpbmRleCArIDEsXG4gICAgICAgICAgICAgICAgbWF0Y2hlZF90ZXJtczogY2FuZGlkYXRlLm1hdGNoZWRUZXJtcyxcbiAgICAgICAgICAgICAgICBvcmlnaW46IGNhbmRpZGF0ZS5vcmlnaW4sXG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlX2lkOiBjYW5kaWRhdGUucmVmZXJlbmNlSWQsXG4gICAgICAgICAgICAgICAgcGFnZTogY2FuZGlkYXRlLnBhZ2UsXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAncHJvcG9zZWQnXG4gICAgICAgICAgICB9KSkpO1xuICAgIGZvcihsZXQgaSA9IDA7IGkgPCBzdWdnZXN0aW9uUm93cy5sZW5ndGg7IGkgKz0gMTAwKXtcbiAgICAgICAgYXdhaXQgZGIuZnJvbSgnc291cmNlX3N1Z2dlc3Rpb25zJykuaW5zZXJ0KHN1Z2dlc3Rpb25Sb3dzLnNsaWNlKGksIGkgKyAxMDApKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaXNzdWVDb3VudDogaXNzdWVzLmxlbmd0aCxcbiAgICAgICAgY3JpdGljYWw6IGlzc3Vlcy5maWx0ZXIoKGkpPT5pLnNldmVyaXR5ID09PSAnY3JpdGljYWwnKS5sZW5ndGgsXG4gICAgICAgIGhpZ2g6IGlzc3Vlcy5maWx0ZXIoKGkpPT5pLnNldmVyaXR5ID09PSAnaGlnaCcpLmxlbmd0aCxcbiAgICAgICAgc3VnZ2VzdGlvbnM6IHN1Z2dlc3Rpb25zLmxlbmd0aFxuICAgIH07XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDUgXHUwMEI3IFByb3Bvc3RhIGRpIHJldmlzaW9uZSBcdTIwMTQgbWFpIHVuYSBzb3ZyYXNjcml0dHVyYVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvcG9zZVJldmlzaW9uKGNvbnRleHQsIGNoYXB0ZXIsIGlzc3Vlcywgc3VnZ2VzdGlvbnMsIGJhc2VWZXJzaW9uSWQpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcnVuQWdlbnQodGVjaG5pY2FsV3JpdGVyQWdlbnQsIHtcbiAgICAgICAgLi4uY2hhcHRlcixcbiAgICAgICAgaXNzdWVzLFxuICAgICAgICBzdWdnZXN0aW9uc1xuICAgIH0sIHtcbiAgICAgICAgZGIsXG4gICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBjaGFwdGVySWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICB3b3JrZmxvd1J1bklkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIHN0ZXBOYW1lOiAncHJvcG9zdGEtcmV2aXNpb25lJ1xuICAgIH0pO1xuICAgIGNvbnN0IHJldmlzaW9uID0gcmVzdWx0Lm91dHB1dDtcbiAgICAvLyBOZXNzdW4gaW50ZXJ2ZW50bzogbm9uIHNpIGNyZWEgdW5hIHZlcnNpb25lIGlkZW50aWNhIGFsbCdvcmlnaW5hbGUuXG4gICAgaWYgKHJldmlzaW9uLmNoYW5nZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB2ZXJzaW9uSWQ6IG51bGwsXG4gICAgICAgICAgICBjaGFuZ2VDb3VudDogMCxcbiAgICAgICAgICAgIHN1bW1hcnk6IHJldmlzaW9uLnN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgeyBkYXRhOiBsYXN0IH0gPSBhd2FpdCBkYi5mcm9tKCdjaGFwdGVyX3ZlcnNpb25zJykuc2VsZWN0KCd2ZXJzaW9uX25vJykuZXEoJ2NoYXB0ZXJfaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCkub3JkZXIoJ3ZlcnNpb25fbm8nLCB7XG4gICAgICAgIGFzY2VuZGluZzogZmFsc2VcbiAgICB9KS5saW1pdCgxKS5tYXliZVNpbmdsZSgpO1xuICAgIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHJldmlzaW9uLmNvbnRlbnRNZCkpO1xuICAgIGNvbnN0IGNvbnRlbnRIYXNoID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKS5tYXAoKGIpPT5iLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKS5qb2luKCcnKTtcbiAgICBjb25zdCB7IGRhdGE6IGNyZWF0ZWQsIGVycm9yIH0gPSBhd2FpdCBkYi5mcm9tKCdjaGFwdGVyX3ZlcnNpb25zJykuaW5zZXJ0KHtcbiAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHByb2plY3RfaWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBvcmdhbml6YXRpb25faWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIHZlcnNpb25fbm86IChsYXN0Py52ZXJzaW9uX25vID8/IDApICsgMSxcbiAgICAgICAgb3JpZ2luOiAnYWlfcHJvcG9zYWwnLFxuICAgICAgICBjb250ZW50X21kOiByZXZpc2lvbi5jb250ZW50TWQsXG4gICAgICAgIGNvbnRlbnRfaGFzaDogY29udGVudEhhc2gsXG4gICAgICAgIHN1bW1hcnk6IHJldmlzaW9uLnN1bW1hcnksXG4gICAgICAgIHdvcmRfY291bnQ6IHJldmlzaW9uLmNvbnRlbnRNZC5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKS5sZW5ndGgsXG4gICAgICAgIHBhcmVudF92ZXJzaW9uX2lkOiBiYXNlVmVyc2lvbklkLFxuICAgICAgICB3b3JrZmxvd19ydW5faWQ6IGNvbnRleHQud29ya2Zsb3dSdW5JZCxcbiAgICAgICAgYWdlbnRfcnVuX2lkOiByZXN1bHQuYWdlbnRSdW5JZCxcbiAgICAgICAgY3JlYXRlZF9ieTogY29udGV4dC5hY3RvcklkXG4gICAgfSkuc2VsZWN0KCdpZCcpLnNpbmdsZSgpO1xuICAgIGlmIChlcnJvciB8fCAhY3JlYXRlZCkgdGhyb3cgbmV3IEVycm9yKGBTYWx2YXRhZ2dpbyBkZWxsYSBwcm9wb3N0YSBmYWxsaXRvOiAke2Vycm9yPy5tZXNzYWdlID8/ICcnfWApO1xuICAgIHJldHVybiB7XG4gICAgICAgIHZlcnNpb25JZDogY3JlYXRlZC5pZCxcbiAgICAgICAgY2hhbmdlQ291bnQ6IHJldmlzaW9uLmNoYW5nZXMubGVuZ3RoLFxuICAgICAgICBzdW1tYXJ5OiByZXZpc2lvbi5zdW1tYXJ5XG4gICAgfTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gNiBcdTAwQjcgUGlhbm8gdmlzdWFsZVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGxhblZpc3VhbHMoY29udGV4dCwgY2hhcHRlciwgZGF0YWZvcm1SZWZzKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcnVuQWdlbnQodmlzdWFsUGxhbkFnZW50LCB7XG4gICAgICAgIC4uLmNoYXB0ZXIsXG4gICAgICAgIGRhdGFmb3JtUmVmc1xuICAgIH0sIHtcbiAgICAgICAgZGI6IGNyZWF0ZUFkbWluQ2xpZW50KCksXG4gICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICBwcm9qZWN0SWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBjaGFwdGVySWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICB3b3JrZmxvd1J1bklkOiBjb250ZXh0LndvcmtmbG93UnVuSWQsXG4gICAgICAgIHN0ZXBOYW1lOiAncGlhbm8tdmlzdWFsZSdcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0Lm91dHB1dDtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gNyBcdTAwQjcgRGlhZ3JhbW1pIGRldGVybWluaXN0aWNpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZW5lcmF0ZURpYWdyYW1zKGNvbnRleHQsIGNoYXB0ZXJUaXRsZSwgZGF0YWZvcm1SZWZzLCBpc0luY3JlbWVudGFsKSB7XG4gICAgY29uc3QgZGIgPSBjcmVhdGVBZG1pbkNsaWVudCgpO1xuICAgIGNvbnN0IGRpYWdyYW0gPSBidWlsZERlcGVuZGVuY3lEYWcoe1xuICAgICAgICB0YXJnZXQ6IGNoYXB0ZXJUaXRsZSxcbiAgICAgICAgZGVwZW5kZW5jaWVzOiBkYXRhZm9ybVJlZnMsXG4gICAgICAgIGlzSW5jcmVtZW50YWxcbiAgICB9KTtcbiAgICBjb25zdCB7IGRhdGE6IGV4aXN0aW5nIH0gPSBhd2FpdCBkYi5mcm9tKCd2aXN1YWxfYXNzZXRzJykuc2VsZWN0KCd2ZXJzaW9uJykuZXEoJ2NoYXB0ZXJfaWQnLCBjb250ZXh0LmNoYXB0ZXJJZCkuZXEoJ2tpbmQnLCAnZGlhZ3JhbScpLm9yZGVyKCd2ZXJzaW9uJywge1xuICAgICAgICBhc2NlbmRpbmc6IGZhbHNlXG4gICAgfSkubGltaXQoMSkubWF5YmVTaW5nbGUoKTtcbiAgICBjb25zdCB7IGRhdGE6IGFzc2V0LCBlcnJvciB9ID0gYXdhaXQgZGIuZnJvbSgndmlzdWFsX2Fzc2V0cycpLmluc2VydCh7XG4gICAgICAgIHByb2plY3RfaWQ6IGNvbnRleHQucHJvamVjdElkLFxuICAgICAgICBvcmdhbml6YXRpb25faWQ6IGNvbnRleHQub3JnYW5pemF0aW9uSWQsXG4gICAgICAgIGNoYXB0ZXJfaWQ6IGNvbnRleHQuY2hhcHRlcklkLFxuICAgICAgICBraW5kOiAnZGlhZ3JhbScsXG4gICAgICAgIGdlbmVyYXRvcjogJ21lcm1haWQnLFxuICAgICAgICAvLyBBbmNoZSB1biBkaWFncmFtbWEgZXNhdHRvIHJpY2hpZWRlIGwnb2NjaGlvIHVtYW5vIHByaW1hIGRpIGZpbmlyZSBuZWwgbGlicm8uXG4gICAgICAgIHN0YXR1czogJ3BlbmRpbmdfYXBwcm92YWwnLFxuICAgICAgICB2ZXJzaW9uOiAoZXhpc3Rpbmc/LnZlcnNpb24gPz8gMCkgKyAxLFxuICAgICAgICB0aXRsZTogZGlhZ3JhbS50aXRsZSxcbiAgICAgICAgY2FwdGlvbjogZGlhZ3JhbS5jYXB0aW9uLFxuICAgICAgICBhbHRfdGV4dDogZGlhZ3JhbS5hbHRUZXh0LFxuICAgICAgICBtZXJtYWlkX3NvdXJjZTogZGlhZ3JhbS5tZXJtYWlkLFxuICAgICAgICBjcmVhdGVkX2J5OiBjb250ZXh0LmFjdG9ySWRcbiAgICB9KS5zZWxlY3QoJ2lkJykuc2luZ2xlKCk7XG4gICAgaWYgKGVycm9yIHx8ICFhc3NldCkgdGhyb3cgbmV3IEVycm9yKGBTYWx2YXRhZ2dpbyBkZWwgZGlhZ3JhbW1hIGZhbGxpdG86ICR7ZXJyb3I/Lm1lc3NhZ2UgPz8gJyd9YCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYXNzZXRJZHM6IFtcbiAgICAgICAgICAgIGFzc2V0LmlkXG4gICAgICAgIF0sXG4gICAgICAgIG1lcm1haWQ6IGRpYWdyYW0ubWVybWFpZFxuICAgIH07XG59XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDggXHUwMEI3IFJpY2hpZXN0YSBkaSBhcHByb3ZhemlvbmVcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlcXVlc3RBcHByb3ZhbChjb250ZXh0LCBiYXNlVmVyc2lvbklkLCBwcm9wb3NlZFZlcnNpb25JZCwgcmVzdW1lVG9rZW4sIHN1bW1hcnkpIHtcbiAgICBjb25zdCBkYiA9IGNyZWF0ZUFkbWluQ2xpZW50KCk7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgZGIuZnJvbSgncmV2aWV3X3JlcXVlc3RzJykuaW5zZXJ0KHtcbiAgICAgICAgcHJvamVjdF9pZDogY29udGV4dC5wcm9qZWN0SWQsXG4gICAgICAgIG9yZ2FuaXphdGlvbl9pZDogY29udGV4dC5vcmdhbml6YXRpb25JZCxcbiAgICAgICAgY2hhcHRlcl9pZDogY29udGV4dC5jaGFwdGVySWQsXG4gICAgICAgIHdvcmtmbG93X3J1bl9pZDogY29udGV4dC53b3JrZmxvd1J1bklkLFxuICAgICAgICBiYXNlX3ZlcnNpb25faWQ6IGJhc2VWZXJzaW9uSWQsXG4gICAgICAgIHByb3Bvc2VkX3ZlcnNpb25faWQ6IHByb3Bvc2VkVmVyc2lvbklkLFxuICAgICAgICBzdGF0dXM6ICdwZW5kaW5nJyxcbiAgICAgICAgdGl0bGU6ICdSZXZpc2lvbmUgcHJvcG9zdGEgZGFsbFx1MjAxOWF1ZGl0IHRlY25pY28nLFxuICAgICAgICBzdW1tYXJ5LFxuICAgICAgICByZXN1bWVfdG9rZW46IHJlc3VtZVRva2VuLFxuICAgICAgICByZXF1ZXN0ZWRfYnk6IGNvbnRleHQuYWN0b3JJZFxuICAgIH0pLnNlbGVjdCgnaWQnKS5zaW5nbGUoKTtcbiAgICBpZiAoZXJyb3IgfHwgIWRhdGEpIHRocm93IG5ldyBFcnJvcihgQ3JlYXppb25lIGRlbGxhIHJpY2hpZXN0YSBkaSByZXZpc2lvbmUgZmFsbGl0YTogJHtlcnJvcj8ubWVzc2FnZSA/PyAnJ31gKTtcbiAgICBhd2FpdCBkYi5mcm9tKCd3b3JrZmxvd19ydW5zJykudXBkYXRlKHtcbiAgICAgICAgc3RhdHVzOiAnYXdhaXRpbmdfYXBwcm92YWwnLFxuICAgICAgICBjdXJyZW50X3N0ZXA6ICdhdHRlc2EtYXBwcm92YXppb25lJ1xuICAgIH0pLmVxKCdpZCcsIGNvbnRleHQud29ya2Zsb3dSdW5JZCk7XG4gICAgYXdhaXQgZGIuZnJvbSgnY2hhcHRlcnMnKS51cGRhdGUoe1xuICAgICAgICBzdGF0dXM6ICdpbl9yZXZpZXcnXG4gICAgfSkuZXEoJ2lkJywgY29udGV4dC5jaGFwdGVySWQpO1xuICAgIHJldHVybiBkYXRhLmlkO1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyA5IFx1MDBCNyBFc2l0byBkZWxsYSBkZWNpc2lvbmUgdW1hbmFcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGx5RGVjaXNpb24oY29udGV4dCwgcmV2aWV3UmVxdWVzdElkLCBfcHJvcG9zZWRWZXJzaW9uSWRBdENyZWF0aW9uLCBkZWNpc2lvbiwgbm90ZSwgZGVjaWRlZEJ5KSB7XG4gICAgY29uc3QgZGIgPSBjcmVhdGVBZG1pbkNsaWVudCgpO1xuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAvLyBMYSBwcm9wb3N0YSB2aWVuZSByaWxldHRhIGFkZXNzbywgbm9uIHVzYXRhIGNvbWUgZXJhIGFsIG1vbWVudG8gZGVsbGFcbiAgICAvLyByaWNoaWVzdGE6IGZyYSBpIGR1ZSBpc3RhbnRpIGlsIHJldmlzb3JlIHB1XHUwMEYyIGF2ZXIgYWNjZXR0YXRvIHNvbG8gYWxjdW5lXG4gICAgLy8gbW9kaWZpY2hlIG8gaW50ZXJ2ZW51dG8gYSBtYW5vLCBnZW5lcmFuZG8gdW5hIHZlcnNpb25lIGRpdmVyc2EuXG4gICAgY29uc3QgeyBkYXRhOiBjdXJyZW50IH0gPSBhd2FpdCBkYi5mcm9tKCdyZXZpZXdfcmVxdWVzdHMnKS5zZWxlY3QoJ3Byb3Bvc2VkX3ZlcnNpb25faWQnKS5lcSgnaWQnLCByZXZpZXdSZXF1ZXN0SWQpLm1heWJlU2luZ2xlKCk7XG4gICAgY29uc3QgcHJvcG9zZWRWZXJzaW9uSWQgPSBjdXJyZW50Py5wcm9wb3NlZF92ZXJzaW9uX2lkID8/IF9wcm9wb3NlZFZlcnNpb25JZEF0Q3JlYXRpb247XG4gICAgYXdhaXQgZGIuZnJvbSgncmV2aWV3X3JlcXVlc3RzJykudXBkYXRlKHtcbiAgICAgICAgc3RhdHVzOiBkZWNpc2lvbixcbiAgICAgICAgZGVjaWRlZF9hdDogbm93LFxuICAgICAgICBkZWNpZGVkX2J5OiBkZWNpZGVkQnksXG4gICAgICAgIGRlY2lzaW9uX25vdGU6IG5vdGVcbiAgICB9KS5lcSgnaWQnLCByZXZpZXdSZXF1ZXN0SWQpO1xuICAgIGlmIChkZWNpc2lvbiAhPT0gJ2FwcHJvdmVkJyB8fCAhcHJvcG9zZWRWZXJzaW9uSWQpIHtcbiAgICAgICAgYXdhaXQgZGIuZnJvbSgnY2hhcHRlcnMnKS51cGRhdGUoe1xuICAgICAgICAgICAgc3RhdHVzOiAnZHJhZnQnXG4gICAgICAgIH0pLmVxKCdpZCcsIGNvbnRleHQuY2hhcHRlcklkKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGFwcHJvdmVkVmVyc2lvbklkOiBudWxsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIExhIHByb3Bvc3RhIGFwcHJvdmF0YSBkaXZlbnRhIGxhIHZlcnNpb25lIGNvcnJlbnRlLiBMJ29yaWdpbmFsZSByZXN0YVxuICAgIC8vIGludGF0dG86IFx1MDBFOCB1bmEgcmlnYSBkaXN0aW50YSwgcHJvdGV0dGEgZGEgdHJpZ2dlci5cbiAgICBhd2FpdCBkYi5mcm9tKCdjaGFwdGVyX3ZlcnNpb25zJykudXBkYXRlKHtcbiAgICAgICAgb3JpZ2luOiAnYXBwcm92ZWQnLFxuICAgICAgICBpc19hcHByb3ZlZDogdHJ1ZSxcbiAgICAgICAgYXBwcm92ZWRfYnk6IGRlY2lkZWRCeSxcbiAgICAgICAgYXBwcm92ZWRfYXQ6IG5vd1xuICAgIH0pLmVxKCdpZCcsIHByb3Bvc2VkVmVyc2lvbklkKTtcbiAgICBhd2FpdCBkYi5mcm9tKCdjaGFwdGVycycpLnVwZGF0ZSh7XG4gICAgICAgIGN1cnJlbnRfdmVyc2lvbl9pZDogcHJvcG9zZWRWZXJzaW9uSWQsXG4gICAgICAgIHN0YXR1czogJ2FwcHJvdmVkJ1xuICAgIH0pLmVxKCdpZCcsIGNvbnRleHQuY2hhcHRlcklkKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBhcHByb3ZlZFZlcnNpb25JZDogcHJvcG9zZWRWZXJzaW9uSWRcbiAgICB9O1xufVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBBZ2dpb3JuYW1lbnRvIGRlbGxvIHN0YXRvIGRpIGF2YW56YW1lbnRvXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrU3RlcCh3b3JrZmxvd1J1bklkLCBzdGVwLCBjb21wbGV0ZWQsIHRvdGFsKSB7XG4gICAgYXdhaXQgY3JlYXRlQWRtaW5DbGllbnQoKS5mcm9tKCd3b3JrZmxvd19ydW5zJykudXBkYXRlKHtcbiAgICAgICAgY3VycmVudF9zdGVwOiBzdGVwLFxuICAgICAgICBjb21wbGV0ZWRfc3RlcHM6IGNvbXBsZXRlZCxcbiAgICAgICAgdG90YWxfc3RlcHM6IHRvdGFsLFxuICAgICAgICBzdGF0dXM6ICdydW5uaW5nJ1xuICAgIH0pLmVxKCdpZCcsIHdvcmtmbG93UnVuSWQpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZpbmlzaFJ1bih3b3JrZmxvd1J1bklkLCBzdGF0dXMsIG91dHB1dCwgZXJyb3IpIHtcbiAgICBhd2FpdCBjcmVhdGVBZG1pbkNsaWVudCgpLmZyb20oJ3dvcmtmbG93X3J1bnMnKS51cGRhdGUoe1xuICAgICAgICBzdGF0dXMsXG4gICAgICAgIG91dHB1dCxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIGZpbmlzaGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICB9KS5lcSgnaWQnLCB3b3JrZmxvd1J1bklkKTtcbn1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gMTEgXHUwMEI3IEFudGVwcmltYSBkZWwgdm9sdW1lXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQWdnaXVuZ2UgaWwgY2FwaXRvbG8gYXBwZW5hIGNvbnZhbGlkYXRvIGFsbCdhbnRlcHJpbWEgZGVsIHZvbHVtZS5cbiAqXG4gKiBcdTAwQzggbCd1bHRpbW8gcGFzc2FnZ2lvLCBlIG5vbiBcdTAwRTggdW4nZXNwb3J0YXppb25lOiBcdTAwRTggaWwgbW9tZW50byBpbiBjdWkgaWwgbGF2b3JvXG4gKiBhcHBlbmEgYXBwcm92YXRvIHNtZXR0ZSBkaSBlc3NlcmUgdW4gY2FwaXRvbG8gYSBzXHUwMEU5IGUgZGl2ZW50YSBwYXJ0ZSBkZWwgbGlicm8uXG4gKiBWZWRlcmUgaWwgdm9sdW1lIGNyZXNjZXJlIGRvcG8gb2duaSBhcHByb3ZhemlvbmUgXHUwMEU4IGNpXHUwMEYyIGNoZSByZW5kZSB2aXNpYmlsZSBpbFxuICogcHJvZ3Jlc3NvIFx1MjAxNCB1biBlbGVuY28gZGkgY2FwaXRvbGkgYXBwcm92YXRpIG5vbiBsbyBtb3N0cmEgYWxsbyBzdGVzc28gbW9kby5cbiAqXG4gKiBJbCBmYWxsaW1lbnRvIHF1aSBub24gYW5udWxsYSBsJ2FwcHJvdmF6aW9uZTogbGEgZGVjaXNpb25lIHVtYW5hIFx1MDBFOCBnaVx1MDBFMCBwcmVzYVxuICogZSByZWdpc3RyYXRhLCBlIHVuIFBERiBjaGUgbm9uIHNpIGNvbXBvbmUgXHUwMEU4IHVuIGluY29udmVuaWVudGUsIG5vbiB1biBtb3Rpdm9cbiAqIHBlciByaW1ldHRlcmUgaW4gZGlzY3Vzc2lvbmUgY2lcdTAwRjIgY2hlIHVuYSBwZXJzb25hIGhhIGRlY2lzby5cbiAqLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlVm9sdW1lUHJldmlldyhjb250ZXh0KSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZXNpdG8gPSBhd2FpdCByZWJ1aWxkVm9sdW1lUHJldmlld1dpdGgoY3JlYXRlQWRtaW5DbGllbnQoKSwge1xuICAgICAgICAgICAgcHJvamVjdElkOiBjb250ZXh0LnByb2plY3RJZCxcbiAgICAgICAgICAgIG9yZ2FuaXphdGlvbklkOiBjb250ZXh0Lm9yZ2FuaXphdGlvbklkLFxuICAgICAgICAgICAgYWN0b3JJZDogY29udGV4dC5hY3RvcklkXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgb2s6IGVzaXRvLm9rLFxuICAgICAgICAgICAgY2hhcHRlcnM6IGVzaXRvLmNoYXB0ZXJzID8/IDAsXG4gICAgICAgICAgICB3b3JkczogZXNpdG8ud29yZHMgPz8gMCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzaXRvLm1lc3NhZ2VcbiAgICAgICAgfTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgICAgY2hhcHRlcnM6IDAsXG4gICAgICAgICAgICB3b3JkczogMCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBBbnRlcHJpbWEgbm9uIGFnZ2lvcm5hdGE6ICR7ZXJyb3IubWVzc2FnZX1gXG4gICAgICAgIH07XG4gICAgfVxufVxucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vbG9hZENoYXB0ZXJcIiwgbG9hZENoYXB0ZXIpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZHJhZnRDaGFwdGVyXCIsIGRyYWZ0Q2hhcHRlcik7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy92ZXJpZnlUZWNobmljYWxcIiwgdmVyaWZ5VGVjaG5pY2FsKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2F1ZGl0U291cmNlc1wiLCBhdWRpdFNvdXJjZXMpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZW5yaWNoV2l0aExpYnJhcnlcIiwgZW5yaWNoV2l0aExpYnJhcnkpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vdmVyaWZ5Q2l0YXRpb25zXCIsIHZlcmlmeUNpdGF0aW9ucyk7XG5yZWdpc3RlclN0ZXBGdW5jdGlvbihcInN0ZXAvLy4vc3JjL3dvcmtmbG93cy9jaGFwdGVyLWF1ZGl0LXN0ZXBzLy9wZXJzaXN0QXVkaXRcIiwgcGVyc2lzdEF1ZGl0KTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3Byb3Bvc2VSZXZpc2lvblwiLCBwcm9wb3NlUmV2aXNpb24pO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vcGxhblZpc3VhbHNcIiwgcGxhblZpc3VhbHMpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vZ2VuZXJhdGVEaWFncmFtc1wiLCBnZW5lcmF0ZURpYWdyYW1zKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL3JlcXVlc3RBcHByb3ZhbFwiLCByZXF1ZXN0QXBwcm92YWwpO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vYXBwbHlEZWNpc2lvblwiLCBhcHBseURlY2lzaW9uKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL21hcmtTdGVwXCIsIG1hcmtTdGVwKTtcbnJlZ2lzdGVyU3RlcEZ1bmN0aW9uKFwic3RlcC8vLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMvL2ZpbmlzaFJ1blwiLCBmaW5pc2hSdW4pO1xucmVnaXN0ZXJTdGVwRnVuY3Rpb24oXCJzdGVwLy8uL3NyYy93b3JrZmxvd3MvY2hhcHRlci1hdWRpdC1zdGVwcy8vdXBkYXRlVm9sdW1lUHJldmlld1wiLCB1cGRhdGVWb2x1bWVQcmV2aWV3KTtcbiIsICJcbiAgICAvLyBCdWlsdCBpbiBzdGVwc1xuICAgIGltcG9ydCAnd29ya2Zsb3cvaW50ZXJuYWwvYnVpbHRpbnMnO1xuICAgIC8vIFVzZXIgc3RlcHNcbiAgICBpbXBvcnQgJy4vbm9kZV9tb2R1bGVzL3dvcmtmbG93L2Rpc3Qvc3RkbGliLmpzJztcbmltcG9ydCAnLi9zcmMvd29ya2Zsb3dzL2NoYXB0ZXItYXVkaXQtc3RlcHMudHMnO1xuICAgIC8vIFNlcmRlIGZpbGVzIGZvciBjcm9zcy1jb250ZXh0IGNsYXNzIHJlZ2lzdHJhdGlvblxuICAgIFxuICAgIC8vIEFQSSBlbnRyeXBvaW50XG4gICAgZXhwb3J0IHsgc3RlcEVudHJ5cG9pbnQgYXMgSEVBRCwgc3RlcEVudHJ5cG9pbnQgYXMgUE9TVCB9IGZyb20gJ3dvcmtmbG93L3J1bnRpbWUnOyJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7QUFBQSxTQUFBLDRCQUFBO0FBU0UsZUFBVyxrQ0FBQTtBQUNYLFNBQU8sS0FBSyxZQUFXO0FBQ3pCO0FBRmE7QUFJYixlQUFzQiwwQkFBdUI7QUFDM0MsU0FBQSxLQUFXLEtBQUE7O0FBRFM7QUFHdEIsZUFBQywwQkFBQTtBQUVELFNBQU8sS0FBSyxLQUFBOztBQUZYO3FCQUlpQixtQ0FBRywrQkFBQTtBQUNyQixxQkFBQywyQkFBQSx1QkFBQTs7OztBQ3JCRCxTQUFBLHdCQUFBQSw2QkFBQTtBQWFBLGVBQXNCLFNBQWtELE1BQUE7QUFDdEUsU0FBQSxXQUFXLE1BQUEsR0FBQSxJQUFBOztBQURTO0FBR3RCQyxzQkFBQywrQkFBQSxLQUFBOzs7QUNoQkQsU0FBUyx3QkFBQUMsNkJBQTRCO0FBRXJDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsdUJBQXVCLGtCQUFrQixxQkFBcUIsb0JBQW9CLHdCQUF3QixzQkFBc0IsdUJBQXVCO0FBQ2hLLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsZ0NBQWdDO0FBQ3pDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsa0JBQWtCLHNCQUFzQjtBQUNqRCxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLDBCQUEwQjtBQUtuQyxlQUFzQixZQUFZLFNBQVM7QUFDdkMsUUFBTSxLQUFLLGtCQUFrQjtBQUM3QixRQUFNLEVBQUUsTUFBTSxTQUFTLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTyxvRUFBb0UsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTLEVBQUUsT0FBTztBQUMzSyxNQUFJLFNBQVMsQ0FBQyxRQUFTLE9BQU0sSUFBSSxNQUFNLHVCQUF1QjtBQUc5RCxNQUFJLFFBQVEsb0JBQW9CLFFBQVEsa0JBQWtCLFFBQVEsZUFBZSxRQUFRLFdBQVc7QUFDaEcsVUFBTSxJQUFJLE1BQU0sa0RBQWtEO0FBQUEsRUFDdEU7QUFDQSxRQUFNLEVBQUUsTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHLEtBQUssa0JBQWtCLEVBQUUsT0FBTyxnQkFBZ0IsRUFBRSxHQUFHLGNBQWMsUUFBUSxTQUFTLEVBQUUsTUFBTSxjQUFjO0FBQUEsSUFDekksV0FBVztBQUFBLEVBQ2YsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLFlBQVk7QUFDeEIsTUFBSSxDQUFDLFFBQVMsT0FBTSxJQUFJLE1BQU0sbURBQW1EO0FBQ2pGLFFBQU0sV0FBVyxnQkFBZ0IsUUFBUSxVQUFVO0FBQ25ELFFBQU0sZ0JBQWdCLFNBQVMsV0FBVyxLQUFLLENBQUMsVUFBUTtBQUNwRCxVQUFNLFNBQVMsbUJBQW1CLE1BQU0sT0FBTztBQUMvQyxXQUFPLFdBQVcsUUFBUSxtQ0FBbUMsS0FBSyxNQUFNO0FBQUEsRUFDNUUsQ0FBQztBQUNELFNBQU87QUFBQSxJQUNILFNBQVM7QUFBQSxNQUNMLFdBQVcsUUFBUTtBQUFBLE1BQ25CLFFBQVEsUUFBUTtBQUFBLE1BQ2hCLE9BQU8sUUFBUTtBQUFBLE1BQ2YsV0FBVyxRQUFRO0FBQUEsTUFDbkIsVUFBVSxTQUFTLFNBQVMsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUM5QixPQUFPLEVBQUU7QUFBQSxRQUNULE1BQU0sRUFBRTtBQUFBLFFBQ1IsTUFBTSxFQUFFO0FBQUEsTUFDWixFQUFFO0FBQUEsTUFDTixZQUFZLFNBQVMsV0FBVyxJQUFJLENBQUMsT0FBSztBQUFBLFFBQ2xDLFVBQVUsRUFBRTtBQUFBLFFBQ1osU0FBUyxFQUFFO0FBQUEsUUFDWCxNQUFNLEVBQUU7QUFBQSxNQUNaLEVBQUU7QUFBQSxNQUNOLE9BQU8sU0FBUztBQUFBLE1BQ2hCLFNBQVMsU0FBUyxRQUFRLElBQUksQ0FBQyxPQUFLO0FBQUEsUUFDNUIsS0FBSyxFQUFFO0FBQUEsUUFDUCxLQUFLLEVBQUU7QUFBQSxRQUNQLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLE1BQ04sY0FBYyxTQUFTLGFBQWEsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUN0QyxhQUFhLEVBQUU7QUFBQSxRQUNmLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLElBQ1Y7QUFBQSxJQUNBLFdBQVcsUUFBUTtBQUFBLElBQ25CO0FBQUEsRUFDSjtBQUNKO0FBaERzQjtBQTJEbEIsU0FBUyxnQkFBZ0IsUUFBUSxRQUFRLFdBQVcsT0FBTyxVQUFVO0FBQ3JFLFFBQU0sUUFBUTtBQUFBLElBQ1YsS0FBSyxXQUFXLE9BQU8sWUFBWSxNQUFNLFFBQVEsRUFBRSxHQUFHLE1BQU07QUFBQSxJQUM1RDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxHQUFHLFVBQVUsSUFBSSxDQUFDLGNBQVksT0FBTyxTQUFTLEVBQUU7QUFBQSxJQUNoRDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDSjtBQUNBLE1BQUksU0FBUyxjQUFjLFNBQVMsR0FBRztBQUNuQyxVQUFNLEtBQUssb0JBQW9CLElBQUksR0FBRyxTQUFTLGNBQWMsSUFBSSxDQUFDLFNBQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFO0FBQUEsRUFDN0Y7QUFDQSxNQUFJLFNBQVMsYUFBYSxTQUFTLEdBQUc7QUFDbEMsVUFBTSxLQUFLLG9CQUFvQixJQUFJLEdBQUcsU0FBUyxhQUFhLElBQUksQ0FBQyxTQUFPLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRTtBQUFBLEVBQzVGO0FBQ0EsUUFBTSxLQUFLLGdCQUFnQixJQUFJLFNBQVMsU0FBUyxFQUFFO0FBQ25ELFFBQU0sS0FBSyxtQkFBbUIsSUFBSSxHQUFHLFNBQVMsVUFBVSxJQUFJLENBQUMsU0FBTyxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUU7QUFDcEYsTUFBSSxTQUFTLEtBQUssU0FBUyxHQUFHO0FBQzFCLFVBQU0sS0FBSyxXQUFXLElBQUkscURBQWtELEVBQUU7QUFDOUUsYUFBUyxLQUFLLFFBQVEsQ0FBQyxTQUFTLFdBQVM7QUFDckMsWUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sUUFBUSxRQUFRLE1BQU0sRUFBRTtBQUN2RCxjQUFRLFFBQVEsUUFBUSxDQUFDLFNBQVMsTUFBSTtBQUNsQyxjQUFNLEtBQUssTUFBTSxPQUFPLGFBQWEsS0FBSyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7QUFBQSxNQUM5RCxDQUFDO0FBQ0QsWUFBTSxLQUFLLEVBQUU7QUFBQSxJQUNqQixDQUFDO0FBR0QsVUFBTSxLQUFLLG9CQUFvQixTQUFTLEtBQUssSUFBSSxDQUFDLFNBQVMsV0FBUyxHQUFHLFNBQVMsQ0FBQyxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsT0FBTyxDQUFDLEVBQUUsRUFBRSxLQUFLLElBQUksR0FBRyxFQUFFO0FBQUEsRUFDcEo7QUFDQSxNQUFJLFNBQVMsSUFBSSxLQUFLLEVBQUcsT0FBTSxLQUFLLGtCQUFrQixJQUFJLFNBQVMsSUFBSSxLQUFLLEdBQUcsRUFBRTtBQUlqRixTQUFPLE1BQU0sS0FBSyxJQUFJO0FBQzFCO0FBckNhO0FBb0RULGVBQXNCLGFBQWEsU0FBUyxTQUFTLGVBQWU7QUFDcEUsUUFBTSxLQUFLLGtCQUFrQjtBQUM3QixRQUFNLENBQUMsRUFBRSxNQUFNLFdBQVcsR0FBRyxFQUFFLE1BQU0sUUFBUSxDQUFDLElBQUksTUFBTSxRQUFRLElBQUk7QUFBQSxJQUNoRSxHQUFHLEtBQUssVUFBVSxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsTUFBTSxRQUFRLFNBQVMsRUFBRSxZQUFZO0FBQUEsSUFDOUUsR0FBRyxLQUFLLFVBQVUsRUFBRSxPQUFPLDhDQUE4QyxFQUFFLEdBQUcsTUFBTSxRQUFRLFNBQVMsRUFBRSxZQUFZO0FBQUEsRUFDdkgsQ0FBQztBQUNELFFBQU0sRUFBRSxNQUFNLEtBQUssSUFBSSxZQUFZLFVBQVUsTUFBTSxHQUFHLEtBQUssbUJBQW1CLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRyxNQUFNLFdBQVcsT0FBTyxFQUFFLFlBQVksSUFBSTtBQUFBLElBQ3pJLE1BQU07QUFBQSxFQUNWO0FBR0EsUUFBTSxDQUFDLEVBQUUsTUFBTSxXQUFXLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixHQUFHLEVBQUUsTUFBTSxhQUFhLENBQUMsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2hHLEdBQUcsS0FBSyxtQkFBbUIsRUFBRSxPQUFPLHVCQUF1QixFQUFFLEdBQUcsaUJBQWlCLFFBQVEsU0FBUyxxQkFBcUIsRUFBRSxJQUFJLFVBQVUsVUFBVSxFQUFFLE1BQU0sRUFBRTtBQUFBLElBQzNKLEdBQUcsS0FBSyxrQkFBa0IsRUFBRSxPQUFPLGtCQUFrQixFQUFFLEdBQUcsaUJBQWlCLFFBQVEsU0FBUyxxQkFBcUIsRUFBRSxNQUFNLGVBQWU7QUFBQSxNQUNwSSxXQUFXO0FBQUEsSUFDZixDQUFDLEVBQUUsTUFBTSxHQUFHO0FBQUEsSUFDWixHQUFHLEtBQUssZUFBZSxFQUFFLE9BQU8sdUJBQXVCLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUyxFQUFFLE1BQU0sZUFBZTtBQUFBLE1BQzlHLFdBQVc7QUFBQSxJQUNmLENBQUMsRUFBRSxNQUFNLEdBQUc7QUFBQSxFQUNoQixDQUFDO0FBQ0QsUUFBTSxXQUFXO0FBQUEsSUFDYixJQUFJLG1CQUFtQixDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVMsR0FBRyxPQUFPLFVBQVUsTUFBTSxPQUFPLE9BQU87QUFBQSxJQUFPLEVBQUUsR0FBRyxPQUFPLE9BQU8sRUFBRTtBQUFBLElBQzdHLElBQUksZ0JBQWdCLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBUyxHQUFHLE9BQU8sY0FBYyxTQUFTLE1BQU0sT0FBTyxhQUFhLEtBQUssS0FBSyxDQUFDO0FBQUEsSUFBTyxFQUFFLEdBQUcsT0FBTyxPQUFPLEVBQUU7QUFBQSxFQUM1SSxFQUFFLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxHQUFNO0FBRTlCLFFBQU0sWUFBWSxRQUFRLFVBQVUsTUFBTSxpREFBaUQ7QUFDM0YsUUFBTSxXQUFXO0FBQUEsSUFDYixXQUFXLFFBQVE7QUFBQSxJQUNuQixRQUFRLFFBQVE7QUFBQSxJQUNoQixPQUFPLFFBQVE7QUFBQSxJQUNmLFlBQVksWUFBWSxDQUFDLEtBQUssSUFBSSxLQUFLLEVBQUUsTUFBTSxHQUFHLEdBQUk7QUFBQSxJQUN0RCxXQUFXLE1BQU0sU0FBUztBQUFBLElBQzFCLFVBQVUsU0FBUyxZQUFZO0FBQUE7QUFBQTtBQUFBLElBRy9CLFdBQVcscUJBQXFCO0FBQUEsTUFDNUIsT0FBTyxTQUFTLFNBQVM7QUFBQSxNQUN6QixNQUFNLFNBQVMsUUFBUTtBQUFBLE1BQ3ZCLFVBQVUsU0FBUyxZQUFZO0FBQUEsTUFDL0IsWUFBWSxTQUFTLGVBQWU7QUFBQSxJQUN4QyxDQUFDO0FBQUEsSUFDRCxhQUFhLGNBQWMsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBZTtBQUFBLE1BQzNDLE9BQU8sWUFBWTtBQUFBLE1BQ25CLFdBQVcsWUFBWSxhQUFhO0FBQUEsTUFDcEMsS0FBSyxZQUFZLE9BQU87QUFBQSxJQUM1QixFQUFFO0FBQUEsSUFDTjtBQUFBLElBQ0EsaUJBQWlCLFFBQVE7QUFBQSxFQUM3QjtBQUNBLFFBQU0sV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBLGdCQUFnQixRQUFRO0FBQUEsSUFDeEIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsZUFBZSxRQUFRO0FBQUEsSUFDdkIsVUFBVTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLE9BQU8sQ0FBQztBQUNkLFFBQU0sU0FBUyxNQUFNLFNBQVMsa0JBQWtCLFVBQVUsUUFBUSxHQUFHO0FBQ3JFLFFBQU0sV0FBVyxNQUFNLFNBQVMsSUFBSSxDQUFDLFlBQVUsUUFBUSxLQUFLO0FBRzVELFFBQU0sVUFBVSxDQUFDO0FBQ2pCLGFBQVcsQ0FBQyxRQUFRLE9BQU8sS0FBSyxNQUFNLFNBQVMsUUFBUSxHQUFFO0FBQ3JELFVBQU0sV0FBVyxNQUFNLFNBQVMscUJBQXFCO0FBQUEsTUFDakQsR0FBRztBQUFBLE1BQ0gsY0FBYyxRQUFRO0FBQUEsTUFDdEIsZUFBZSxRQUFRO0FBQUEsTUFDdkIsV0FBVyxRQUFRO0FBQUEsTUFDbkIsYUFBYSxRQUFRO0FBQUEsTUFDckIsZUFBZSxTQUFTO0FBQUEsTUFDeEIsU0FBUztBQUFBLE1BQ1QsWUFBWSxNQUFNO0FBQUEsSUFDdEIsR0FBRyxRQUFRLEdBQUc7QUFDZCxZQUFRLEtBQUssUUFBUSxVQUFVLEtBQUssQ0FBQztBQUNyQyxTQUFLLEtBQUssR0FBRyxRQUFRLElBQUk7QUFBQSxFQUM3QjtBQUNBLFFBQU0sUUFBUSxRQUFRLEtBQUssTUFBTTtBQUdqQyxRQUFNLFlBQVksTUFBTSxTQUFTLHVCQUF1QjtBQUFBLElBQ3BELEdBQUc7QUFBQSxJQUNILFlBQVksTUFBTTtBQUFBLElBQ2xCLFNBQVM7QUFBQSxJQUNULE1BQU07QUFBQSxFQUNWLEdBQUcsUUFBUSxHQUFHO0FBQ2QsT0FBSyxLQUFLLEdBQUcsU0FBUyxJQUFJO0FBQzFCLFFBQU0sWUFBWSxnQkFBZ0IsUUFBUSxRQUFRLFFBQVEsT0FBTyxNQUFNLFlBQVksT0FBTyxRQUFRO0FBQ2xHLFFBQU0sRUFBRSxNQUFNLEtBQUssSUFBSSxNQUFNLEdBQUcsS0FBSyxrQkFBa0IsRUFBRSxPQUFPLFlBQVksRUFBRSxHQUFHLGNBQWMsUUFBUSxTQUFTLEVBQUUsTUFBTSxjQUFjO0FBQUEsSUFDbEksV0FBVztBQUFBLEVBQ2YsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLFlBQVk7QUFDeEIsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUN4RixRQUFNLGNBQWMsTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBTyxLQUFLLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUU7QUFDOUcsUUFBTSxXQUFXLGdCQUFnQixTQUFTO0FBQzFDLFFBQU0sWUFBWSxVQUFVLE1BQU0sS0FBSyxFQUFFLE9BQU8sT0FBTyxFQUFFO0FBQ3pELFFBQU0sRUFBRSxNQUFNLFNBQVMsTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLGtCQUFrQixFQUFFLE9BQU87QUFBQSxJQUN0RSxZQUFZLFFBQVE7QUFBQSxJQUNwQixZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLGFBQWEsTUFBTSxjQUFjLEtBQUs7QUFBQSxJQUN0QyxRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxTQUFTLHVCQUF1QixNQUFNLFNBQVMsTUFBTSxXQUFnQixLQUFLLFNBQVMsSUFBSSxTQUFTLEtBQUssTUFBTSxtQ0FBbUMsRUFBRTtBQUFBLElBQ2hKLFlBQVk7QUFBQSxJQUNaLG1CQUFtQjtBQUFBLElBQ25CLGlCQUFpQixRQUFRO0FBQUEsRUFDN0IsQ0FBQyxFQUFFLE9BQU8sSUFBSSxFQUFFLE9BQU87QUFDdkIsTUFBSSxTQUFTLENBQUMsUUFBUyxPQUFNLElBQUksTUFBTSxPQUFPLFdBQVcseUJBQXlCO0FBQ2xGLFFBQU0sR0FBRyxLQUFLLFVBQVUsRUFBRSxPQUFPO0FBQUEsSUFDN0Isb0JBQW9CLFFBQVE7QUFBQSxJQUM1QixRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixrQkFBa0IsU0FBUyxXQUFXO0FBQUEsSUFDdEMsZUFBZSxTQUFTLFNBQVM7QUFBQSxJQUNqQyxjQUFjLFNBQVMsUUFBUTtBQUFBLElBQy9CLG1CQUFtQixTQUFTLGFBQWE7QUFBQSxJQUN6QyxZQUFZLFNBQVMsTUFBTTtBQUFBLEVBQy9CLENBQUMsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTO0FBQzdCLFNBQU87QUFBQSxJQUNILFNBQVM7QUFBQSxNQUNMLEdBQUc7QUFBQSxNQUNIO0FBQUEsTUFDQSxVQUFVLFNBQVMsU0FBUyxJQUFJLENBQUMsT0FBSztBQUFBLFFBQzlCLE9BQU8sRUFBRTtBQUFBLFFBQ1QsTUFBTSxFQUFFO0FBQUEsUUFDUixNQUFNLEVBQUU7QUFBQSxNQUNaLEVBQUU7QUFBQSxNQUNOLFlBQVksU0FBUyxXQUFXLElBQUksQ0FBQyxPQUFLO0FBQUEsUUFDbEMsVUFBVSxFQUFFO0FBQUEsUUFDWixTQUFTLEVBQUU7QUFBQSxRQUNYLE1BQU0sRUFBRTtBQUFBLE1BQ1osRUFBRTtBQUFBLE1BQ04sT0FBTyxTQUFTO0FBQUEsTUFDaEIsU0FBUyxTQUFTLFFBQVEsSUFBSSxDQUFDLE9BQUs7QUFBQSxRQUM1QixLQUFLLEVBQUU7QUFBQSxRQUNQLEtBQUssRUFBRTtBQUFBLFFBQ1AsTUFBTSxFQUFFO0FBQUEsTUFDWixFQUFFO0FBQUEsTUFDTixjQUFjLFNBQVMsYUFBYSxJQUFJLENBQUMsT0FBSztBQUFBLFFBQ3RDLGFBQWEsRUFBRTtBQUFBLFFBQ2YsTUFBTSxFQUFFO0FBQUEsTUFDWixFQUFFO0FBQUEsSUFDVjtBQUFBLElBQ0EsV0FBVyxRQUFRO0FBQUEsSUFDbkI7QUFBQSxJQUNBLFVBQVUsS0FBSyxXQUFXO0FBQUEsRUFDOUI7QUFDSjtBQXBKMEI7QUF3SjFCLGVBQXNCLGdCQUFnQixTQUFTLFNBQVM7QUFDcEQsUUFBTSxTQUFTLE1BQU0sU0FBUyx3QkFBd0IsU0FBUztBQUFBLElBQzNELElBQUksa0JBQWtCO0FBQUEsSUFDdEIsZ0JBQWdCLFFBQVE7QUFBQSxJQUN4QixXQUFXLFFBQVE7QUFBQSxJQUNuQixXQUFXLFFBQVE7QUFBQSxJQUNuQixlQUFlLFFBQVE7QUFBQSxJQUN2QixVQUFVO0FBQUEsRUFDZCxDQUFDO0FBQ0QsU0FBTyxPQUFPO0FBQ2xCO0FBVnNCO0FBc0JsQixlQUFzQixhQUFhLFNBQVMsU0FBUyxRQUFRO0FBQzdELE1BQUksUUFBUSxNQUFNLFdBQVcsS0FBSyxPQUFPLFdBQVcsR0FBRztBQUNuRCxXQUFPO0FBQUEsTUFDSCxXQUFXLENBQUM7QUFBQSxNQUNaLGFBQWEsQ0FBQztBQUFBLE1BQ2QsaUJBQWlCO0FBQUEsTUFDakIsUUFBUTtBQUFBLFFBQ0o7QUFBQSxVQUNJLE1BQU07QUFBQSxVQUNOLFVBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxVQUNQLFFBQVE7QUFBQSxVQUNSLFlBQVk7QUFBQSxVQUNaLFVBQVU7QUFBQSxZQUNOLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULFNBQVM7QUFBQSxVQUNiO0FBQUEsVUFDQSxVQUFVLENBQUM7QUFBQSxRQUNmO0FBQUEsTUFDSjtBQUFBO0FBQUEsTUFFQSxZQUFZO0FBQUEsTUFDWixTQUFTO0FBQUEsSUFDYjtBQUFBLEVBQ0o7QUFDQSxRQUFNLFNBQVMsTUFBTSxTQUFTLG9CQUFvQjtBQUFBLElBQzlDLEdBQUc7QUFBQSxJQUNIO0FBQUEsRUFDSixHQUFHO0FBQUEsSUFDQyxJQUFJLGtCQUFrQjtBQUFBLElBQ3RCLGdCQUFnQixRQUFRO0FBQUEsSUFDeEIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsZUFBZSxRQUFRO0FBQUEsSUFDdkIsVUFBVTtBQUFBLEVBQ2QsQ0FBQztBQUNELFNBQU8sT0FBTztBQUNsQjtBQXRDMEI7QUFrRHRCLGVBQXNCLGtCQUFrQixTQUFTLFFBQVEsYUFBYTtBQUN0RSxRQUFNLEtBQUssa0JBQWtCO0FBQzdCLFFBQU0sRUFBRSxPQUFPLGVBQWUsSUFBSSxNQUFNLGtCQUFrQixJQUFJLFFBQVEsZ0JBQWdCLFFBQVEsU0FBUztBQUd2RyxNQUFJLG1CQUFtQixHQUFHO0FBQ3RCLFdBQU87QUFBQSxNQUNIO0FBQUEsTUFDQSxXQUFXO0FBQUEsTUFDWCxnQkFBZ0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFDQSxRQUFNLFdBQVcsZUFBZSxRQUFRLEtBQUs7QUFDN0MsU0FBTztBQUFBLElBQ0gsYUFBYSxpQkFBaUIsYUFBYSxTQUFTLFdBQVc7QUFBQSxJQUMvRCxXQUFXLFNBQVM7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFDSjtBQWxCMEI7QUFpQ3RCLGVBQXNCLGdCQUFnQixVQUFVLFdBQVc7QUFDM0QsUUFBTSxnQkFBZ0IsVUFBVSxPQUFPLENBQUMsYUFBVyxTQUFTLGlCQUFpQixZQUFZO0FBQ3pGLE1BQUksY0FBYyxXQUFXLEVBQUcsUUFBTztBQUFBLElBQ25DLFFBQVEsQ0FBQztBQUFBLElBQ1QsVUFBVSxDQUFDO0FBQUEsSUFDWCxRQUFRO0FBQUEsRUFDWjtBQUNBLFFBQU0sUUFBUSxNQUFNLFdBQVcsY0FBYyxJQUFJLENBQUMsYUFBVyxTQUFTLEdBQUcsQ0FBQztBQUMxRSxRQUFNLFNBQVMsQ0FBQztBQUNoQixRQUFNLFdBQVcsQ0FBQztBQUNsQixXQUFRLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUU7QUFDcEMsVUFBTSxRQUFRLE1BQU0sQ0FBQztBQUNyQixVQUFNLFdBQVcsY0FBYyxDQUFDO0FBQ2hDLGFBQVMsS0FBSztBQUFBLE1BQ1YsS0FBSyxTQUFTO0FBQUEsTUFDZCxRQUFRLE1BQU07QUFBQSxNQUNkLElBQUksTUFBTTtBQUFBLE1BQ1YsT0FBTyxNQUFNO0FBQUEsSUFDakIsQ0FBQztBQUNELFFBQUksTUFBTSxJQUFJO0FBR1YsVUFBSSxTQUFTLGNBQWMsQ0FBQyxTQUFTLFNBQVM7QUFDMUMsZUFBTyxLQUFLO0FBQUEsVUFDUixNQUFNO0FBQUEsVUFDTixVQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsVUFDUCxRQUFRLEdBQUcsU0FBUyxHQUFHLGFBQWEsTUFBTSxNQUFNLHlCQUFtQixNQUFNLFNBQVMsUUFBRztBQUFBLFVBQ3JGLFlBQVk7QUFBQSxVQUNaLFVBQVU7QUFBQSxZQUNOLE1BQU0sU0FBUyxRQUFRO0FBQUEsWUFDdkIsU0FBUztBQUFBLFlBQ1QsU0FBUyxTQUFTO0FBQUEsVUFDdEI7QUFBQSxVQUNBLFVBQVU7QUFBQSxZQUNOLFNBQVM7QUFBQSxVQUNiO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDTDtBQUNBO0FBQUEsSUFDSjtBQUNBLFdBQU8sS0FBSztBQUFBLE1BQ1IsTUFBTTtBQUFBLE1BQ04sVUFBVTtBQUFBLE1BQ1YsT0FBTztBQUFBLE1BQ1AsUUFBUSxHQUFHLFNBQVMsR0FBRyxtQkFBbUIsTUFBTSxXQUFXLE9BQU8sV0FBVyxNQUFNLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDdkcsWUFBWSxNQUFNLFFBQVE7QUFBQSxNQUMxQixVQUFVO0FBQUEsUUFDTixNQUFNLFNBQVMsUUFBUTtBQUFBLFFBQ3ZCLFNBQVM7QUFBQSxRQUNULFNBQVMsU0FBUztBQUFBLE1BQ3RCO0FBQUEsTUFDQSxVQUFVO0FBQUEsUUFDTixTQUFTO0FBQUEsTUFDYjtBQUFBLElBQ0osQ0FBQztBQUFBLEVBQ0w7QUFDQSxTQUFPO0FBQUEsSUFDSDtBQUFBLElBQ0E7QUFBQSxJQUNBLFFBQVEsT0FBTyxPQUFPLENBQUMsTUFBSSxFQUFFLGFBQWEsTUFBTSxFQUFFO0FBQUEsRUFDdEQ7QUFDSjtBQTlEMEI7QUFrRTFCLGVBQXNCLGFBQWEsU0FBUyxXQUFXLFNBQVMsYUFBYSxZQUFZLFlBQVk7QUFDakcsUUFBTSxLQUFLLGtCQUFrQjtBQUk3QixRQUFNLGdCQUFnQixRQUFRLE9BQU8sT0FBTyxDQUFDLFVBQVEsTUFBTSxVQUFVLHFDQUFxQztBQUMxRyxRQUFNLFNBQVM7QUFBQSxJQUNYLEdBQUcsVUFBVTtBQUFBLElBQ2IsR0FBRztBQUFBLElBQ0gsR0FBRztBQUFBLEVBQ1AsRUFBRSxJQUFJLENBQUMsV0FBUztBQUFBLElBQ1IsR0FBRztBQUFBO0FBQUE7QUFBQSxJQUdILFVBQVU7QUFBQSxNQUNOLEdBQUcsTUFBTTtBQUFBLE1BQ1QsTUFBTSxNQUFNLFNBQVMsU0FBUyxJQUFJLE9BQU8sTUFBTSxTQUFTO0FBQUEsSUFDNUQ7QUFBQSxFQUNKLEVBQUU7QUFHTixRQUFNLEdBQUcsS0FBSyxxQkFBcUIsRUFBRSxPQUFPLEVBQUUsR0FBRyxtQkFBbUIsUUFBUSxhQUFhO0FBQ3pGLE1BQUksT0FBTyxTQUFTLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDLFdBQVM7QUFBQSxNQUMxQixZQUFZLFFBQVE7QUFBQSxNQUNwQixpQkFBaUIsUUFBUTtBQUFBLE1BQ3pCLFlBQVksUUFBUTtBQUFBLE1BQ3BCLGlCQUFpQixRQUFRO0FBQUEsTUFDekIsTUFBTSxNQUFNO0FBQUEsTUFDWixVQUFVLE1BQU07QUFBQSxNQUNoQixRQUFRO0FBQUEsTUFDUixPQUFPLE1BQU07QUFBQSxNQUNiLFFBQVEsTUFBTTtBQUFBLE1BQ2QsWUFBWSxNQUFNO0FBQUEsTUFDbEIsVUFBVSxNQUFNO0FBQUEsTUFDaEIsVUFBVSxNQUFNO0FBQUEsSUFDcEIsRUFBRTtBQUNOLGFBQVEsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssS0FBSTtBQUNyQyxZQUFNLEdBQUcsS0FBSyxxQkFBcUIsRUFBRSxPQUFPLEtBQUssTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDO0FBQUEsSUFDdEU7QUFBQSxFQUNKO0FBRUEsUUFBTSxHQUFHLEtBQUssV0FBVyxFQUFFLE9BQU8sRUFBRSxHQUFHLGNBQWMsUUFBUSxTQUFTO0FBQ3RFLE1BQUksUUFBUSxVQUFVLFNBQVMsR0FBRztBQUM5QixVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxHQUFHLEtBQUssV0FBVyxFQUFFLE9BQU8sUUFBUSxVQUFVLElBQUksQ0FBQyxjQUFZO0FBQUEsTUFDN0QsWUFBWSxRQUFRO0FBQUEsTUFDcEIsaUJBQWlCLFFBQVE7QUFBQSxNQUN6QixZQUFZLFFBQVE7QUFBQSxNQUNwQixLQUFLLFNBQVM7QUFBQSxNQUNkLE9BQU8sU0FBUyxnQkFBZ0IsU0FBUyxRQUFRO0FBQUEsTUFDakQsV0FBVyxTQUFTLFVBQVU7QUFBQSxNQUM5QixhQUFhLFNBQVM7QUFBQSxNQUN0QixNQUFNLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlmLGFBQWEsV0FBVyxLQUFLLENBQUMsTUFBSSxFQUFFLFFBQVEsU0FBUyxHQUFHLEdBQUcsVUFBVTtBQUFBLE1BQ3JFLGNBQWMsV0FBVyxLQUFLLENBQUMsTUFBSSxFQUFFLFFBQVEsU0FBUyxHQUFHLEdBQUcsTUFBTTtBQUFBLE1BQ2xFLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUUsQ0FBQztBQUFBLEVBQ1g7QUFHQSxRQUFNLEdBQUcsS0FBSyxvQkFBb0IsRUFBRSxPQUFPLEVBQUUsR0FBRyxtQkFBbUIsUUFBUSxhQUFhO0FBQ3hGLFFBQU0saUJBQWlCLFlBQVksUUFBUSxDQUFDLGVBQWEsV0FBVyxXQUFXLElBQUksQ0FBQyxXQUFXLFdBQVM7QUFBQSxJQUM1RixZQUFZLFFBQVE7QUFBQSxJQUNwQixpQkFBaUIsUUFBUTtBQUFBLElBQ3pCLFlBQVksUUFBUTtBQUFBLElBQ3BCLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsWUFBWSxXQUFXO0FBQUEsSUFDdkIsZUFBZSxXQUFXO0FBQUEsSUFDMUIsVUFBVSxXQUFXO0FBQUEsSUFDckIsS0FBSyxVQUFVO0FBQUEsSUFDZixPQUFPLFVBQVU7QUFBQSxJQUNqQixTQUFTLFVBQVU7QUFBQSxJQUNuQixPQUFPLFVBQVU7QUFBQSxJQUNqQixNQUFNLFFBQVE7QUFBQSxJQUNkLGVBQWUsVUFBVTtBQUFBLElBQ3pCLFFBQVEsVUFBVTtBQUFBLElBQ2xCLGNBQWMsVUFBVTtBQUFBLElBQ3hCLE1BQU0sVUFBVTtBQUFBLElBQ2hCLFFBQVE7QUFBQSxFQUNaLEVBQUUsQ0FBQztBQUNYLFdBQVEsSUFBSSxHQUFHLElBQUksZUFBZSxRQUFRLEtBQUssS0FBSTtBQUMvQyxVQUFNLEdBQUcsS0FBSyxvQkFBb0IsRUFBRSxPQUFPLGVBQWUsTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDO0FBQUEsRUFDL0U7QUFDQSxTQUFPO0FBQUEsSUFDSCxZQUFZLE9BQU87QUFBQSxJQUNuQixVQUFVLE9BQU8sT0FBTyxDQUFDLE1BQUksRUFBRSxhQUFhLFVBQVUsRUFBRTtBQUFBLElBQ3hELE1BQU0sT0FBTyxPQUFPLENBQUMsTUFBSSxFQUFFLGFBQWEsTUFBTSxFQUFFO0FBQUEsSUFDaEQsYUFBYSxZQUFZO0FBQUEsRUFDN0I7QUFDSjtBQTdGc0I7QUFpR3RCLGVBQXNCLGdCQUFnQixTQUFTLFNBQVMsUUFBUSxhQUFhLGVBQWU7QUFDeEYsUUFBTSxLQUFLLGtCQUFrQjtBQUM3QixRQUFNLFNBQVMsTUFBTSxTQUFTLHNCQUFzQjtBQUFBLElBQ2hELEdBQUc7QUFBQSxJQUNIO0FBQUEsSUFDQTtBQUFBLEVBQ0osR0FBRztBQUFBLElBQ0M7QUFBQSxJQUNBLGdCQUFnQixRQUFRO0FBQUEsSUFDeEIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsV0FBVyxRQUFRO0FBQUEsSUFDbkIsZUFBZSxRQUFRO0FBQUEsSUFDdkIsVUFBVTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sV0FBVyxPQUFPO0FBRXhCLE1BQUksU0FBUyxRQUFRLFdBQVcsR0FBRztBQUMvQixXQUFPO0FBQUEsTUFDSCxXQUFXO0FBQUEsTUFDWCxhQUFhO0FBQUEsTUFDYixTQUFTLFNBQVM7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFDQSxRQUFNLEVBQUUsTUFBTSxLQUFLLElBQUksTUFBTSxHQUFHLEtBQUssa0JBQWtCLEVBQUUsT0FBTyxZQUFZLEVBQUUsR0FBRyxjQUFjLFFBQVEsU0FBUyxFQUFFLE1BQU0sY0FBYztBQUFBLElBQ2xJLFdBQVc7QUFBQSxFQUNmLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRSxZQUFZO0FBQ3hCLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTLFNBQVMsQ0FBQztBQUNqRyxRQUFNLGNBQWMsTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUU7QUFDeEcsUUFBTSxFQUFFLE1BQU0sU0FBUyxNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssa0JBQWtCLEVBQUUsT0FBTztBQUFBLElBQ3RFLFlBQVksUUFBUTtBQUFBLElBQ3BCLFlBQVksUUFBUTtBQUFBLElBQ3BCLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsYUFBYSxNQUFNLGNBQWMsS0FBSztBQUFBLElBQ3RDLFFBQVE7QUFBQSxJQUNSLFlBQVksU0FBUztBQUFBLElBQ3JCLGNBQWM7QUFBQSxJQUNkLFNBQVMsU0FBUztBQUFBLElBQ2xCLFlBQVksU0FBUyxVQUFVLE1BQU0sS0FBSyxFQUFFLE9BQU8sT0FBTyxFQUFFO0FBQUEsSUFDNUQsbUJBQW1CO0FBQUEsSUFDbkIsaUJBQWlCLFFBQVE7QUFBQSxJQUN6QixjQUFjLE9BQU87QUFBQSxJQUNyQixZQUFZLFFBQVE7QUFBQSxFQUN4QixDQUFDLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTztBQUN2QixNQUFJLFNBQVMsQ0FBQyxRQUFTLE9BQU0sSUFBSSxNQUFNLHVDQUF1QyxPQUFPLFdBQVcsRUFBRSxFQUFFO0FBQ3BHLFNBQU87QUFBQSxJQUNILFdBQVcsUUFBUTtBQUFBLElBQ25CLGFBQWEsU0FBUyxRQUFRO0FBQUEsSUFDOUIsU0FBUyxTQUFTO0FBQUEsRUFDdEI7QUFDSjtBQWpEc0I7QUFxRHRCLGVBQXNCLFlBQVksU0FBUyxTQUFTLGNBQWM7QUFDOUQsUUFBTSxTQUFTLE1BQU0sU0FBUyxpQkFBaUI7QUFBQSxJQUMzQyxHQUFHO0FBQUEsSUFDSDtBQUFBLEVBQ0osR0FBRztBQUFBLElBQ0MsSUFBSSxrQkFBa0I7QUFBQSxJQUN0QixnQkFBZ0IsUUFBUTtBQUFBLElBQ3hCLFdBQVcsUUFBUTtBQUFBLElBQ25CLFdBQVcsUUFBUTtBQUFBLElBQ25CLGVBQWUsUUFBUTtBQUFBLElBQ3ZCLFVBQVU7QUFBQSxFQUNkLENBQUM7QUFDRCxTQUFPLE9BQU87QUFDbEI7QUFic0I7QUFpQnRCLGVBQXNCLGlCQUFpQixTQUFTLGNBQWMsY0FBYyxlQUFlO0FBQ3ZGLFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxVQUFVLG1CQUFtQjtBQUFBLElBQy9CLFFBQVE7QUFBQSxJQUNSLGNBQWM7QUFBQSxJQUNkO0FBQUEsRUFDSixDQUFDO0FBQ0QsUUFBTSxFQUFFLE1BQU0sU0FBUyxJQUFJLE1BQU0sR0FBRyxLQUFLLGVBQWUsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLGNBQWMsUUFBUSxTQUFTLEVBQUUsR0FBRyxRQUFRLFNBQVMsRUFBRSxNQUFNLFdBQVc7QUFBQSxJQUNuSixXQUFXO0FBQUEsRUFDZixDQUFDLEVBQUUsTUFBTSxDQUFDLEVBQUUsWUFBWTtBQUN4QixRQUFNLEVBQUUsTUFBTSxPQUFPLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxlQUFlLEVBQUUsT0FBTztBQUFBLElBQ2pFLFlBQVksUUFBUTtBQUFBLElBQ3BCLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsWUFBWSxRQUFRO0FBQUEsSUFDcEIsTUFBTTtBQUFBLElBQ04sV0FBVztBQUFBO0FBQUEsSUFFWCxRQUFRO0FBQUEsSUFDUixVQUFVLFVBQVUsV0FBVyxLQUFLO0FBQUEsSUFDcEMsT0FBTyxRQUFRO0FBQUEsSUFDZixTQUFTLFFBQVE7QUFBQSxJQUNqQixVQUFVLFFBQVE7QUFBQSxJQUNsQixnQkFBZ0IsUUFBUTtBQUFBLElBQ3hCLFlBQVksUUFBUTtBQUFBLEVBQ3hCLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPO0FBQ3ZCLE1BQUksU0FBUyxDQUFDLE1BQU8sT0FBTSxJQUFJLE1BQU0sc0NBQXNDLE9BQU8sV0FBVyxFQUFFLEVBQUU7QUFDakcsU0FBTztBQUFBLElBQ0gsVUFBVTtBQUFBLE1BQ04sTUFBTTtBQUFBLElBQ1Y7QUFBQSxJQUNBLFNBQVMsUUFBUTtBQUFBLEVBQ3JCO0FBQ0o7QUFoQ3NCO0FBb0N0QixlQUFzQixnQkFBZ0IsU0FBUyxlQUFlLG1CQUFtQixhQUFhLFNBQVM7QUFDbkcsUUFBTSxLQUFLLGtCQUFrQjtBQUM3QixRQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxHQUFHLEtBQUssaUJBQWlCLEVBQUUsT0FBTztBQUFBLElBQzVELFlBQVksUUFBUTtBQUFBLElBQ3BCLGlCQUFpQixRQUFRO0FBQUEsSUFDekIsWUFBWSxRQUFRO0FBQUEsSUFDcEIsaUJBQWlCLFFBQVE7QUFBQSxJQUN6QixpQkFBaUI7QUFBQSxJQUNqQixxQkFBcUI7QUFBQSxJQUNyQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUDtBQUFBLElBQ0EsY0FBYztBQUFBLElBQ2QsY0FBYyxRQUFRO0FBQUEsRUFDMUIsQ0FBQyxFQUFFLE9BQU8sSUFBSSxFQUFFLE9BQU87QUFDdkIsTUFBSSxTQUFTLENBQUMsS0FBTSxPQUFNLElBQUksTUFBTSxtREFBbUQsT0FBTyxXQUFXLEVBQUUsRUFBRTtBQUM3RyxRQUFNLEdBQUcsS0FBSyxlQUFlLEVBQUUsT0FBTztBQUFBLElBQ2xDLFFBQVE7QUFBQSxJQUNSLGNBQWM7QUFBQSxFQUNsQixDQUFDLEVBQUUsR0FBRyxNQUFNLFFBQVEsYUFBYTtBQUNqQyxRQUFNLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTztBQUFBLElBQzdCLFFBQVE7QUFBQSxFQUNaLENBQUMsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTO0FBQzdCLFNBQU8sS0FBSztBQUNoQjtBQXhCc0I7QUE0QnRCLGVBQXNCLGNBQWMsU0FBUyxpQkFBaUIsOEJBQThCLFVBQVUsTUFBTSxXQUFXO0FBQ25ILFFBQU0sS0FBSyxrQkFBa0I7QUFDN0IsUUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBSW5DLFFBQU0sRUFBRSxNQUFNLFFBQVEsSUFBSSxNQUFNLEdBQUcsS0FBSyxpQkFBaUIsRUFBRSxPQUFPLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxlQUFlLEVBQUUsWUFBWTtBQUMvSCxRQUFNLG9CQUFvQixTQUFTLHVCQUF1QjtBQUMxRCxRQUFNLEdBQUcsS0FBSyxpQkFBaUIsRUFBRSxPQUFPO0FBQUEsSUFDcEMsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osWUFBWTtBQUFBLElBQ1osZUFBZTtBQUFBLEVBQ25CLENBQUMsRUFBRSxHQUFHLE1BQU0sZUFBZTtBQUMzQixNQUFJLGFBQWEsY0FBYyxDQUFDLG1CQUFtQjtBQUMvQyxVQUFNLEdBQUcsS0FBSyxVQUFVLEVBQUUsT0FBTztBQUFBLE1BQzdCLFFBQVE7QUFBQSxJQUNaLENBQUMsRUFBRSxHQUFHLE1BQU0sUUFBUSxTQUFTO0FBQzdCLFdBQU87QUFBQSxNQUNILG1CQUFtQjtBQUFBLElBQ3ZCO0FBQUEsRUFDSjtBQUdBLFFBQU0sR0FBRyxLQUFLLGtCQUFrQixFQUFFLE9BQU87QUFBQSxJQUNyQyxRQUFRO0FBQUEsSUFDUixhQUFhO0FBQUEsSUFDYixhQUFhO0FBQUEsSUFDYixhQUFhO0FBQUEsRUFDakIsQ0FBQyxFQUFFLEdBQUcsTUFBTSxpQkFBaUI7QUFDN0IsUUFBTSxHQUFHLEtBQUssVUFBVSxFQUFFLE9BQU87QUFBQSxJQUM3QixvQkFBb0I7QUFBQSxJQUNwQixRQUFRO0FBQUEsRUFDWixDQUFDLEVBQUUsR0FBRyxNQUFNLFFBQVEsU0FBUztBQUM3QixTQUFPO0FBQUEsSUFDSCxtQkFBbUI7QUFBQSxFQUN2QjtBQUNKO0FBckNzQjtBQXlDdEIsZUFBc0IsU0FBUyxlQUFlLE1BQU0sV0FBVyxPQUFPO0FBQ2xFLFFBQU0sa0JBQWtCLEVBQUUsS0FBSyxlQUFlLEVBQUUsT0FBTztBQUFBLElBQ25ELGNBQWM7QUFBQSxJQUNkLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxJQUNiLFFBQVE7QUFBQSxFQUNaLENBQUMsRUFBRSxHQUFHLE1BQU0sYUFBYTtBQUM3QjtBQVBzQjtBQVF0QixlQUFzQixVQUFVLGVBQWUsUUFBUSxRQUFRLE9BQU87QUFDbEUsUUFBTSxrQkFBa0IsRUFBRSxLQUFLLGVBQWUsRUFBRSxPQUFPO0FBQUEsSUFDbkQ7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLEVBQ3hDLENBQUMsRUFBRSxHQUFHLE1BQU0sYUFBYTtBQUM3QjtBQVBzQjtBQXNCbEIsZUFBc0Isb0JBQW9CLFNBQVM7QUFDbkQsTUFBSTtBQUNBLFVBQU0sUUFBUSxNQUFNLHlCQUF5QixrQkFBa0IsR0FBRztBQUFBLE1BQzlELFdBQVcsUUFBUTtBQUFBLE1BQ25CLGdCQUFnQixRQUFRO0FBQUEsTUFDeEIsU0FBUyxRQUFRO0FBQUEsSUFDckIsQ0FBQztBQUNELFdBQU87QUFBQSxNQUNILElBQUksTUFBTTtBQUFBLE1BQ1YsVUFBVSxNQUFNLFlBQVk7QUFBQSxNQUM1QixPQUFPLE1BQU0sU0FBUztBQUFBLE1BQ3RCLFNBQVMsTUFBTTtBQUFBLElBQ25CO0FBQUEsRUFDSixTQUFTLE9BQU87QUFDWixXQUFPO0FBQUEsTUFDSCxJQUFJO0FBQUEsTUFDSixVQUFVO0FBQUEsTUFDVixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QixNQUFNLE9BQU87QUFBQSxJQUN2RDtBQUFBLEVBQ0o7QUFDSjtBQXJCMEI7QUFzQjFCQyxzQkFBcUIsMERBQTBELFdBQVc7QUFDMUZBLHNCQUFxQiwyREFBMkQsWUFBWTtBQUM1RkEsc0JBQXFCLDhEQUE4RCxlQUFlO0FBQ2xHQSxzQkFBcUIsMkRBQTJELFlBQVk7QUFDNUZBLHNCQUFxQixnRUFBZ0UsaUJBQWlCO0FBQ3RHQSxzQkFBcUIsOERBQThELGVBQWU7QUFDbEdBLHNCQUFxQiwyREFBMkQsWUFBWTtBQUM1RkEsc0JBQXFCLDhEQUE4RCxlQUFlO0FBQ2xHQSxzQkFBcUIsMERBQTBELFdBQVc7QUFDMUZBLHNCQUFxQiwrREFBK0QsZ0JBQWdCO0FBQ3BHQSxzQkFBcUIsOERBQThELGVBQWU7QUFDbEdBLHNCQUFxQiw0REFBNEQsYUFBYTtBQUM5RkEsc0JBQXFCLHVEQUF1RCxRQUFRO0FBQ3BGQSxzQkFBcUIsd0RBQXdELFNBQVM7QUFDdEZBLHNCQUFxQixrRUFBa0UsbUJBQW1COzs7QUM1d0J0RyxTQUEyQixnQkFBd0Isa0JBQWxCQyx1QkFBOEI7IiwKICAibmFtZXMiOiBbInJlZ2lzdGVyU3RlcEZ1bmN0aW9uIiwgInJlZ2lzdGVyU3RlcEZ1bmN0aW9uIiwgInJlZ2lzdGVyU3RlcEZ1bmN0aW9uIiwgInJlZ2lzdGVyU3RlcEZ1bmN0aW9uIiwgInN0ZXBFbnRyeXBvaW50Il0KfQo=
